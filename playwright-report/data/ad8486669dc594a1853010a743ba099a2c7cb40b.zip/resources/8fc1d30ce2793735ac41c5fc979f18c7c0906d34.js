import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FocusStatisticsChart.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b4895507";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "/node_modules/.vite/deps/recharts.js?v=b4895507";
import { getTimerInsights } from "/src/services/apiClient.js";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/FocusStatisticsChart.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$();
function formatHours(value) {
	const hours = Number(value);
	if (!Number.isFinite(hours)) return "0 hours";
	return `${hours.toFixed(1)} ${hours.toFixed(1) === "1.0" ? "hour" : "hours"}`;
}
function formatCalendarDate(value) {
	if (!value) return "";
	const [year, month, day] = String(value).slice(0, 10).split("-").map(Number);
	if (!year || !month || !day) return String(value);
	return new Date(year, month - 1, day).toLocaleDateString(undefined, {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
}
function normalizeCurrentStreak(streak) {
	const value = Number(streak?.currentStreak);
	return Number.isFinite(value) && value >= 0 ? Math.floor(value) : null;
}
function normalizeDailyBreakdown(dailyBreakdown) {
	if (!Array.isArray(dailyBreakdown)) return [];
	return dailyBreakdown.map((day) => {
		const focusMinutes = Number(day?.focusMinutes ?? day?.focus_miutes ?? 0);
		const safeFocusMinutes = Number.isFinite(focusMinutes) && focusMinutes > 0 ? focusMinutes : 0;
		const date = String(day?.date ?? "");
		return {
			date,
			label: day?.dayOfWeek || day?.day_of_week || formatCalendarDate(date),
			focusHours: Math.round(safeFocusMinutes / 60 * 100) / 100
		};
	});
}
function FocusChartTooltip({ active, payload }) {
	if (!active || !Array.isArray(payload) || payload.length === 0) return null;
	const point = payload[0]?.payload;
	if (!point) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "focus-statistics-tooltip",
		children: [
			/* @__PURE__ */ _jsxDEV("strong", { children: point.label }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("span", { children: formatCalendarDate(point.date) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: [formatHours(point.focusHours), " of focus"] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 9
	}, this);
}
_c = FocusChartTooltip;
export default function FocusStatisticsChart() {
	_s();
	const [chartData, setChartData] = useState([]);
	const [currentStreak, setCurrentStreak] = useState(null);
	const [isLoading, setLoading] = useState(true);
	const [error, setError] = useState("");
	useEffect(() => {
		let isCurrent = true;
		const loadFocuseStatistics = async () => {
			setLoading(true);
			setError("");
			try {
				const insights = await getTimerInsights({ days: 7 });
				const dailyBreakdown = insights?.statistics?.dailyBreakdown;
				if (!Array.isArray(dailyBreakdown)) {
					throw new Error("The focus statisics response did not contain a daily breakdown.");
				}
				if (isCurrent) {
					setChartData(normalizeDailyBreakdown(dailyBreakdown));
					setCurrentStreak(normalizeCurrentStreak(insights?.streak));
				}
			} catch (requestError) {
				if (isCurrent) {
					setError(requestError instanceof Error ? requestError.message : "Unable to load focus statistics.");
				}
			} finally {
				if (isCurrent) setLoading(false);
			}
		};
		loadFocuseStatistics();
		return () => {
			isCurrent = false;
		};
	}, []);
	const totalFocusHours = chartData.reduce((total, day) => total + day.focusHours, 0);
	const handleRetry = async () => {
		setLoading(true);
		setError("");
		try {
			const insights = await getTimerInsights({ days: 7 });
			const dailyBreakdown = insights?.statistics?.dailyBreakdown;
			if (!Array.isArray(dailyBreakdown)) {
				throw new Error("The focus statistics repsonse did not contain a daily breakdown.");
			}
			setChartData(normalizeDailyBreakdown(dailyBreakdown));
			setCurrentStreak(normalizeCurrentStreak(insights?.streak));
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Unable to load focus statistics");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "focus-statistics-panel",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "focus-statistics-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					id: "focus-statistics-heading",
					children: "Focus Statistics"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 144,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Daily study hours over the last seven days" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 21
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 17
				}, this), !isLoading && !error && chartData.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
					className: "focus-statistics-header-metrics",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "focus-streak-counter",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "focus-streak-flame",
							children: "🔥"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "focus-streak-copy",
							children: [/* @__PURE__ */ _jsxDEV("strong", {
								className: "focus-streak-number",
								children: currentStreak ?? "—"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 33
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "focus-streak-label",
								children: "day streak"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "focus-statistics-total",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: [totalFocusHours.toFixed(1), " hrs "] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "this week" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 13
			}, this),
			isLoading && /* @__PURE__ */ _jsxDEV("p", {
				className: "focus-statistics-feedback",
				role: "status",
				children: "Loading Focus Statistics"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 17
			}, this),
			!isLoading && error && /* @__PURE__ */ _jsxDEV("div", {
				className: "focus-statistics-error",
				role: "alert",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: handleRetry,
					children: "Try Again"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 17
			}, this),
			!isLoading && !error && chartData.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "focus-statistics-feedback",
				children: "No focus statistics are available yet. Complete a focus session to start tracking your study hours."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 17
			}, this),
			!isLoading && !error && chartData.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "focus-statistics-chart",
				role: "img",
				children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ _jsxDEV(BarChart, {
						data: chartData,
						margin: {
							top: 8,
							right: 12,
							left: -18,
							bottom: 0
						},
						barCategoryGap: "25%",
						children: [
							/* @__PURE__ */ _jsxDEV(CartesianGrid, {
								vertical: false,
								stroke: "#dfe9e1",
								strokeDasharray: "3 3"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV(XAxis, {
								dataKay: "label",
								tickline: false,
								axisLine: false,
								tick: {
									fill: "#68716b",
									fontSize: 11
								},
								tickMargin: 10,
								interval: 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV(YAxis, {
								domain: [0, "auto"],
								allowDecimals: true,
								tickLine: false,
								axisLine: false,
								tick: {
									fill: "#68716b",
									fontSize: 10
								},
								tickFormatter: (value) => `${value}`,
								width: 42
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV(Tooltip, {
								content: /* @__PURE__ */ _jsxDEV(FocusChartTooltip, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 42
								}, this),
								cursor: { fill: "#218B4314" }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV(Bar, {
								dataKey: "focusHours",
								name: "Focus Hours",
								fill: "var(--primary-color)",
								radius: [
									5,
									5,
									0,
									0
								],
								maxBarSize: 48
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 29
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 141,
		columnNumber: 9
	}, this);
}
_s(FocusStatisticsChart, "7XeBJSVldBzkmYUIh/vugwBp/n0=");
_c2 = FocusStatisticsChart;
var _c, _c2;
$RefreshReg$(_c, "FocusChartTooltip");
$RefreshReg$(_c2, "FocusStatisticsChart");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FocusStatisticsChart.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/FocusStatisticsChart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/FocusStatisticsChart.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/FocusStatisticsChart.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUNJLEtBQ0EsVUFDQSxlQUNBLHFCQUNBLFNBQ0EsT0FDQSxhQUNHO0FBRVAsU0FBUyx3QkFBd0I7Ozs7QUFFakMsU0FBUyxZQUFZLE9BQU87Q0FDeEIsTUFBTSxRQUFRLE9BQU8sS0FBSztDQUMxQixJQUFJLENBQUMsT0FBTyxTQUFTLEtBQUssR0FBRyxPQUFPO0NBQ3BDLE9BQU8sR0FBRyxNQUFNLFFBQVEsQ0FBQyxFQUFFLEdBQUcsTUFBTSxRQUFRLENBQUMsTUFBTSxRQUFRLFNBQVM7QUFDeEU7QUFFQSxTQUFTLG1CQUFtQixPQUFPO0NBQy9CLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsTUFBTSxDQUFDLE1BQU0sT0FBTyxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNO0NBQzNFLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssT0FBTyxPQUFPLEtBQUs7Q0FFaEQsT0FBTyxJQUFJLEtBQUssTUFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLENBQUMsbUJBQW1CLFdBQVc7RUFDaEUsT0FBTztFQUNQLEtBQUs7RUFDTCxNQUFNO0NBQ1YsQ0FBQztBQUNMO0FBRUEsU0FBUyx1QkFBdUIsUUFBUTtDQUNwQyxNQUFNLFFBQVEsT0FBTyxRQUFRLGFBQWE7Q0FDMUMsT0FBTyxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJO0FBQ3RFO0FBRUEsU0FBUyx3QkFBd0IsZ0JBQWdCO0NBQzdDLElBQUksQ0FBQyxNQUFNLFFBQVEsY0FBYyxHQUFHLE9BQU8sQ0FBQztDQUU1QyxPQUFPLGVBQWUsS0FBSyxRQUFRO0VBQy9CLE1BQU0sZUFBZSxPQUFPLEtBQUssZ0JBQWdCLEtBQUssZ0JBQWdCLENBQUM7RUFDdkUsTUFBTSxtQkFBbUIsT0FBTyxTQUFTLFlBQVksS0FBSyxlQUFlLElBQ25FLGVBQ0E7RUFDTixNQUFNLE9BQU8sT0FBTyxLQUFLLFFBQVEsRUFBRTtFQUVuQyxPQUFPO0dBQ0g7R0FDQSxPQUFPLEtBQUssYUFBYSxLQUFLLGVBQWUsbUJBQW1CLElBQUk7R0FDcEUsWUFBWSxLQUFLLE1BQU8sbUJBQW1CLEtBQU0sR0FBRyxJQUFJO0VBQzVEO0NBQ0osQ0FBQztBQUNMO0FBRUEsU0FBUyxrQkFBa0IsRUFBRSxRQUFRLFdBQVc7Q0FDNUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxLQUFLLFFBQVEsV0FBVyxHQUFHLE9BQU87Q0FFdkUsTUFBTSxRQUFRLFFBQVEsRUFBRSxFQUFFO0NBQzFCLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FFbkIsT0FDSSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0ksd0JBQUMsVUFBRCxZQUFTLE1BQU0sTUFBYzs7Ozs7R0FDN0Isd0JBQUMsUUFBRCxZQUFPLG1CQUFtQixNQUFNLElBQUksRUFBUTs7Ozs7R0FDNUMsd0JBQUMsS0FBRCxhQUFJLFlBQVksTUFBTSxVQUFVLEdBQUUsV0FBWTs7Ozs7RUFDN0M7Ozs7OztBQUViOztBQUVBLGVBQWUsU0FBUyx1QkFBdUI7O0NBQzNDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLENBQUMsQ0FBQztDQUM3QyxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxJQUFJO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGNBQWMsU0FBUyxJQUFJO0NBQzdDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLGdCQUFnQjtFQUNaLElBQUksWUFBWTtFQUVoQixNQUFNLHVCQUF1QixZQUFZO0dBQ3JDLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTtHQUVYLElBQUk7SUFDQSxNQUFNLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUNuRCxNQUFNLGlCQUFpQixVQUFVLFlBQVk7SUFFN0MsSUFBSSxDQUFDLE1BQU0sUUFBUSxjQUFjLEdBQUc7S0FDaEMsTUFBTSxJQUFJLE1BQU0saUVBQWlFO0lBQ3JGO0lBRUEsSUFBSSxXQUFXO0tBQ1gsYUFBYSx3QkFBd0IsY0FBYyxDQUFDO0tBQ3BELGlCQUFpQix1QkFBdUIsVUFBVSxNQUFNLENBQUM7SUFDN0Q7R0FDSixTQUFTLGNBQWM7SUFDbkIsSUFBSSxXQUFXO0tBQ1gsU0FDSSx3QkFBd0IsUUFDbEIsYUFBYSxVQUNiLGtDQUNWO0lBQ0o7R0FDSixVQUFVO0lBQ04sSUFBSSxXQUFXLFdBQVcsS0FBSztHQUNuQztFQUNKO0VBRUEscUJBQXFCO0VBRXJCLGFBQWE7R0FDVCxZQUFZO0VBQ2hCO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGtCQUFrQixVQUFVLFFBQVEsT0FBTyxRQUFRLFFBQVEsSUFBSSxZQUFZLENBQUM7Q0FFbEYsTUFBTSxjQUFjLFlBQVk7RUFDNUIsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNBLE1BQU0sV0FBVyxNQUFNLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxDQUFDO0dBQ25ELE1BQU0saUJBQWlCLFVBQVUsWUFBWTtHQUM3QyxJQUFJLENBQUMsTUFBTSxRQUFRLGNBQWMsR0FBRztJQUNoQyxNQUFNLElBQUksTUFBTSxrRUFBa0U7R0FDdEY7R0FDQSxhQUFhLHdCQUF3QixjQUFjLENBQUM7R0FDcEQsaUJBQWlCLHVCQUF1QixVQUFVLE1BQU0sQ0FBQztFQUM3RCxTQUFTLGNBQWM7R0FDbkIsU0FDSSx3QkFBd0IsUUFDbEIsYUFBYSxVQUNiLGlDQUNWO0VBQ0osVUFBVTtHQUNOLFdBQVcsS0FBSztFQUNwQjtDQUNKO0NBRUEsT0FDSSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtLQUFJLElBQUc7ZUFBMkI7SUFBb0I7Ozs7Y0FDdEQsd0JBQUMsS0FBRCxZQUFHLDZDQUE2Qzs7OztZQUMvQzs7OztjQUNKLENBQUMsYUFBYSxDQUFDLFNBQVMsVUFBVSxTQUFTLEtBQ3hDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFxQjtNQUFROzs7O2dCQUM3Qyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FDSSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBdUIsaUJBQWlCO09BQVk7Ozs7aUJBQ3RFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFxQjtPQUFnQjs7OztlQUNuRDs7Ozs7Y0FDTDs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNJLHdCQUFDLFVBQUQsYUFBUyxnQkFBZ0IsUUFBUSxDQUFDLEdBQUUsT0FBYTs7OztnQkFDakQsd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7Y0FDcEI7Ozs7O2FBQ0o7Ozs7O1lBRVI7Ozs7OztHQUVKLGFBQ0csd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBNEIsTUFBSztjQUFTO0dBRXBEOzs7OztHQUdOLENBQUMsYUFBYSxTQUNYLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQXlCLE1BQUs7Y0FBN0MsQ0FDSSx3QkFBQyxLQUFELFlBQUksTUFBUzs7OztjQUNiLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsU0FBUztlQUFhO0lBQWlCOzs7O1lBQzVEOzs7Ozs7R0FHUixDQUFDLGFBQWEsQ0FBQyxTQUFTLFVBQVUsV0FBVyxLQUMxQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUE0QjtHQUV0Qzs7Ozs7R0FHTixDQUFDLGFBQWEsQ0FBQyxTQUFTLFVBQVUsU0FBUyxLQUN4Qyx3QkFBQyxPQUFEO0lBQ0ksV0FBVTtJQUNWLE1BQUs7Y0FFTCx3QkFBQyxxQkFBRDtLQUFxQixPQUFNO0tBQU8sUUFBTztlQUNyQyx3QkFBQyxVQUFEO01BQ0ksTUFBTTtNQUNOLFFBQVE7T0FBRSxLQUFLO09BQUcsT0FBTztPQUFJLE1BQU0sQ0FBQztPQUFJLFFBQVE7TUFBRTtNQUNsRCxnQkFBZTtnQkFIbkI7T0FLSSx3QkFBQyxlQUFEO1FBQ0ksVUFBVTtRQUNWLFFBQU87UUFDUCxpQkFBZ0I7T0FDbkI7Ozs7O09BQ0Qsd0JBQUMsT0FBRDtRQUNJLFNBQVE7UUFDUixVQUFVO1FBQ1YsVUFBVTtRQUNWLE1BQU07U0FBRSxNQUFNO1NBQVcsVUFBVTtRQUFHO1FBQ3RDLFlBQVk7UUFDWixVQUFVO09BQ2I7Ozs7O09BQ0Qsd0JBQUMsT0FBRDtRQUNJLFFBQVEsQ0FBQyxHQUFHLE1BQU07UUFDbEI7UUFDQSxVQUFVO1FBQ1YsVUFBVTtRQUNWLE1BQU07U0FBRSxNQUFNO1NBQVcsVUFBVTtRQUFHO1FBQ3RDLGdCQUFnQixVQUFVLEdBQUc7UUFDN0IsT0FBTztPQUNWOzs7OztPQUNELHdCQUFDLFNBQUQ7UUFDSSxTQUFTLHdCQUFDLG1CQUFELENBQW9COzs7OztRQUM3QixRQUFRLEVBQUUsTUFBTSxZQUFZO09BQy9COzs7OztPQUNELHdCQUFDLEtBQUQ7UUFDSSxTQUFRO1FBQ1IsTUFBSztRQUNMLE1BQUs7UUFDTCxRQUFRO1NBQUM7U0FBRztTQUFHO1NBQUc7UUFBQztRQUNuQixZQUFZO09BQ2Y7Ozs7O01BQ0s7Ozs7OztJQUNPOzs7OztHQUVwQjs7Ozs7RUFFSjs7Ozs7O0FBRWpCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZvY3VzU3RhdGlzdGljc0NoYXJ0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgICBCYXIsXG4gICAgQmFyQ2hhcnQsXG4gICAgQ2FydGVzaWFuR3JpZCxcbiAgICBSZXNwb25zaXZlQ29udGFpbmVyLFxuICAgIFRvb2x0aXAsXG4gICAgWEF4aXMsXG4gICAgWUF4aXMsXG59IGZyb20gJ3JlY2hhcnRzJ1xuXG5pbXBvcnQgeyBnZXRUaW1lckluc2lnaHRzIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpQ2xpZW50JztcblxuZnVuY3Rpb24gZm9ybWF0SG91cnModmFsdWUpIHtcbiAgICBjb25zdCBob3VycyA9IE51bWJlcih2YWx1ZSk7XG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoaG91cnMpKSByZXR1cm4gJzAgaG91cnMnO1xuICAgIHJldHVybiBgJHtob3Vycy50b0ZpeGVkKDEpfSAke2hvdXJzLnRvRml4ZWQoMSkgPT09ICcxLjAnID8gJ2hvdXInIDogJ2hvdXJzJ31gO1xufVxuXG5mdW5jdGlvbiBmb3JtYXRDYWxlbmRhckRhdGUodmFsdWUpIHtcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gJyc7XG4gICAgY29uc3QgW3llYXIsIG1vbnRoLCBkYXldID0gU3RyaW5nKHZhbHVlKS5zbGljZSgwLCAxMCkuc3BsaXQoJy0nKS5tYXAoTnVtYmVyKTtcbiAgICBpZiAoIXllYXIgfHwgIW1vbnRoIHx8ICFkYXkpIHJldHVybiBTdHJpbmcodmFsdWUpO1xuXG4gICAgcmV0dXJuIG5ldyBEYXRlKHllYXIsIG1vbnRoIC0gMSwgZGF5KS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7XG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxuICAgICAgICBkYXk6ICdudW1lcmljJyxcbiAgICAgICAgeWVhcjogJ251bWVyaWMnLFxuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVDdXJyZW50U3RyZWFrKHN0cmVhaykge1xuICAgIGNvbnN0IHZhbHVlID0gTnVtYmVyKHN0cmVhaz8uY3VycmVudFN0cmVhayk7XG4gICAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgPj0gMCA/IE1hdGguZmxvb3IodmFsdWUpIDogbnVsbDtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplRGFpbHlCcmVha2Rvd24oZGFpbHlCcmVha2Rvd24pIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGFpbHlCcmVha2Rvd24pKSByZXR1cm4gW107XG5cbiAgICByZXR1cm4gZGFpbHlCcmVha2Rvd24ubWFwKChkYXkpID0+IHtcbiAgICAgICAgY29uc3QgZm9jdXNNaW51dGVzID0gTnVtYmVyKGRheT8uZm9jdXNNaW51dGVzID8/IGRheT8uZm9jdXNfbWl1dGVzID8/IDApO1xuICAgICAgICBjb25zdCBzYWZlRm9jdXNNaW51dGVzID0gTnVtYmVyLmlzRmluaXRlKGZvY3VzTWludXRlcykgJiYgZm9jdXNNaW51dGVzID4gMFxuICAgICAgICAgICAgPyBmb2N1c01pbnV0ZXNcbiAgICAgICAgICAgIDogMDtcbiAgICAgICAgY29uc3QgZGF0ZSA9IFN0cmluZyhkYXk/LmRhdGUgPz8gJycpO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkYXRlLFxuICAgICAgICAgICAgbGFiZWw6IGRheT8uZGF5T2ZXZWVrIHx8IGRheT8uZGF5X29mX3dlZWsgfHwgZm9ybWF0Q2FsZW5kYXJEYXRlKGRhdGUpLFxuICAgICAgICAgICAgZm9jdXNIb3VyczogTWF0aC5yb3VuZCgoc2FmZUZvY3VzTWludXRlcyAvIDYwKSAqIDEwMCkgLyAxMDAsXG4gICAgICAgIH07XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIEZvY3VzQ2hhcnRUb29sdGlwKHsgYWN0aXZlLCBwYXlsb2FkIH0pIHtcbiAgICBpZiAoIWFjdGl2ZSB8fCAhQXJyYXkuaXNBcnJheShwYXlsb2FkKSB8fCBwYXlsb2FkLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBwb2ludCA9IHBheWxvYWRbMF0/LnBheWxvYWQ7XG4gICAgaWYgKCFwb2ludCkgcmV0dXJuIG51bGw7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtdG9vbHRpcFwiPlxuICAgICAgICAgICAgPHN0cm9uZz57cG9pbnQubGFiZWx9PC9zdHJvbmc+XG4gICAgICAgICAgICA8c3Bhbj57Zm9ybWF0Q2FsZW5kYXJEYXRlKHBvaW50LmRhdGUpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxwPntmb3JtYXRIb3Vycyhwb2ludC5mb2N1c0hvdXJzKX0gb2YgZm9jdXM8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvY3VzU3RhdGlzdGljc0NoYXJ0KCkge1xuICAgIGNvbnN0IFtjaGFydERhdGEsIHNldENoYXJ0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2N1cnJlbnRTdHJlYWssIHNldEN1cnJlbnRTdHJlYWtdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGxldCBpc0N1cnJlbnQgPSB0cnVlO1xuXG4gICAgICAgIGNvbnN0IGxvYWRGb2N1c2VTdGF0aXN0aWNzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIHNldEVycm9yKCcnKTtcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpbnNpZ2h0cyA9IGF3YWl0IGdldFRpbWVySW5zaWdodHMoeyBkYXlzOiA3IH0pO1xuICAgICAgICAgICAgICAgIGNvbnN0IGRhaWx5QnJlYWtkb3duID0gaW5zaWdodHM/LnN0YXRpc3RpY3M/LmRhaWx5QnJlYWtkb3duO1xuXG4gICAgICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGRhaWx5QnJlYWtkb3duKSkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZSBmb2N1cyBzdGF0aXNpY3MgcmVzcG9uc2UgZGlkIG5vdCBjb250YWluIGEgZGFpbHkgYnJlYWtkb3duLicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBpZiAoaXNDdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHNldENoYXJ0RGF0YShub3JtYWxpemVEYWlseUJyZWFrZG93bihkYWlseUJyZWFrZG93bikpO1xuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50U3RyZWFrKG5vcm1hbGl6ZUN1cnJlbnRTdHJlYWsoaW5zaWdodHM/LnN0cmVhaykpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgICAgICAgICAgIGlmIChpc0N1cnJlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1ZXN0RXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdVbmFibGUgdG8gbG9hZCBmb2N1cyBzdGF0aXN0aWNzLicsXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBpZiAoaXNDdXJyZW50KSBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBsb2FkRm9jdXNlU3RhdGlzdGljcygpO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpc0N1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCB0b3RhbEZvY3VzSG91cnMgPSBjaGFydERhdGEucmVkdWNlKCh0b3RhbCwgZGF5KSA9PiB0b3RhbCArIGRheS5mb2N1c0hvdXJzLCAwKTtcblxuICAgIGNvbnN0IGhhbmRsZVJldHJ5ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgICAgICBzZXRFcnJvcignJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGluc2lnaHRzID0gYXdhaXQgZ2V0VGltZXJJbnNpZ2h0cyh7IGRheXM6IDcgfSk7XG4gICAgICAgICAgICBjb25zdCBkYWlseUJyZWFrZG93biA9IGluc2lnaHRzPy5zdGF0aXN0aWNzPy5kYWlseUJyZWFrZG93bjtcbiAgICAgICAgICAgIGlmICghQXJyYXkuaXNBcnJheShkYWlseUJyZWFrZG93bikpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZSBmb2N1cyBzdGF0aXN0aWNzIHJlcHNvbnNlIGRpZCBub3QgY29udGFpbiBhIGRhaWx5IGJyZWFrZG93bi4nKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0Q2hhcnREYXRhKG5vcm1hbGl6ZURhaWx5QnJlYWtkb3duKGRhaWx5QnJlYWtkb3duKSk7XG4gICAgICAgICAgICBzZXRDdXJyZW50U3RyZWFrKG5vcm1hbGl6ZUN1cnJlbnRTdHJlYWsoaW5zaWdodHM/LnN0cmVhaykpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKFxuICAgICAgICAgICAgICAgIHJlcXVlc3RFcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIGxvYWQgZm9jdXMgc3RhdGlzdGljcydcbiAgICAgICAgICAgIClcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtcGFuZWxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9jdXMtc3RhdGlzdGljcy1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDIgaWQ9XCJmb2N1cy1zdGF0aXN0aWNzLWhlYWRpbmdcIj5Gb2N1cyBTdGF0aXN0aWNzPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgPHA+RGFpbHkgc3R1ZHkgaG91cnMgb3ZlciB0aGUgbGFzdCBzZXZlbiBkYXlzPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHshaXNMb2FkaW5nICYmICFlcnJvciAmJiBjaGFydERhdGEubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9jdXMtc3RhdGlzdGljcy1oZWFkZXItbWV0cmljc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb2N1cy1zdHJlYWstY291bnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvY3VzLXN0cmVhay1mbGFtZVwiPvCflKU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9jdXMtc3RyZWFrLWNvcHlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJmb2N1cy1zdHJlYWstbnVtYmVyXCI+e2N1cnJlbnRTdHJlYWsgPz8gJ+KAlCd9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvY3VzLXN0cmVhay1sYWJlbFwiPmRheSBzdHJlYWs8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtdG90YWxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPnt0b3RhbEZvY3VzSG91cnMudG9GaXhlZCgxKX0gaHJzIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnRoaXMgd2Vlazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtpc0xvYWRpbmcgJiYgKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtZmVlZGJhY2tcIiByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICAgIExvYWRpbmcgRm9jdXMgU3RhdGlzdGljc1xuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHshaXNMb2FkaW5nICYmIGVycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHA+e2Vycm9yfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlUmV0cnl9PlRyeSBBZ2FpbjwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiYgIWVycm9yICYmIGNoYXJ0RGF0YS5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtZmVlZGJhY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gZm9jdXMgc3RhdGlzdGljcyBhcmUgYXZhaWxhYmxlIHlldC4gQ29tcGxldGUgYSBmb2N1cyBzZXNzaW9uIHRvIHN0YXJ0IHRyYWNraW5nIHlvdXIgc3R1ZHkgaG91cnMuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiYgIWVycm9yICYmIGNoYXJ0RGF0YS5sZW5ndGggPiAwICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvY3VzLXN0YXRpc3RpY3MtY2hhcnRcIlxuICAgICAgICAgICAgICAgICAgICByb2xlPVwiaW1nXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCYXJDaGFydFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2NoYXJ0RGF0YX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW49e3sgdG9wOiA4LCByaWdodDogMTIsIGxlZnQ6IC0xOCwgYm90dG9tOiAwIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFyQ2F0ZWdvcnlHYXA9XCIyNSVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZlcnRpY2FsPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2RmZTllMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WEF4aXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YUtheT1cImxhYmVsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2xpbmU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBheGlzTGluZT17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpY2s9e3sgZmlsbDogJyM2ODcxNmInLCBmb250U2l6ZTogMTEgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja01hcmdpbj17MTB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludGVydmFsPXswfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFlBeGlzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvbWFpbj17WzAsICdhdXRvJ119XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93RGVjaW1hbHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja0xpbmU9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBheGlzTGluZT17ZmFsc2V9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpY2s9e3sgZmlsbDogJyM2ODcxNmInLCBmb250U2l6ZTogMTAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja0Zvcm1hdHRlcj17KHZhbHVlKSA9PiBgJHt2YWx1ZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aD17NDJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50PXs8Rm9jdXNDaGFydFRvb2x0aXAgLz59XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnNvcj17eyBmaWxsOiAnIzIxOEI0MzE0JyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJhclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhS2V5PVwiZm9jdXNIb3Vyc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJGb2N1cyBIb3Vyc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJ2YXIoLS1wcmltYXJ5LWNvbG9yKVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJhZGl1cz17WzUsIDUsIDAsIDBdfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhCYXJTaXplPXs0OH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CYXJDaGFydD5cbiAgICAgICAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxuXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG4gICAgKTtcbn0iXX0=