import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const API_BASE_URL = import.meta.env.VITE_API_URL?.replace(/\/$/, "") || "http://localhost:5050";
const AUTH_TOKEN_KEY = "authToken";
/**
* Retrieves the stored JWT authentication token from browser localStorage.
*
* @returns {string|null} The stored authentication token, or null if unauthenticated.
*/
export function getAuthToken() {
	return localStorage.getItem(AUTH_TOKEN_KEY);
}
/**
* Universal fetch wrapper for the Project Katch-Up REST API.
* Automatically attaches Authorization header if user is logged in and handles JSON/text parsing.
*
* @param {string} path - API endpoint path (e.g. '/api/tasks').
* @param {RequestInit} [options={}] - Standard fetch configuration options.
* @returns {Promise<any>} Parsed response JSON or text body.
* @throws {Error} If the HTTP response status is not ok (4xx or 5xx).
*/
export async function apiClient(path, options = {}) {
	const authToken = getAuthToken();
	const headers = {
		"Content-Type": "application/json",
		...options.headers || {}
	};
	if (authToken) {
		headers.Authorization = `Bearer ${authToken}`;
	}
	const response = await fetch(`${API_BASE_URL}${path}`, {
		...options,
		headers
	});
	let body = null;
	const contentType = response.headers.get("content-type") || "";
	if (contentType.includes("application/json")) {
		body = await response.json();
	} else if (response.status !== 204) {
		body = await response.text();
	}
	if (!response.ok) {
		const message = body && typeof body === "object" && (body.error || body.message) ? body.error || body.message : response.statusText || `Request failed with status ${response.status}.`;
		throw new Error(message);
	}
	return body;
}
/**
* Normalizes task list responses from various array or envelope formats.
*
* @param {any} payload - Raw API response payload.
* @returns {Array<object>} Normalized array of task objects.
*/
function normalizeTasks(payload) {
	if (Array.isArray(payload)) return payload;
	if (Array.isArray(payload?.tasks)) return payload.tasks;
	if (Array.isArray(payload?.data)) return payload.data;
	return [];
}
/**
* Fetches all non-deleted tasks for the authenticated user.
*
* @returns {Promise<Array<object>>} List of task objects.
*/
export async function getTasks() {
	return normalizeTasks(await apiClient("/api/tasks"));
}
/**
* Creates a new task.
*
* @param {object} task - Task details including title, optional description, and dueDate.
* @returns {Promise<object>} The created task object.
*/
export async function createTask(task) {
	return apiClient("/api/tasks", {
		method: "POST",
		body: JSON.stringify(task)
	});
}
/**
* Updates an existing task by its ID.
*
* @param {string|number} id - Unique identifier of the task.
* @param {object} updates - Fields to update on the task.
* @returns {Promise<object>} The updated task object.
*/
export async function updateTask(id, updates) {
	return apiClient(`/api/tasks/${id}`, {
		method: "PUT",
		body: JSON.stringify(updates)
	});
}
/**
* Soft deletes a task by its ID.
*
* @param {string|number} id - Unique identifier of the task.
* @returns {Promise<any>} API response payload.
*/
export async function deleteTask(id) {
	return apiClient(`/api/tasks/${id}`, { method: "DELETE" });
}
/**
* Fetches the next priority task for the authenticated user.
*
* @returns {Promise<object|null>} The next scheduled task or null.
*/
export async function getNextTask() {
	return apiClient("/api/tasks/next");
}
/**
* Starts or resumes the Pomodoro timer.
*
* @param {object} [options={}] - Timer options.
* @param {number} [options.taskId] - Optional ID of the task being worked on.
* @param {number} [options.durationSeconds] - Optional planned duration override in seconds.
* @returns {Promise<object>} Response with timer endTime and confirmation message.
*/
export async function startTimer({ taskId, durationSeconds } = {}) {
	return apiClient("/api/timer/start", {
		method: "POST",
		body: JSON.stringify({
			taskId,
			durationSeconds
		})
	});
}
/**
* Pauses the active Pomodoro timer.
*
* @returns {Promise<object>} Response with paused status and remaining seconds.
*/
export async function pauseTimer() {
	return apiClient("/api/timer/pause", { method: "POST" });
}
/**
* Completes the active timer phase and advances to the next phase.
*
* @returns {Promise<object>} Response containing the next phase.
*/
export async function stopTimer() {
	return apiClient("/api/timer/complete", { method: "POST" });
}
/**
* Resets the Pomodoro timer back to initial focus state.
*
* @returns {Promise<object>} Confirmation message.
*/
export async function resetTimer() {
	return apiClient("/api/timer/reset", { method: "POST" });
}
/**
* Retrieves the current real-time Pomodoro timer status from the server.
*
* @returns {Promise<object>} Status object with phase, remainingSeconds, isActive, and endTime.
*/
export async function getTimerStatus() {
	return apiClient("/api/timer/status");
}
/**
* Signs the user out, invalidates the session, and clears the local auth token.
*
* @returns {Promise<void>} Resolves when logout completes.
*/
export async function logout() {
	try {
		await apiClient("/api/auth/logout", { method: "POST" });
	} finally {
		localStorage.removeItem(AUTH_TOKEN_KEY);
	}
}
/**
* Retrieves timer habit insights, recommendations, and streaks.
*
* @param {object} [options={}] - Query options.
* @param {number} [options.days=7] - Number of trailing days to analyze.
* @returns {Promise<object>} Timer insights response.
*/
export async function getTimerInsights({ days = 7 } = {}) {
	const query = days ? `?days=${encodeURIComponent(days)}` : "";
	return apiClient(`/api/timer/insights${query}`);
}
/**
* Applies a productivity recommendation to the user's timer preferences.
*
* @param {object} [options={}] - Setting target and value to apply.
* @param {string} [options.target] - Setting identifier (e.g. 'break_interval').
* @param {number} [options.value] - New numeric value.
* @param {object} [options.action] - Optional action object envelope.
* @returns {Promise<object>} Result confirming the updated settings.
*/
export async function applyTimerInsight({ target, value, action } = {}) {
	return apiClient("/api/timer/insights/apply", {
		method: "POST",
		body: JSON.stringify({
			target,
			value,
			action
		})
	});
}
/**
* Records a completed or interrupted Pomodoro session to the database.
*
* @param {object} sessionData - Session attributes.
* @returns {Promise<object>} Persisted session record.
*/
export async function recordTimerSession(sessionData) {
	return apiClient("/api/timer/sessions", {
		method: "POST",
		body: JSON.stringify(sessionData)
	});
}
/**
* Fetches recent Pomodoro session history for the authenticated user.
*
* @param {object} [options={}] - Query options.
* @param {number} [options.limit=50] - Maximum sessions to return.
* @returns {Promise<Array<object>>} List of historical session records.
*/
export async function getTimerSessions({ limit = 50 } = {}) {
	const query = limit ? `?limit=${encodeURIComponent(limit)}` : "";
	return apiClient(`/api/timer/sessions${query}`);
}
/**
* Fetches user timer interval preferences.
*
* @returns {Promise<object>} Object with focusInterval, breakInterval, and pomodoroCycles.
*/
export async function getTimerPreferences() {
	return apiClient("/api/timer/preferences");
}
/**
* Updates user timer interval preferences.
*
* @param {object} preferences - Dictionary of updated preferences.
* @returns {Promise<object>} Confirmation message and updatedSettings.
*/
export async function updateTimerPreferences(preferences) {
	return apiClient("/api/timer/preferences", {
		method: "PUT",
		body: JSON.stringify(preferences)
	});
}
export default apiClient;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsTUFBTSxlQUFlLFlBQVksSUFBSSxjQUFjLFFBQVEsT0FBTyxFQUFFLEtBQUs7QUFDekUsTUFBTSxpQkFBaUI7Ozs7OztBQU92QixPQUFPLFNBQVMsZUFBZTtDQUM3QixPQUFPLGFBQWEsUUFBUSxjQUFjO0FBQzVDOzs7Ozs7Ozs7O0FBV0EsT0FBTyxlQUFlLFVBQVUsTUFBTSxVQUFVLENBQUMsR0FBRztDQUNsRCxNQUFNLFlBQVksYUFBYTtDQUUvQixNQUFNLFVBQVU7RUFDZCxnQkFBZ0I7RUFDaEIsR0FBSSxRQUFRLFdBQVcsQ0FBQztDQUMxQjtDQUVBLElBQUksV0FBVztFQUNiLFFBQVEsZ0JBQWdCLFVBQVU7Q0FDcEM7Q0FFQSxNQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsZUFBZSxRQUFRO0VBQ3JELEdBQUc7RUFDSDtDQUNGLENBQUM7Q0FFRCxJQUFJLE9BQU87Q0FDWCxNQUFNLGNBQWMsU0FBUyxRQUFRLElBQUksY0FBYyxLQUFLO0NBRTVELElBQUksWUFBWSxTQUFTLGtCQUFrQixHQUFHO0VBQzVDLE9BQU8sTUFBTSxTQUFTLEtBQUs7Q0FDN0IsT0FBTyxJQUFJLFNBQVMsV0FBVyxLQUFLO0VBQ2xDLE9BQU8sTUFBTSxTQUFTLEtBQUs7Q0FDN0I7Q0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0VBQ2hCLE1BQU0sVUFDSixRQUFRLE9BQU8sU0FBUyxhQUFhLEtBQUssU0FBUyxLQUFLLFdBQ3BELEtBQUssU0FBUyxLQUFLLFVBQ25CLFNBQVMsY0FBYyw4QkFBOEIsU0FBUyxPQUFPO0VBRTNFLE1BQU0sSUFBSSxNQUFNLE9BQU87Q0FDekI7Q0FFQSxPQUFPO0FBQ1Q7Ozs7Ozs7QUFRQSxTQUFTLGVBQWUsU0FBUztDQUMvQixJQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUcsT0FBTztDQUNuQyxJQUFJLE1BQU0sUUFBUSxTQUFTLEtBQUssR0FBRyxPQUFPLFFBQVE7Q0FDbEQsSUFBSSxNQUFNLFFBQVEsU0FBUyxJQUFJLEdBQUcsT0FBTyxRQUFRO0NBQ2pELE9BQU8sQ0FBQztBQUNWOzs7Ozs7QUFPQSxPQUFPLGVBQWUsV0FBVztDQUMvQixPQUFPLGVBQWUsTUFBTSxVQUFVLFlBQVksQ0FBQztBQUNyRDs7Ozs7OztBQVFBLE9BQU8sZUFBZSxXQUFXLE1BQU07Q0FDckMsT0FBTyxVQUFVLGNBQWM7RUFDN0IsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLElBQUk7Q0FDM0IsQ0FBQztBQUNIOzs7Ozs7OztBQVNBLE9BQU8sZUFBZSxXQUFXLElBQUksU0FBUztDQUM1QyxPQUFPLFVBQVUsY0FBYyxNQUFNO0VBQ25DLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVSxPQUFPO0NBQzlCLENBQUM7QUFDSDs7Ozs7OztBQVFBLE9BQU8sZUFBZSxXQUFXLElBQUk7Q0FDbkMsT0FBTyxVQUFVLGNBQWMsTUFBTSxFQUNuQyxRQUFRLFNBQ1YsQ0FBQztBQUNIOzs7Ozs7QUFPQSxPQUFPLGVBQWUsY0FBYztDQUNsQyxPQUFPLFVBQVUsaUJBQWlCO0FBQ3BDOzs7Ozs7Ozs7QUFVQSxPQUFPLGVBQWUsV0FBVyxFQUFFLFFBQVEsb0JBQW9CLENBQUMsR0FBRztDQUNqRSxPQUFPLFVBQVUsb0JBQW9CO0VBQ25DLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVTtHQUFFO0dBQVE7RUFBZ0IsQ0FBQztDQUNsRCxDQUFDO0FBQ0g7Ozs7OztBQU9BLE9BQU8sZUFBZSxhQUFhO0NBQ2pDLE9BQU8sVUFBVSxvQkFBb0IsRUFBRSxRQUFRLE9BQU8sQ0FBQztBQUN6RDs7Ozs7O0FBT0EsT0FBTyxlQUFlLFlBQVk7Q0FDaEMsT0FBTyxVQUFVLHVCQUF1QixFQUFFLFFBQVEsT0FBTyxDQUFDO0FBQzVEOzs7Ozs7QUFPQSxPQUFPLGVBQWUsYUFBYTtDQUNqQyxPQUFPLFVBQVUsb0JBQW9CLEVBQUUsUUFBUSxPQUFPLENBQUM7QUFDekQ7Ozs7OztBQU9BLE9BQU8sZUFBZSxpQkFBaUI7Q0FDckMsT0FBTyxVQUFVLG1CQUFtQjtBQUN0Qzs7Ozs7O0FBT0EsT0FBTyxlQUFlLFNBQVM7Q0FDN0IsSUFBSTtFQUNGLE1BQU0sVUFBVSxvQkFBb0IsRUFBRSxRQUFRLE9BQU8sQ0FBQztDQUN4RCxVQUFVO0VBQ1IsYUFBYSxXQUFXLGNBQWM7Q0FDeEM7QUFDRjs7Ozs7Ozs7QUFTQSxPQUFPLGVBQWUsaUJBQWlCLEVBQUUsT0FBTyxNQUFNLENBQUMsR0FBRztDQUN4RCxNQUFNLFFBQVEsT0FBTyxTQUFTLG1CQUFtQixJQUFJLE1BQU07Q0FDM0QsT0FBTyxVQUFVLHNCQUFzQixPQUFPO0FBQ2hEOzs7Ozs7Ozs7O0FBV0EsT0FBTyxlQUFlLGtCQUFrQixFQUFFLFFBQVEsT0FBTyxXQUFXLENBQUMsR0FBRztDQUN0RSxPQUFPLFVBQVUsNkJBQTZCO0VBQzVDLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVTtHQUFFO0dBQVE7R0FBTztFQUFPLENBQUM7Q0FDaEQsQ0FBQztBQUNIOzs7Ozs7O0FBUUEsT0FBTyxlQUFlLG1CQUFtQixhQUFhO0NBQ3BELE9BQU8sVUFBVSx1QkFBdUI7RUFDdEMsUUFBUTtFQUNSLE1BQU0sS0FBSyxVQUFVLFdBQVc7Q0FDbEMsQ0FBQztBQUNIOzs7Ozs7OztBQVNBLE9BQU8sZUFBZSxpQkFBaUIsRUFBRSxRQUFRLE9BQU8sQ0FBQyxHQUFHO0NBQzFELE1BQU0sUUFBUSxRQUFRLFVBQVUsbUJBQW1CLEtBQUssTUFBTTtDQUM5RCxPQUFPLFVBQVUsc0JBQXNCLE9BQU87QUFDaEQ7Ozs7OztBQU9BLE9BQU8sZUFBZSxzQkFBc0I7Q0FDMUMsT0FBTyxVQUFVLHdCQUF3QjtBQUMzQzs7Ozs7OztBQVFBLE9BQU8sZUFBZSx1QkFBdUIsYUFBYTtDQUN4RCxPQUFPLFVBQVUsMEJBQTBCO0VBQ3pDLFFBQVE7RUFDUixNQUFNLEtBQUssVUFBVSxXQUFXO0NBQ2xDLENBQUM7QUFDSDtBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXBpQ2xpZW50LmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEFQSV9CQVNFX1VSTCA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0FQSV9VUkw/LnJlcGxhY2UoL1xcLyQvLCAnJykgfHwgJ2h0dHA6Ly9sb2NhbGhvc3Q6NTA1MCc7XG5jb25zdCBBVVRIX1RPS0VOX0tFWSA9ICdhdXRoVG9rZW4nO1xuXG4vKipcbiAqIFJldHJpZXZlcyB0aGUgc3RvcmVkIEpXVCBhdXRoZW50aWNhdGlvbiB0b2tlbiBmcm9tIGJyb3dzZXIgbG9jYWxTdG9yYWdlLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gVGhlIHN0b3JlZCBhdXRoZW50aWNhdGlvbiB0b2tlbiwgb3IgbnVsbCBpZiB1bmF1dGhlbnRpY2F0ZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRBdXRoVG9rZW4oKSB7XG4gIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShBVVRIX1RPS0VOX0tFWSk7XG59XG5cbi8qKlxuICogVW5pdmVyc2FsIGZldGNoIHdyYXBwZXIgZm9yIHRoZSBQcm9qZWN0IEthdGNoLVVwIFJFU1QgQVBJLlxuICogQXV0b21hdGljYWxseSBhdHRhY2hlcyBBdXRob3JpemF0aW9uIGhlYWRlciBpZiB1c2VyIGlzIGxvZ2dlZCBpbiBhbmQgaGFuZGxlcyBKU09OL3RleHQgcGFyc2luZy5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aCAtIEFQSSBlbmRwb2ludCBwYXRoIChlLmcuICcvYXBpL3Rhc2tzJykuXG4gKiBAcGFyYW0ge1JlcXVlc3RJbml0fSBbb3B0aW9ucz17fV0gLSBTdGFuZGFyZCBmZXRjaCBjb25maWd1cmF0aW9uIG9wdGlvbnMuXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBQYXJzZWQgcmVzcG9uc2UgSlNPTiBvciB0ZXh0IGJvZHkuXG4gKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIEhUVFAgcmVzcG9uc2Ugc3RhdHVzIGlzIG5vdCBvayAoNHh4IG9yIDV4eCkuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcGlDbGllbnQocGF0aCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IGF1dGhUb2tlbiA9IGdldEF1dGhUb2tlbigpO1xuXG4gIGNvbnN0IGhlYWRlcnMgPSB7XG4gICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgfTtcblxuICBpZiAoYXV0aFRva2VuKSB7XG4gICAgaGVhZGVycy5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke2F1dGhUb2tlbn1gO1xuICB9XG5cbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfQkFTRV9VUkx9JHtwYXRofWAsIHtcbiAgICAuLi5vcHRpb25zLFxuICAgIGhlYWRlcnMsXG4gIH0pO1xuXG4gIGxldCBib2R5ID0gbnVsbDtcbiAgY29uc3QgY29udGVudFR5cGUgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykgfHwgJyc7XG5cbiAgaWYgKGNvbnRlbnRUeXBlLmluY2x1ZGVzKCdhcHBsaWNhdGlvbi9qc29uJykpIHtcbiAgICBib2R5ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICB9IGVsc2UgaWYgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMjA0KSB7XG4gICAgYm9keSA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgfVxuXG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgIGJvZHkgJiYgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIChib2R5LmVycm9yIHx8IGJvZHkubWVzc2FnZSlcbiAgICAgICAgPyBib2R5LmVycm9yIHx8IGJvZHkubWVzc2FnZVxuICAgICAgICA6IHJlc3BvbnNlLnN0YXR1c1RleHQgfHwgYFJlcXVlc3QgZmFpbGVkIHdpdGggc3RhdHVzICR7cmVzcG9uc2Uuc3RhdHVzfS5gO1xuXG4gICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICB9XG5cbiAgcmV0dXJuIGJvZHk7XG59XG5cbi8qKlxuICogTm9ybWFsaXplcyB0YXNrIGxpc3QgcmVzcG9uc2VzIGZyb20gdmFyaW91cyBhcnJheSBvciBlbnZlbG9wZSBmb3JtYXRzLlxuICpcbiAqIEBwYXJhbSB7YW55fSBwYXlsb2FkIC0gUmF3IEFQSSByZXNwb25zZSBwYXlsb2FkLlxuICogQHJldHVybnMge0FycmF5PG9iamVjdD59IE5vcm1hbGl6ZWQgYXJyYXkgb2YgdGFzayBvYmplY3RzLlxuICovXG5mdW5jdGlvbiBub3JtYWxpemVUYXNrcyhwYXlsb2FkKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KHBheWxvYWQpKSByZXR1cm4gcGF5bG9hZDtcbiAgaWYgKEFycmF5LmlzQXJyYXkocGF5bG9hZD8udGFza3MpKSByZXR1cm4gcGF5bG9hZC50YXNrcztcbiAgaWYgKEFycmF5LmlzQXJyYXkocGF5bG9hZD8uZGF0YSkpIHJldHVybiBwYXlsb2FkLmRhdGE7XG4gIHJldHVybiBbXTtcbn1cblxuLyoqXG4gKiBGZXRjaGVzIGFsbCBub24tZGVsZXRlZCB0YXNrcyBmb3IgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlci5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxBcnJheTxvYmplY3Q+Pn0gTGlzdCBvZiB0YXNrIG9iamVjdHMuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUYXNrcygpIHtcbiAgcmV0dXJuIG5vcm1hbGl6ZVRhc2tzKGF3YWl0IGFwaUNsaWVudCgnL2FwaS90YXNrcycpKTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IHRhc2suXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IHRhc2sgLSBUYXNrIGRldGFpbHMgaW5jbHVkaW5nIHRpdGxlLCBvcHRpb25hbCBkZXNjcmlwdGlvbiwgYW5kIGR1ZURhdGUuXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBUaGUgY3JlYXRlZCB0YXNrIG9iamVjdC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRhc2sodGFzaykge1xuICByZXR1cm4gYXBpQ2xpZW50KCcvYXBpL3Rhc2tzJywge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHRhc2spLFxuICB9KTtcbn1cblxuLyoqXG4gKiBVcGRhdGVzIGFuIGV4aXN0aW5nIHRhc2sgYnkgaXRzIElELlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfG51bWJlcn0gaWQgLSBVbmlxdWUgaWRlbnRpZmllciBvZiB0aGUgdGFzay5cbiAqIEBwYXJhbSB7b2JqZWN0fSB1cGRhdGVzIC0gRmllbGRzIHRvIHVwZGF0ZSBvbiB0aGUgdGFzay5cbiAqIEByZXR1cm5zIHtQcm9taXNlPG9iamVjdD59IFRoZSB1cGRhdGVkIHRhc2sgb2JqZWN0LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlVGFzayhpZCwgdXBkYXRlcykge1xuICByZXR1cm4gYXBpQ2xpZW50KGAvYXBpL3Rhc2tzLyR7aWR9YCwge1xuICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkodXBkYXRlcyksXG4gIH0pO1xufVxuXG4vKipcbiAqIFNvZnQgZGVsZXRlcyBhIHRhc2sgYnkgaXRzIElELlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfG51bWJlcn0gaWQgLSBVbmlxdWUgaWRlbnRpZmllciBvZiB0aGUgdGFzay5cbiAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59IEFQSSByZXNwb25zZSBwYXlsb2FkLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlVGFzayhpZCkge1xuICByZXR1cm4gYXBpQ2xpZW50KGAvYXBpL3Rhc2tzLyR7aWR9YCwge1xuICAgIG1ldGhvZDogJ0RFTEVURScsXG4gIH0pO1xufVxuXG4vKipcbiAqIEZldGNoZXMgdGhlIG5leHQgcHJpb3JpdHkgdGFzayBmb3IgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlci5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3R8bnVsbD59IFRoZSBuZXh0IHNjaGVkdWxlZCB0YXNrIG9yIG51bGwuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXROZXh0VGFzaygpIHtcbiAgcmV0dXJuIGFwaUNsaWVudCgnL2FwaS90YXNrcy9uZXh0Jyk7XG59XG5cbi8qKlxuICogU3RhcnRzIG9yIHJlc3VtZXMgdGhlIFBvbW9kb3JvIHRpbWVyLlxuICpcbiAqIEBwYXJhbSB7b2JqZWN0fSBbb3B0aW9ucz17fV0gLSBUaW1lciBvcHRpb25zLlxuICogQHBhcmFtIHtudW1iZXJ9IFtvcHRpb25zLnRhc2tJZF0gLSBPcHRpb25hbCBJRCBvZiB0aGUgdGFzayBiZWluZyB3b3JrZWQgb24uXG4gKiBAcGFyYW0ge251bWJlcn0gW29wdGlvbnMuZHVyYXRpb25TZWNvbmRzXSAtIE9wdGlvbmFsIHBsYW5uZWQgZHVyYXRpb24gb3ZlcnJpZGUgaW4gc2Vjb25kcy5cbiAqIEByZXR1cm5zIHtQcm9taXNlPG9iamVjdD59IFJlc3BvbnNlIHdpdGggdGltZXIgZW5kVGltZSBhbmQgY29uZmlybWF0aW9uIG1lc3NhZ2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdGFydFRpbWVyKHsgdGFza0lkLCBkdXJhdGlvblNlY29uZHMgfSA9IHt9KSB7XG4gIHJldHVybiBhcGlDbGllbnQoJy9hcGkvdGltZXIvc3RhcnQnLCB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyB0YXNrSWQsIGR1cmF0aW9uU2Vjb25kcyB9KSxcbiAgfSk7XG59XG5cbi8qKlxuICogUGF1c2VzIHRoZSBhY3RpdmUgUG9tb2Rvcm8gdGltZXIuXG4gKlxuICogQHJldHVybnMge1Byb21pc2U8b2JqZWN0Pn0gUmVzcG9uc2Ugd2l0aCBwYXVzZWQgc3RhdHVzIGFuZCByZW1haW5pbmcgc2Vjb25kcy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBhdXNlVGltZXIoKSB7XG4gIHJldHVybiBhcGlDbGllbnQoJy9hcGkvdGltZXIvcGF1c2UnLCB7IG1ldGhvZDogJ1BPU1QnIH0pO1xufVxuXG4vKipcbiAqIENvbXBsZXRlcyB0aGUgYWN0aXZlIHRpbWVyIHBoYXNlIGFuZCBhZHZhbmNlcyB0byB0aGUgbmV4dCBwaGFzZS5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBSZXNwb25zZSBjb250YWluaW5nIHRoZSBuZXh0IHBoYXNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RvcFRpbWVyKCkge1xuICByZXR1cm4gYXBpQ2xpZW50KCcvYXBpL3RpbWVyL2NvbXBsZXRlJywgeyBtZXRob2Q6ICdQT1NUJyB9KTtcbn1cblxuLyoqXG4gKiBSZXNldHMgdGhlIFBvbW9kb3JvIHRpbWVyIGJhY2sgdG8gaW5pdGlhbCBmb2N1cyBzdGF0ZS5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBDb25maXJtYXRpb24gbWVzc2FnZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlc2V0VGltZXIoKSB7XG4gIHJldHVybiBhcGlDbGllbnQoJy9hcGkvdGltZXIvcmVzZXQnLCB7IG1ldGhvZDogJ1BPU1QnIH0pO1xufVxuXG4vKipcbiAqIFJldHJpZXZlcyB0aGUgY3VycmVudCByZWFsLXRpbWUgUG9tb2Rvcm8gdGltZXIgc3RhdHVzIGZyb20gdGhlIHNlcnZlci5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBTdGF0dXMgb2JqZWN0IHdpdGggcGhhc2UsIHJlbWFpbmluZ1NlY29uZHMsIGlzQWN0aXZlLCBhbmQgZW5kVGltZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRpbWVyU3RhdHVzKCkge1xuICByZXR1cm4gYXBpQ2xpZW50KCcvYXBpL3RpbWVyL3N0YXR1cycpO1xufVxuXG4vKipcbiAqIFNpZ25zIHRoZSB1c2VyIG91dCwgaW52YWxpZGF0ZXMgdGhlIHNlc3Npb24sIGFuZCBjbGVhcnMgdGhlIGxvY2FsIGF1dGggdG9rZW4uXG4gKlxuICogQHJldHVybnMge1Byb21pc2U8dm9pZD59IFJlc29sdmVzIHdoZW4gbG9nb3V0IGNvbXBsZXRlcy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvZ291dCgpIHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBhcGlDbGllbnQoJy9hcGkvYXV0aC9sb2dvdXQnLCB7IG1ldGhvZDogJ1BPU1QnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKEFVVEhfVE9LRU5fS0VZKTtcbiAgfVxufVxuXG4vKipcbiAqIFJldHJpZXZlcyB0aW1lciBoYWJpdCBpbnNpZ2h0cywgcmVjb21tZW5kYXRpb25zLCBhbmQgc3RyZWFrcy5cbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gW29wdGlvbnM9e31dIC0gUXVlcnkgb3B0aW9ucy5cbiAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0aW9ucy5kYXlzPTddIC0gTnVtYmVyIG9mIHRyYWlsaW5nIGRheXMgdG8gYW5hbHl6ZS5cbiAqIEByZXR1cm5zIHtQcm9taXNlPG9iamVjdD59IFRpbWVyIGluc2lnaHRzIHJlc3BvbnNlLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGltZXJJbnNpZ2h0cyh7IGRheXMgPSA3IH0gPSB7fSkge1xuICBjb25zdCBxdWVyeSA9IGRheXMgPyBgP2RheXM9JHtlbmNvZGVVUklDb21wb25lbnQoZGF5cyl9YCA6ICcnO1xuICByZXR1cm4gYXBpQ2xpZW50KGAvYXBpL3RpbWVyL2luc2lnaHRzJHtxdWVyeX1gKTtcbn1cblxuLyoqXG4gKiBBcHBsaWVzIGEgcHJvZHVjdGl2aXR5IHJlY29tbWVuZGF0aW9uIHRvIHRoZSB1c2VyJ3MgdGltZXIgcHJlZmVyZW5jZXMuXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IFtvcHRpb25zPXt9XSAtIFNldHRpbmcgdGFyZ2V0IGFuZCB2YWx1ZSB0byBhcHBseS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9ucy50YXJnZXRdIC0gU2V0dGluZyBpZGVudGlmaWVyIChlLmcuICdicmVha19pbnRlcnZhbCcpLlxuICogQHBhcmFtIHtudW1iZXJ9IFtvcHRpb25zLnZhbHVlXSAtIE5ldyBudW1lcmljIHZhbHVlLlxuICogQHBhcmFtIHtvYmplY3R9IFtvcHRpb25zLmFjdGlvbl0gLSBPcHRpb25hbCBhY3Rpb24gb2JqZWN0IGVudmVsb3BlLlxuICogQHJldHVybnMge1Byb21pc2U8b2JqZWN0Pn0gUmVzdWx0IGNvbmZpcm1pbmcgdGhlIHVwZGF0ZWQgc2V0dGluZ3MuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBseVRpbWVySW5zaWdodCh7IHRhcmdldCwgdmFsdWUsIGFjdGlvbiB9ID0ge30pIHtcbiAgcmV0dXJuIGFwaUNsaWVudCgnL2FwaS90aW1lci9pbnNpZ2h0cy9hcHBseScsIHtcbiAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRhcmdldCwgdmFsdWUsIGFjdGlvbiB9KSxcbiAgfSk7XG59XG5cbi8qKlxuICogUmVjb3JkcyBhIGNvbXBsZXRlZCBvciBpbnRlcnJ1cHRlZCBQb21vZG9ybyBzZXNzaW9uIHRvIHRoZSBkYXRhYmFzZS5cbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gc2Vzc2lvbkRhdGEgLSBTZXNzaW9uIGF0dHJpYnV0ZXMuXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBQZXJzaXN0ZWQgc2Vzc2lvbiByZWNvcmQuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWNvcmRUaW1lclNlc3Npb24oc2Vzc2lvbkRhdGEpIHtcbiAgcmV0dXJuIGFwaUNsaWVudCgnL2FwaS90aW1lci9zZXNzaW9ucycsIHtcbiAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShzZXNzaW9uRGF0YSksXG4gIH0pO1xufVxuXG4vKipcbiAqIEZldGNoZXMgcmVjZW50IFBvbW9kb3JvIHNlc3Npb24gaGlzdG9yeSBmb3IgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlci5cbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gW29wdGlvbnM9e31dIC0gUXVlcnkgb3B0aW9ucy5cbiAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0aW9ucy5saW1pdD01MF0gLSBNYXhpbXVtIHNlc3Npb25zIHRvIHJldHVybi5cbiAqIEByZXR1cm5zIHtQcm9taXNlPEFycmF5PG9iamVjdD4+fSBMaXN0IG9mIGhpc3RvcmljYWwgc2Vzc2lvbiByZWNvcmRzLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGltZXJTZXNzaW9ucyh7IGxpbWl0ID0gNTAgfSA9IHt9KSB7XG4gIGNvbnN0IHF1ZXJ5ID0gbGltaXQgPyBgP2xpbWl0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KGxpbWl0KX1gIDogJyc7XG4gIHJldHVybiBhcGlDbGllbnQoYC9hcGkvdGltZXIvc2Vzc2lvbnMke3F1ZXJ5fWApO1xufVxuXG4vKipcbiAqIEZldGNoZXMgdXNlciB0aW1lciBpbnRlcnZhbCBwcmVmZXJlbmNlcy5cbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZTxvYmplY3Q+fSBPYmplY3Qgd2l0aCBmb2N1c0ludGVydmFsLCBicmVha0ludGVydmFsLCBhbmQgcG9tb2Rvcm9DeWNsZXMuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaW1lclByZWZlcmVuY2VzKCkge1xuICByZXR1cm4gYXBpQ2xpZW50KCcvYXBpL3RpbWVyL3ByZWZlcmVuY2VzJyk7XG59XG5cbi8qKlxuICogVXBkYXRlcyB1c2VyIHRpbWVyIGludGVydmFsIHByZWZlcmVuY2VzLlxuICpcbiAqIEBwYXJhbSB7b2JqZWN0fSBwcmVmZXJlbmNlcyAtIERpY3Rpb25hcnkgb2YgdXBkYXRlZCBwcmVmZXJlbmNlcy5cbiAqIEByZXR1cm5zIHtQcm9taXNlPG9iamVjdD59IENvbmZpcm1hdGlvbiBtZXNzYWdlIGFuZCB1cGRhdGVkU2V0dGluZ3MuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVUaW1lclByZWZlcmVuY2VzKHByZWZlcmVuY2VzKSB7XG4gIHJldHVybiBhcGlDbGllbnQoJy9hcGkvdGltZXIvcHJlZmVyZW5jZXMnLCB7XG4gICAgbWV0aG9kOiAnUFVUJyxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwcmVmZXJlbmNlcyksXG4gIH0pO1xufVxuXG5leHBvcnQgZGVmYXVsdCBhcGlDbGllbnQ7XG4iXX0=