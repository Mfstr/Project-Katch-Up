import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/main.jsx");const StrictMode = __vite__cjsImport1_react["StrictMode"];const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import "/src/styles/styles.css";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=b4895507";
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=b4895507";
import { BrowserRouter, Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=b4895507";
import Home from "/src/pages/home.jsx";
import Authorize from "/src/pages/authorize.jsx";
import { getAuthToken } from "/src/services/apiClient.js";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/main.jsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
const ProtectedRoute = ({ children }) => {
	const token = getAuthToken();
	return token ? children : /* @__PURE__ */ _jsxDEV(Navigate, {
		to: "/login",
		replace: true
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 31
	}, this);
};
_c = ProtectedRoute;
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
	/* @__PURE__ */ _jsxDEV(Route, {
		path: "/",
		element: /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 42
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 17
	}, this),
	/* @__PURE__ */ _jsxDEV(Route, {
		path: "/login",
		element: /* @__PURE__ */ _jsxDEV(Authorize, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 47
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 17
	}, this),
	/* @__PURE__ */ _jsxDEV(Route, {
		path: "/register",
		element: /* @__PURE__ */ _jsxDEV(Authorize, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 50
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 17
	}, this),
	/* @__PURE__ */ _jsxDEV(Route, {
		path: "/dashboard",
		element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(Home, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 67
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 51
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 17
	}, this),
	/* @__PURE__ */ _jsxDEV(Route, {
		path: "*",
		element: /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/login",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 42
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 17
	}, this)
] }, void 0, true, {
	fileName: _jsxFileName,
	lineNumber: 18,
	columnNumber: 13
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 17,
	columnNumber: 9
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 16,
	columnNumber: 5
}, this));
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/main.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/main.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/main.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/main.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsZUFBZSxVQUFVLE9BQU8sY0FBYztBQUV2RCxPQUFPLFVBQVU7QUFDakIsT0FBTyxlQUFlO0FBQ3RCLFNBQVMsb0JBQW9COzs7QUFFN0IsTUFBTSxrQkFBa0IsRUFBRSxlQUFlO0NBQ3JDLE1BQU0sUUFBUSxhQUFhO0NBQzNCLE9BQU8sUUFBUSxXQUFXLHdCQUFDLFVBQUQ7RUFBVSxJQUFHO0VBQVM7Q0FBUzs7Ozs7QUFDN0Q7O0FBRUEsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUN4Qyx3QkFBQyxZQUFELFlBQ0ksd0JBQUMsZUFBRCxZQUNJLHdCQUFDLFFBQUQ7Q0FDSSx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFJLFNBQVMsd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUztFQUFTOzs7OztDQUFJOzs7OztDQUM1RCx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFTLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztDQUFJOzs7OztDQUM5Qyx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFZLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztDQUFJOzs7OztDQUNqRCx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFhLFNBQVMsd0JBQUMsZ0JBQUQsWUFBZ0Isd0JBQUMsTUFBRCxDQUFPOzs7O1dBQWlCOzs7OztDQUFJOzs7OztDQUM5RSx3QkFBQyxPQUFEO0VBQU8sTUFBSztFQUFJLFNBQVMsd0JBQUMsVUFBRDtHQUFVLElBQUc7R0FBUztFQUFTOzs7OztDQUFJOzs7OztBQUN4RDs7OztTQUNHOzs7O1NBQ1A7Ozs7UUFDaEIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9zdHlsZXMvc3R5bGVzLmNzc1wiO1xuaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgeyBCcm93c2VyUm91dGVyLCBOYXZpZ2F0ZSwgUm91dGUsIFJvdXRlcyB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuXG5pbXBvcnQgSG9tZSBmcm9tIFwiLi9wYWdlcy9ob21lLmpzeFwiO1xuaW1wb3J0IEF1dGhvcml6ZSBmcm9tIFwiLi9wYWdlcy9hdXRob3JpemUuanN4XCI7XG5pbXBvcnQgeyBnZXRBdXRoVG9rZW4gfSBmcm9tIFwiLi9zZXJ2aWNlcy9hcGlDbGllbnQuanNcIjtcblxuY29uc3QgUHJvdGVjdGVkUm91dGUgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gICAgY29uc3QgdG9rZW4gPSBnZXRBdXRoVG9rZW4oKTtcbiAgICByZXR1cm4gdG9rZW4gPyBjaGlsZHJlbiA6IDxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHJlcGxhY2UgLz47XG59O1xuXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSkucmVuZGVyKFxuICAgIDxTdHJpY3RNb2RlPlxuICAgICAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgICAgICAgIDxSb3V0ZXM+XG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PE5hdmlnYXRlIHRvPVwiL2xvZ2luXCIgcmVwbGFjZSAvPn0gLz5cbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxBdXRob3JpemUgLz59IC8+XG4gICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVnaXN0ZXJcIiBlbGVtZW50PXs8QXV0aG9yaXplIC8+fSAvPlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2Rhc2hib2FyZFwiIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT48SG9tZSAvPjwvUHJvdGVjdGVkUm91dGU+fSAvPlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiKlwiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9sb2dpblwiIHJlcGxhY2UgLz59IC8+XG4gICAgICAgICAgICA8L1JvdXRlcz5cbiAgICAgICAgPC9Ccm93c2VyUm91dGVyPlxuICAgIDwvU3RyaWN0TW9kZT5cbik7Il19