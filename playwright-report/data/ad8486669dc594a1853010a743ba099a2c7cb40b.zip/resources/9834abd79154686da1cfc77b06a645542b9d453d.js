import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SettingsPanel.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b4895507";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$();
const EMPTY_TASK_FORM = {
	title: "",
	description: "",
	dueDate: ""
};
const BACKGROUNDS = [
	{
		value: "plain",
		label: "Plain White",
		description: "Clean white background"
	},
	{
		value: "paper",
		label: "Warm Paper",
		description: "Gives background a paper-like texture"
	},
	{
		value: "greenery",
		label: "Soft Greenery",
		description: "Subtle green garden-like tones"
	},
	{
		value: "sunset",
		label: "Warm Sunset",
		description: "Muted peach and cream tones"
	},
	{
		value: "blue-grid",
		label: "Blue Grid",
		description: "Light blue notebook grid"
	}
];
export default function SettingsPanel({ background, onBackgroundChange, isYoutubePlayerEnabled = true, onYoutubePlayerToggle = () => {}, isTaskManagerOpen = false, taskForm = EMPTY_TASK_FORM, isCreatingTask = false, taskError = "", taskNotice = "", taskNoticeFading = false, onTaskManagerToggle = () => {}, onTaskManagerClose = () => {}, onTaskFormChange = () => {}, onCreateTask = (event) => event.preventDefault() }) {
	_s();
	const [isBackgroundOpen, setBackgroundOpen] = useState(false);
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "settings-panel",
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: `settings-shortcut settings-background-trigger${isBackgroundOpen ? " is-active" : ""}`,
				onClick: () => {
					onTaskManagerClose?.();
					setBackgroundOpen((open) => !open);
				},
				title: "Change Background",
				children: /* @__PURE__ */ _jsxDEV("span", { children: "B" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: `settings-shortcut settings-youtube-trigger${isYoutubePlayerEnabled ? " is-active" : ""}`,
				onClick: onYoutubePlayerToggle,
				title: isYoutubePlayerEnabled ? "Turn off YouTube music player" : "Turn on YouTube music player",
				children: /* @__PURE__ */ _jsxDEV("span", { children: "Y" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: `settings-shortcut settings-task-trigger${isTaskManagerOpen ? " is-active" : ""}`,
				onClick: () => {
					setBackgroundOpen(false);
					onTaskManagerToggle?.();
				},
				title: "Add a Task",
				children: /* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 13
			}, this),
			isBackgroundOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "background-selector",
				id: "background-selector",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "background-image-select",
						children: "Background Image"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("select", {
						id: "background-image-select",
						value: background,
						onChange: (event) => onBackgroundChange(event.target.value),
						children: BACKGROUNDS.map((option) => /* @__PURE__ */ _jsxDEV("option", {
							value: option.value,
							children: option.label
						}, option.value, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 29
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "background-selector-help",
						children: "Choose a look for your background."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 17
			}, this),
			isTaskManagerOpen && /* @__PURE__ */ _jsxDEV("section", {
				className: "task-manager-panel",
				id: "task-manager-panel",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "task-manager-header",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							id: "task-manager-heading",
							children: "Add a Task"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Enter the details for your new task." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "task-manager-close",
							onClick: onTaskManagerClose,
							children: "X"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 21
					}, this),
					taskError && /* @__PURE__ */ _jsxDEV("p", {
						className: "task-manager-feedback-error",
						role: "alert",
						children: taskError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 25
					}, this),
					taskNotice && /* @__PURE__ */ _jsxDEV("p", {
						className: `task-manager-feedback is-success auto-dismiss-notice${taskNoticeFading ? " is-fading" : ""}`,
						role: "status",
						children: taskNotice
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						className: "task-create-form",
						onSubmit: onCreateTask,
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "task-title",
								children: "Task Title"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: "new-task-title",
								name: "title",
								type: "text",
								value: taskForm.title,
								onChange: (event) => onTaskFormChange("title", event.target.value),
								maxLength: 150,
								required: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "new-task-description",
								children: ["Description ", /* @__PURE__ */ _jsxDEV("span", { children: "(optional)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 75
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: "new-task-description",
								name: "description",
								value: taskForm.description,
								onChange: (event) => onTaskFormChange("description", event.target.value),
								maxLength: 500,
								rows: 2
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "new-task-due-date",
								children: ["Due Date ", /* @__PURE__ */ _jsxDEV("span", { children: "(optional)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 69
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: "new-task-due-date",
								name: "dueDate",
								type: "date",
								value: taskForm.dueDate,
								onChange: (event) => onTaskFormChange("dueDate", event.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "task-manager-add-button",
								disabled: isCreatingTask,
								children: isCreatingTask ? "Adding..." : "Add Task"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 9
	}, this);
}
_s(SettingsPanel, "Z2K5UxuKS64Bn53I8nfh4wgE4eg=");
_c = SettingsPanel;
var _c;
$RefreshReg$(_c, "SettingsPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SettingsPanel.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsTUFBTSxrQkFBa0I7Q0FBRSxPQUFPO0NBQUksYUFBYTtDQUFJLFNBQVM7QUFBRztBQUVsRSxNQUFNLGNBQWM7Q0FDaEI7RUFBRSxPQUFPO0VBQVMsT0FBTztFQUFlLGFBQWE7Q0FBeUI7Q0FDOUU7RUFBRSxPQUFPO0VBQVMsT0FBTztFQUFjLGFBQWE7Q0FBdUM7Q0FDM0Y7RUFBRSxPQUFPO0VBQVksT0FBTztFQUFpQixhQUFZO0NBQWlDO0NBQzFGO0VBQUUsT0FBTztFQUFVLE9BQU87RUFBZSxhQUFhO0NBQThCO0NBQ3BGO0VBQUUsT0FBTztFQUFhLE9BQU87RUFBYSxhQUFhO0NBQTBCO0FBQ3JGO0FBRUEsZUFBZSxTQUFTLGNBQWMsRUFDbEMsWUFDQSxvQkFDQSx5QkFBeUIsTUFDekIsOEJBQThCLENBQUMsR0FDL0Isb0JBQW9CLE9BQ3BCLFdBQVcsaUJBQ1gsaUJBQWlCLE9BQ2pCLFlBQVksSUFDWixhQUFhLElBQ2IsbUJBQW1CLE9BQ25CLDRCQUE0QixDQUFDLEdBQzdCLDJCQUEyQixDQUFDLEdBQzVCLHlCQUF5QixDQUFDLEdBQzFCLGdCQUFnQixVQUFVLE1BQU0sZUFBZSxLQUNoRDs7Q0FDQyxNQUFNLENBQUMsa0JBQWtCLHFCQUFxQixTQUFTLEtBQUs7Q0FFNUQsT0FDSSx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQjtHQUNJLHdCQUFDLFVBQUQ7SUFDSSxNQUFLO0lBQ0wsV0FBVyxnREFBZ0QsbUJBQW1CLGVBQWU7SUFDN0YsZUFBZTtLQUNYLHFCQUFxQjtLQUNyQixtQkFBbUIsU0FBUyxDQUFDLElBQUk7SUFDckM7SUFDQSxPQUFNO2NBRU4sd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O0dBQ1Q7Ozs7O0dBRVIsd0JBQUMsVUFBRDtJQUNJLE1BQUs7SUFDTCxXQUFXLDZDQUE2Qyx5QkFBeUIsZUFBZTtJQUNoRyxTQUFTO0lBQ1QsT0FBTyx5QkFBeUIsa0NBQWtDO2NBRWxFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztHQUNUOzs7OztHQUVSLHdCQUFDLFVBQUQ7SUFDSSxNQUFLO0lBQ0wsV0FBVywwQ0FBMEMsb0JBQW9CLGVBQWU7SUFDeEYsZUFBZTtLQUNYLGtCQUFrQixLQUFLO0tBQ3ZCLHNCQUFzQjtJQUMxQjtJQUNBLE9BQU07Y0FFTix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7R0FDVDs7Ozs7R0FFUCxvQkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFzQixJQUFHO2NBQXhDO0tBQ0ksd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQTBCO0tBQXVCOzs7OztLQUNoRSx3QkFBQyxVQUFEO01BQ0ksSUFBRztNQUNILE9BQU87TUFDUCxXQUFXLFVBQVUsbUJBQW1CLE1BQU0sT0FBTyxLQUFLO2dCQUV6RCxZQUFZLEtBQUssV0FDZCx3QkFBQyxVQUFEO09BQTJCLE9BQU8sT0FBTztpQkFDcEMsT0FBTztNQUNKLEdBRkssT0FBTzs7OzthQUVaLENBQ1g7S0FDRzs7Ozs7S0FDUix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMkI7S0FFckM7Ozs7O0lBQ0Y7Ozs7OztHQUdSLHFCQUNHLHdCQUFDLFdBQUQ7SUFDSSxXQUFVO0lBQ1YsSUFBRztjQUZQO0tBSUksd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDSSx3QkFBQyxPQUFELGFBQ0ksd0JBQUMsTUFBRDtPQUFJLElBQUc7aUJBQXVCO01BQWM7Ozs7Z0JBQzVDLHdCQUFDLEtBQUQsWUFBRyx1Q0FBdUM7Ozs7Y0FDekM7Ozs7Z0JBQ0wsd0JBQUMsVUFBRDtPQUNJLE1BQUs7T0FDTCxXQUFVO09BQ1YsU0FBUztpQkFDWjtNQUVPOzs7O2NBQ1A7Ozs7OztLQUVKLGFBQ0csd0JBQUMsS0FBRDtNQUFHLFdBQVU7TUFBOEIsTUFBSztnQkFDM0M7S0FDRjs7Ozs7S0FFTixjQUNHLHdCQUFDLEtBQUQ7TUFBRyxXQUFXLHVEQUF1RCxtQkFBbUIsZUFBZTtNQUFNLE1BQUs7Z0JBQzdHO0tBQ0Y7Ozs7O0tBR1Asd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBbUIsVUFBVTtnQkFBN0M7T0FDSSx3QkFBQyxTQUFEO1FBQU8sU0FBUTtrQkFBYTtPQUFpQjs7Ozs7T0FDN0Msd0JBQUMsU0FBRDtRQUNJLElBQUc7UUFDSCxNQUFLO1FBQ0wsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLFVBQVUsaUJBQWlCLFNBQVMsTUFBTSxPQUFPLEtBQUs7UUFDakUsV0FBVztRQUNYO09BQ0g7Ozs7O09BRUQsd0JBQUMsU0FBRDtRQUFPLFNBQVE7a0JBQWYsQ0FBc0MsZ0JBQVksd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2dCQUFROzs7Ozs7T0FDaEYsd0JBQUMsWUFBRDtRQUNJLElBQUc7UUFDSCxNQUFLO1FBQ0wsT0FBTyxTQUFTO1FBQ2hCLFdBQVcsVUFBVSxpQkFBaUIsZUFBZSxNQUFNLE9BQU8sS0FBSztRQUN2RSxXQUFXO1FBQ1gsTUFBTTtPQUNUOzs7OztPQUVELHdCQUFDLFNBQUQ7UUFBTyxTQUFRO2tCQUFmLENBQW1DLGFBQVMsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2dCQUFROzs7Ozs7T0FDMUUsd0JBQUMsU0FBRDtRQUNJLElBQUc7UUFDSCxNQUFLO1FBQ0wsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLFVBQVUsaUJBQWlCLFdBQVcsTUFBTSxPQUFPLEtBQUs7T0FDdEU7Ozs7O09BRUQsd0JBQUMsVUFBRDtRQUNJLE1BQUs7UUFDTCxXQUFVO1FBQ1YsVUFBVTtrQkFFVCxpQkFBaUIsY0FBYztPQUM1Qjs7Ozs7TUFDTjs7Ozs7O0lBQ0Q7Ozs7OztFQUVWOzs7Ozs7QUFFZiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXR0aW5nc1BhbmVsLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcblxuY29uc3QgRU1QVFlfVEFTS19GT1JNID0geyB0aXRsZTogJycsIGRlc2NyaXB0aW9uOiAnJywgZHVlRGF0ZTogJycgfTtcblxuY29uc3QgQkFDS0dST1VORFMgPSBbXG4gICAgeyB2YWx1ZTogJ3BsYWluJywgbGFiZWw6ICdQbGFpbiBXaGl0ZScsIGRlc2NyaXB0aW9uOiAnQ2xlYW4gd2hpdGUgYmFja2dyb3VuZCcgfSxcbiAgICB7IHZhbHVlOiAncGFwZXInLCBsYWJlbDogJ1dhcm0gUGFwZXInLCBkZXNjcmlwdGlvbjogJ0dpdmVzIGJhY2tncm91bmQgYSBwYXBlci1saWtlIHRleHR1cmUnfSxcbiAgICB7IHZhbHVlOiAnZ3JlZW5lcnknLCBsYWJlbDogJ1NvZnQgR3JlZW5lcnknLCBkZXNjcmlwdGlvbjonU3VidGxlIGdyZWVuIGdhcmRlbi1saWtlIHRvbmVzJyB9LFxuICAgIHsgdmFsdWU6ICdzdW5zZXQnLCBsYWJlbDogJ1dhcm0gU3Vuc2V0JywgZGVzY3JpcHRpb246ICdNdXRlZCBwZWFjaCBhbmQgY3JlYW0gdG9uZXMnIH0sXG4gICAgeyB2YWx1ZTogJ2JsdWUtZ3JpZCcsIGxhYmVsOiAnQmx1ZSBHcmlkJywgZGVzY3JpcHRpb246ICdMaWdodCBibHVlIG5vdGVib29rIGdyaWQnfVxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2V0dGluZ3NQYW5lbCh7XG4gICAgYmFja2dyb3VuZCxcbiAgICBvbkJhY2tncm91bmRDaGFuZ2UsXG4gICAgaXNZb3V0dWJlUGxheWVyRW5hYmxlZCA9IHRydWUsXG4gICAgb25Zb3V0dWJlUGxheWVyVG9nZ2xlID0gKCkgPT4ge30sXG4gICAgaXNUYXNrTWFuYWdlck9wZW4gPSBmYWxzZSxcbiAgICB0YXNrRm9ybSA9IEVNUFRZX1RBU0tfRk9STSxcbiAgICBpc0NyZWF0aW5nVGFzayA9IGZhbHNlLFxuICAgIHRhc2tFcnJvciA9ICcnLFxuICAgIHRhc2tOb3RpY2UgPSAnJyxcbiAgICB0YXNrTm90aWNlRmFkaW5nID0gZmFsc2UsXG4gICAgb25UYXNrTWFuYWdlclRvZ2dsZSA9ICgpID0+IHt9LFxuICAgIG9uVGFza01hbmFnZXJDbG9zZSA9ICgpID0+IHt9LFxuICAgIG9uVGFza0Zvcm1DaGFuZ2UgPSAoKSA9PiB7fSxcbiAgICBvbkNyZWF0ZVRhc2sgPSAoZXZlbnQpID0+IGV2ZW50LnByZXZlbnREZWZhdWx0KCksXG59KSB7XG4gICAgY29uc3QgW2lzQmFja2dyb3VuZE9wZW4sIHNldEJhY2tncm91bmRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJzZXR0aW5ncy1wYW5lbFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHNldHRpbmdzLXNob3J0Y3V0IHNldHRpbmdzLWJhY2tncm91bmQtdHJpZ2dlciR7aXNCYWNrZ3JvdW5kT3BlbiA/ICcgaXMtYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBvblRhc2tNYW5hZ2VyQ2xvc2U/LigpO1xuICAgICAgICAgICAgICAgICAgICBzZXRCYWNrZ3JvdW5kT3Blbigob3BlbikgPT4gIW9wZW4pXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNoYW5nZSBCYWNrZ3JvdW5kXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj5CPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzZXR0aW5ncy1zaG9ydGN1dCBzZXR0aW5ncy15b3V0dWJlLXRyaWdnZXIke2lzWW91dHViZVBsYXllckVuYWJsZWQgPyAnIGlzLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uWW91dHViZVBsYXllclRvZ2dsZX1cbiAgICAgICAgICAgICAgICB0aXRsZT17aXNZb3V0dWJlUGxheWVyRW5hYmxlZCA/ICdUdXJuIG9mZiBZb3VUdWJlIG11c2ljIHBsYXllcicgOiAnVHVybiBvbiBZb3VUdWJlIG11c2ljIHBsYXllcid9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+WTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2V0dGluZ3Mtc2hvcnRjdXQgc2V0dGluZ3MtdGFzay10cmlnZ2VyJHtpc1Rhc2tNYW5hZ2VyT3BlbiA/ICcgaXMtYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRCYWNrZ3JvdW5kT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIG9uVGFza01hbmFnZXJUb2dnbGU/LigpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgdGl0bGU9XCJBZGQgYSBUYXNrXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHtpc0JhY2tncm91bmRPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhY2tncm91bmQtc2VsZWN0b3JcIiBpZD1cImJhY2tncm91bmQtc2VsZWN0b3JcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJiYWNrZ3JvdW5kLWltYWdlLXNlbGVjdFwiPkJhY2tncm91bmQgSW1hZ2U8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImJhY2tncm91bmQtaW1hZ2Utc2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiYWNrZ3JvdW5kfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25CYWNrZ3JvdW5kQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtCQUNLR1JPVU5EUy5tYXAoKG9wdGlvbikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJiYWNrZ3JvdW5kLXNlbGVjdG9yLWhlbHBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIENob29zZSBhIGxvb2sgZm9yIHlvdXIgYmFja2dyb3VuZC5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2lzVGFza01hbmFnZXJPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8c2VjdGlvblxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItcGFuZWxcIlxuICAgICAgICAgICAgICAgICAgICBpZD1cInRhc2stbWFuYWdlci1wYW5lbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbWFuYWdlci1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGlkPVwidGFzay1tYW5hZ2VyLWhlYWRpbmdcIj5BZGQgYSBUYXNrPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5FbnRlciB0aGUgZGV0YWlscyBmb3IgeW91ciBuZXcgdGFzay48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItY2xvc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uVGFza01hbmFnZXJDbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBYXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge3Rhc2tFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItZmVlZGJhY2stZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFza0Vycm9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7dGFza05vdGljZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0YXNrLW1hbmFnZXItZmVlZGJhY2sgaXMtc3VjY2VzcyBhdXRvLWRpc21pc3Mtbm90aWNlJHt0YXNrTm90aWNlRmFkaW5nID8gJyBpcy1mYWRpbmcnIDogJyd9YH0gcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrTm90aWNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInRhc2stY3JlYXRlLWZvcm1cIiBvblN1Ym1pdD17b25DcmVhdGVUYXNrfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidGFzay10aXRsZVwiPlRhc2sgVGl0bGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuZXctdGFzay10aXRsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uVGFza0Zvcm1DaGFuZ2UoJ3RpdGxlJywgZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezE1MH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctdGFzay1kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uIDxzcGFuPihvcHRpb25hbCk8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmV3LXRhc2stZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkZXNjcmlwdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uVGFza0Zvcm1DaGFuZ2UoJ2Rlc2NyaXB0aW9uJywgZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezUwMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctdGFzay1kdWUtZGF0ZVwiPkR1ZSBEYXRlIDxzcGFuPihvcHRpb25hbCk8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmV3LXRhc2stZHVlLWRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkdWVEYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmR1ZURhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25UYXNrRm9ybUNoYW5nZSgnZHVlRGF0ZScsIGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFzay1tYW5hZ2VyLWFkZC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0NyZWF0aW5nVGFza31cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDcmVhdGluZ1Rhc2sgPyAnQWRkaW5nLi4uJyA6ICdBZGQgVGFzayd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvYXNpZGU+XG4gICAgKTtcbn0iXX0=