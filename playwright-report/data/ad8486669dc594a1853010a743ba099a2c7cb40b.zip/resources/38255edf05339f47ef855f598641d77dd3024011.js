import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StartSessionButton.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/StartSessionButton.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
export default function StartSessionButton({ onClick, loading = false, disabled = false }) {
	return /* @__PURE__ */ _jsxDEV("button", {
		className: "start-session",
		type: "button",
		onClick,
		disabled: disabled || loading,
		children: /* @__PURE__ */ _jsxDEV("span", { children: loading ? "Starting session..." : "Start Session" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 3,
		columnNumber: 9
	}, this);
}
_c = StartSessionButton;
var _c;
$RefreshReg$(_c, "StartSessionButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/StartSessionButton.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/StartSessionButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/StartSessionButton.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/StartSessionButton.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLFNBQVMsbUJBQW1CLEVBQUUsU0FBUyxVQUFVLE9BQU8sV0FBVyxTQUFTO0NBQ3ZGLE9BQ0ksd0JBQUMsVUFBRDtFQUNJLFdBQVU7RUFDVixNQUFLO0VBQ0k7RUFDVCxVQUFVLFlBQVk7WUFFdEIsd0JBQUMsUUFBRCxZQUNLLFVBQVUsd0JBQXdCLGdCQUNqQzs7Ozs7Q0FDRjs7Ozs7QUFFaEIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhcnRTZXNzaW9uQnV0dG9uLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdGFydFNlc3Npb25CdXR0b24oeyBvbkNsaWNrLCBsb2FkaW5nID0gZmFsc2UsIGRpc2FibGVkID0gZmFsc2UgfSkge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0YXJ0LXNlc3Npb25cIlxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2Rpc2FibGVkIHx8IGxvYWRpbmd9XG4gICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gJ1N0YXJ0aW5nIHNlc3Npb24uLi4nIDogJ1N0YXJ0IFNlc3Npb24nfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICApO1xufVxuIl19