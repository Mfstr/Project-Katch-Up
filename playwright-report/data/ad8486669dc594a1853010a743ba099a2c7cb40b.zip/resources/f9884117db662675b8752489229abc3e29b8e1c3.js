import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/InsightAlert.jsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b4895507";
import { ToastContainer, toast } from "/node_modules/.vite/deps/react-toastify.js?v=b4895507";
import "/node_modules/react-toastify/dist/ReactToastify.css";
import { getTimerInsights, updateTimerPreferences } from "/src/services/apiClient.js";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/InsightAlert.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
function getSeverityLabel(severity) {
	switch (severity) {
		case "warning": return "ATTENTION";
		case "tip": return "PRODUCTIVITY TIP";
		default: return "SMART INSIGHT";
	}
}
function getPreferenceUpdate(suggestedAction) {
	if (!suggestedAction || suggestedAction.value == null) return null;
	const targetToPreferenceKey = {
		break_interval: "breakInterval",
		breakInterval: "breakInterval",
		focus_interval: "focusInterval",
		focusInterval: "focusInterval",
		pomodoro_cycles: "pomodoroCycles",
		pomodoroCycles: "pomodoroCycles"
	};
	const preferenceKey = targetToPreferenceKey[suggestedAction.target];
	const value = Number(suggestedAction.value);
	if (!preferenceKey || !Number.isInteger(value) || value < 1 || value > 180) {
		return null;
	}
	return { [preferenceKey]: value };
}
function getSuggestedActionLabel(suggestedAction) {
	const prefereenceUpdate = getPreferenceUpdate(suggestedAction);
	if (!prefereenceUpdate) return "";
	const targetLabels = {
		break_interval: "Suggested break interval:",
		breakInterval: "Suggested break interval:",
		focus_interval: "Suggested focus interval:",
		focusInterval: "Suggested focus interval:",
		pomodoro_cycles: "Sessions before a long break:",
		pomodoroCycles: "Sessions before a long break:"
	};
	const targetLabel = targetLabels[suggestedAction.target] || "Suggested Setting";
	const unit = suggestedAction.unit ? ` ${suggestedAction.unit}` : "";
	return `${targetLabel}: ${suggestedAction.value}${unit}`;
}
function InsightToastContent({ recommendation }) {
	_s();
	const actionLabel = getSuggestedActionLabel(recommendation.suggestedAction);
	const preferenceUpdate = getPreferenceUpdate(recommendation.suggestedAction);
	const [applyState, setApplyState] = useState("idle");
	const [applyError, setApplyError] = useState("");
	const handleApply = async () => {
		if (!preferenceUpdate || applyState !== "idle") return;
		setApplyState("applying");
		setApplyError("");
		try {
			await updateTimerPreferences(preferenceUpdate);
			setApplyState("applied");
		} catch (error) {
			setApplyState("idle");
			setApplyError(error instanceof Error ? error.message : "Unable to apply the recommendation.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "insight-toast-content",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "insight-toast-eyebrow",
				children: getSeverityLabel(recommendation.severity)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("strong", {
				className: "insight-toast-title",
				children: recommendation.title || "A new productivity insight"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 13
			}, this),
			recommendation.message && /* @__PURE__ */ _jsxDEV("p", {
				className: "insight-toast-message",
				children: recommendation.message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 17
			}, this),
			actionLabel && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "insight-toast-suggestion",
					children: actionLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "insight-toast-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: `insight-toast-apply-button${applyState === "applied" ? " is-applied" : ""}`,
						onClick: handleApply,
						disabled: applyState !== "idle",
						children: [
							applyState === "applying" && "Applying...",
							applyState === "applied" && "Applied",
							applyState === "idle" && "Apply"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 25
					}, this), applyState === "applied" && /* @__PURE__ */ _jsxDEV("span", {
						className: "insight-toast-apply-success",
						role: "status",
						children: "Preference successfully saved!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 29
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 21
				}, this),
				applyError && /* @__PURE__ */ _jsxDEV("p", {
					className: "insight-toast-apply-error",
					role: "alert",
					children: applyError
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 9
	}, this);
}
_s(InsightToastContent, "Kxb/07q5dvq0E5rO7C2+6fMj6Rk=");
_c = InsightToastContent;
function showInsightToast(recommendation, index) {
	const toastOptions = {
		toastId: `katchup-insight-${recommendation.id ?? recommendation.title ?? index}`,
		className: "insight-toast-shell",
		autoClose: 8500,
		closeOnClick: false,
		delay: index * 650
	};
	const content = /* @__PURE__ */ _jsxDEV(InsightToastContent, { recommendation }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 131,
		columnNumber: 21
	}, this);
	switch (recommendation.severity) {
		case "warning":
			toast.warn(content, toastOptions);
			break;
		case "tip":
			toast.success(content, toastOptions);
			break;
		default:
			toast.info(content, toastOptions);
			break;
	}
}
export default function InsightAlert() {
	_s2();
	const displayedRecommendationsRef = useRef(new Set());
	useEffect(() => {
		let isCurrent = true;
		const loadRecommendations = async () => {
			try {
				const insights = await getTimerInsights({ days: 7 });
				if (!isCurrent || !Array.isArray(insights?.recommendations)) return;
				insights.recommendations.forEach((recommendation, index) => {
					if (!recommendation || typeof recommendation !== "object") return;
					const hasTitle = typeof recommendation.title === "string" && recommendation.title.trim();
					const hasMessage = typeof recommendation.message === "string" && recommendation.message.trim();
					if (!hasTitle && !hasMessage) return;
					const recommendationKey = String(recommendation.id ?? `${recommendation.title}-${recommendation.message}`);
					if (displayedRecommendationsRef.current.has(recommendationKey)) return;
					displayedRecommendationsRef.current.add(recommendationKey);
					showInsightToast(recommendation, index);
				});
			} catch (requestError) {
				console.warn("Unable to load recommendations.", requestError);
			}
		};
		loadRecommendations();
		return () => {
			isCurrent = false;
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV(ToastContainer, {
		className: "insight-toast-container",
		position: "top-left",
		autoClose: 8500,
		closeOnClick: false,
		newestOnTop: true,
		pauseOnFocusLoss: true,
		pauseOnHover: true,
		draggable: true,
		limit: 3,
		theme: "light"
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 185,
		columnNumber: 9
	}, this);
}
_s2(InsightAlert, "ksuQWBOe/jgQIxP7adNoy4SXwpg=");
_c2 = InsightAlert;
var _c, _c2;
$RefreshReg$(_c, "InsightToastContent");
$RefreshReg$(_c2, "InsightAlert");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/InsightAlert.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/InsightAlert.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/InsightAlert.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/InsightAlert.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsZ0JBQWdCLGFBQWE7QUFDdEMsT0FBTztBQUVQLFNBQVMsa0JBQWtCLDhCQUE4Qjs7OztBQUd6RCxTQUFTLGlCQUFpQixVQUFVO0NBQ2hDLFFBQVEsVUFBUjtFQUNJLEtBQUssV0FDRCxPQUFPO0VBQ1gsS0FBSyxPQUNELE9BQU87RUFDWCxTQUNJLE9BQU87Q0FDZjtBQUNKO0FBRUEsU0FBUyxvQkFBb0IsaUJBQWlCO0NBQzFDLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLFNBQVMsTUFBTSxPQUFPO0NBRTlELE1BQU0sd0JBQXdCO0VBQzFCLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsZ0JBQWdCO0NBQ3BCO0NBQ0EsTUFBTSxnQkFBZ0Isc0JBQXNCLGdCQUFnQjtDQUM1RCxNQUFNLFFBQVEsT0FBTyxnQkFBZ0IsS0FBSztDQUUxQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsT0FBTyxVQUFVLEtBQUssS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLO0VBQ3hFLE9BQU87Q0FDWDtDQUVBLE9BQU8sR0FBRyxnQkFBZ0IsTUFBTTtBQUNwQztBQUVBLFNBQVMsd0JBQXdCLGlCQUFpQjtDQUM5QyxNQUFNLG9CQUFvQixvQkFBb0IsZUFBZTtDQUM3RCxJQUFJLENBQUMsbUJBQW1CLE9BQU87Q0FFL0IsTUFBTSxlQUFjO0VBQ2hCLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsZ0JBQWdCO0NBQ3BCO0NBRUEsTUFBTSxjQUFjLGFBQWEsZ0JBQWdCLFdBQVc7Q0FDNUQsTUFBTSxPQUFPLGdCQUFnQixPQUFPLElBQUksZ0JBQWdCLFNBQVM7Q0FFakUsT0FBTyxHQUFHLFlBQVksSUFBSSxnQkFBZ0IsUUFBUTtBQUN0RDtBQUVBLFNBQVMsb0JBQW9CLEVBQUUsa0JBQWtCOztDQUM3QyxNQUFNLGNBQWMsd0JBQXdCLGVBQWUsZUFBZTtDQUMxRSxNQUFNLG1CQUFtQixvQkFBb0IsZUFBZSxlQUFlO0NBQzNFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLE1BQU07Q0FDbkQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUUvQyxNQUFNLGNBQWMsWUFBWTtFQUM1QixJQUFJLENBQUMsb0JBQW9CLGVBQWUsUUFBUTtFQUVoRCxjQUFjLFVBQVU7RUFDeEIsY0FBYyxFQUFFO0VBRWhCLElBQUk7R0FDQSxNQUFNLHVCQUF1QixnQkFBZ0I7R0FDN0MsY0FBYyxTQUFTO0VBQzNCLFNBQVMsT0FBTztHQUNaLGNBQWMsTUFBTTtHQUNwQixjQUFjLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxxQ0FBcUM7RUFDaEc7Q0FDSjtDQUVBLE9BQ0ksd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNJLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ1gsaUJBQWlCLGVBQWUsUUFBUTtHQUN2Qzs7Ozs7R0FDTix3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUNiLGVBQWUsU0FBUztHQUNyQjs7Ozs7R0FDUCxlQUFlLFdBQ1osd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBeUIsZUFBZTtHQUFXOzs7OztHQUVuRSxlQUNHO0lBQ0ksd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBNEI7SUFBa0I7Ozs7O0lBQzlELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDSSx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLFdBQVcsNkJBQTZCLGVBQWUsWUFBWSxnQkFBZ0I7TUFDbkYsU0FBUztNQUNULFVBQVUsZUFBZTtnQkFKN0I7T0FNSyxlQUFlLGNBQWM7T0FDN0IsZUFBZSxhQUFhO09BQzVCLGVBQWUsVUFBVTtNQUN0Qjs7Ozs7ZUFDUCxlQUFlLGFBQ1osd0JBQUMsUUFBRDtNQUFNLFdBQVU7TUFBOEIsTUFBSztnQkFBUztLQUV0RDs7OzthQUVUOzs7Ozs7SUFDSixjQUNHLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO0tBQTRCLE1BQUs7ZUFDekM7SUFDRjs7Ozs7R0FFVDs7Ozs7RUFFTDs7Ozs7O0FBRWI7OztBQUVBLFNBQVMsaUJBQWlCLGdCQUFnQixPQUFPO0NBQzdDLE1BQU0sZUFBZTtFQUNqQixTQUFTLG1CQUFtQixlQUFlLE1BQU0sZUFBZSxTQUFTO0VBQ3pFLFdBQVc7RUFDWCxXQUFXO0VBQ1gsY0FBYztFQUNkLE9BQU8sUUFBUTtDQUNuQjtDQUVBLE1BQU0sVUFBVSx3QkFBQyxxQkFBRCxFQUFxQyxlQUFpQjs7Ozs7Q0FFdEUsUUFBUSxlQUFlLFVBQXZCO0VBQ0ksS0FBSztHQUNELE1BQU0sS0FBSyxTQUFTLFlBQVk7R0FDaEM7RUFDSixLQUFLO0dBQ0QsTUFBTSxRQUFRLFNBQVMsWUFBWTtHQUNuQztFQUNKO0dBQ0ksTUFBTSxLQUFLLFNBQVMsWUFBWTtHQUNoQztDQUNSO0FBQ0o7QUFFQSxlQUFlLFNBQVMsZUFBZTs7Q0FDbkMsTUFBTSw4QkFBOEIsT0FBTyxJQUFJLElBQUksQ0FBQztDQUVwRCxnQkFBZ0I7RUFDWixJQUFJLFlBQVk7RUFFaEIsTUFBTSxzQkFBc0IsWUFBWTtHQUNwQyxJQUFJO0lBQ0EsTUFBTSxXQUFXLE1BQU0saUJBQWlCLEVBQUUsTUFBTSxFQUFFLENBQUM7SUFDbkQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLFFBQVEsVUFBVSxlQUFlLEdBQUc7SUFFN0QsU0FBUyxnQkFBZ0IsU0FBUyxnQkFBZ0IsVUFBVTtLQUN4RCxJQUFJLENBQUMsa0JBQWtCLE9BQU8sbUJBQW1CLFVBQVU7S0FFM0QsTUFBTSxXQUFXLE9BQU8sZUFBZSxVQUFVLFlBQVksZUFBZSxNQUFNLEtBQUs7S0FDdkYsTUFBTSxhQUFhLE9BQU8sZUFBZSxZQUFZLFlBQVksZUFBZSxRQUFRLEtBQUs7S0FDN0YsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZO0tBRTlCLE1BQU0sb0JBQW9CLE9BQ3RCLGVBQWUsTUFBTSxHQUFHLGVBQWUsTUFBTSxHQUFHLGVBQWUsU0FDbkU7S0FDQSxJQUFJLDRCQUE0QixRQUFRLElBQUksaUJBQWlCLEdBQUc7S0FFaEUsNEJBQTRCLFFBQVEsSUFBSSxpQkFBaUI7S0FDekQsaUJBQWlCLGdCQUFnQixLQUFLO0lBQzFDLENBQUM7R0FDTCxTQUFTLGNBQWM7SUFDZixRQUFRLEtBQUssbUNBQW1DLFlBQVk7R0FDcEU7RUFDSjtFQUVBLG9CQUFvQjtFQUVwQixhQUFhO0dBQ1QsWUFBWTtFQUNoQjtDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBRUwsT0FDSSx3QkFBQyxnQkFBRDtFQUNJLFdBQVU7RUFDVixVQUFTO0VBQ1QsV0FBVztFQUNYLGNBQWM7RUFDZDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE9BQU87RUFDUCxPQUFNO0NBQ1Q7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW5zaWdodEFsZXJ0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciwgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSc7XG5pbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xuXG5pbXBvcnQgeyBnZXRUaW1lckluc2lnaHRzLCB1cGRhdGVUaW1lclByZWZlcmVuY2VzIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpQ2xpZW50LmpzJztcblxuXG5mdW5jdGlvbiBnZXRTZXZlcml0eUxhYmVsKHNldmVyaXR5KSB7XG4gICAgc3dpdGNoIChzZXZlcml0eSkge1xuICAgICAgICBjYXNlICd3YXJuaW5nJzpcbiAgICAgICAgICAgIHJldHVybiAnQVRURU5USU9OJztcbiAgICAgICAgY2FzZSAndGlwJzpcbiAgICAgICAgICAgIHJldHVybiAnUFJPRFVDVElWSVRZIFRJUCc7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gJ1NNQVJUIElOU0lHSFQnO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gZ2V0UHJlZmVyZW5jZVVwZGF0ZShzdWdnZXN0ZWRBY3Rpb24pIHtcbiAgICBpZiAoIXN1Z2dlc3RlZEFjdGlvbiB8fCBzdWdnZXN0ZWRBY3Rpb24udmFsdWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB0YXJnZXRUb1ByZWZlcmVuY2VLZXkgPSB7XG4gICAgICAgIGJyZWFrX2ludGVydmFsOiAnYnJlYWtJbnRlcnZhbCcsXG4gICAgICAgIGJyZWFrSW50ZXJ2YWw6ICdicmVha0ludGVydmFsJyxcbiAgICAgICAgZm9jdXNfaW50ZXJ2YWw6ICdmb2N1c0ludGVydmFsJyxcbiAgICAgICAgZm9jdXNJbnRlcnZhbDogJ2ZvY3VzSW50ZXJ2YWwnLFxuICAgICAgICBwb21vZG9yb19jeWNsZXM6ICdwb21vZG9yb0N5Y2xlcycsXG4gICAgICAgIHBvbW9kb3JvQ3ljbGVzOiAncG9tb2Rvcm9DeWNsZXMnLFxuICAgIH07XG4gICAgY29uc3QgcHJlZmVyZW5jZUtleSA9IHRhcmdldFRvUHJlZmVyZW5jZUtleVtzdWdnZXN0ZWRBY3Rpb24udGFyZ2V0XTtcbiAgICBjb25zdCB2YWx1ZSA9IE51bWJlcihzdWdnZXN0ZWRBY3Rpb24udmFsdWUpO1xuXG4gICAgaWYgKCFwcmVmZXJlbmNlS2V5IHx8ICFOdW1iZXIuaXNJbnRlZ2VyKHZhbHVlKSB8fCB2YWx1ZSA8IDEgfHwgdmFsdWUgPiAxODApIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgW3ByZWZlcmVuY2VLZXldOiB2YWx1ZSB9O1xufVxuXG5mdW5jdGlvbiBnZXRTdWdnZXN0ZWRBY3Rpb25MYWJlbChzdWdnZXN0ZWRBY3Rpb24pIHtcbiAgICBjb25zdCBwcmVmZXJlZW5jZVVwZGF0ZSA9IGdldFByZWZlcmVuY2VVcGRhdGUoc3VnZ2VzdGVkQWN0aW9uKTtcbiAgICBpZiAoIXByZWZlcmVlbmNlVXBkYXRlKSByZXR1cm4gJyc7XG5cbiAgICBjb25zdCB0YXJnZXRMYWJlbHMgPXtcbiAgICAgICAgYnJlYWtfaW50ZXJ2YWw6ICdTdWdnZXN0ZWQgYnJlYWsgaW50ZXJ2YWw6JyxcbiAgICAgICAgYnJlYWtJbnRlcnZhbDogJ1N1Z2dlc3RlZCBicmVhayBpbnRlcnZhbDonLFxuICAgICAgICBmb2N1c19pbnRlcnZhbDogJ1N1Z2dlc3RlZCBmb2N1cyBpbnRlcnZhbDonLFxuICAgICAgICBmb2N1c0ludGVydmFsOiAnU3VnZ2VzdGVkIGZvY3VzIGludGVydmFsOicsXG4gICAgICAgIHBvbW9kb3JvX2N5Y2xlczogXCJTZXNzaW9ucyBiZWZvcmUgYSBsb25nIGJyZWFrOlwiLFxuICAgICAgICBwb21vZG9yb0N5Y2xlczogXCJTZXNzaW9ucyBiZWZvcmUgYSBsb25nIGJyZWFrOlwiLFxuICAgIH07XG5cbiAgICBjb25zdCB0YXJnZXRMYWJlbCA9IHRhcmdldExhYmVsc1tzdWdnZXN0ZWRBY3Rpb24udGFyZ2V0XSB8fCAnU3VnZ2VzdGVkIFNldHRpbmcnO1xuICAgIGNvbnN0IHVuaXQgPSBzdWdnZXN0ZWRBY3Rpb24udW5pdCA/IGAgJHtzdWdnZXN0ZWRBY3Rpb24udW5pdH1gIDogJyc7XG5cbiAgICByZXR1cm4gYCR7dGFyZ2V0TGFiZWx9OiAke3N1Z2dlc3RlZEFjdGlvbi52YWx1ZX0ke3VuaXR9YDtcbn1cblxuZnVuY3Rpb24gSW5zaWdodFRvYXN0Q29udGVudCh7IHJlY29tbWVuZGF0aW9uIH0pIHtcbiAgICBjb25zdCBhY3Rpb25MYWJlbCA9IGdldFN1Z2dlc3RlZEFjdGlvbkxhYmVsKHJlY29tbWVuZGF0aW9uLnN1Z2dlc3RlZEFjdGlvbik7XG4gICAgY29uc3QgcHJlZmVyZW5jZVVwZGF0ZSA9IGdldFByZWZlcmVuY2VVcGRhdGUocmVjb21tZW5kYXRpb24uc3VnZ2VzdGVkQWN0aW9uKTtcbiAgICBjb25zdCBbYXBwbHlTdGF0ZSwgc2V0QXBwbHlTdGF0ZV0gPSB1c2VTdGF0ZSgnaWRsZScpO1xuICAgIGNvbnN0IFthcHBseUVycm9yLCBzZXRBcHBseUVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICAgIGNvbnN0IGhhbmRsZUFwcGx5ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBpZiAoIXByZWZlcmVuY2VVcGRhdGUgfHwgYXBwbHlTdGF0ZSAhPT0gJ2lkbGUnKSByZXR1cm47XG5cbiAgICAgICAgc2V0QXBwbHlTdGF0ZSgnYXBwbHlpbmcnKTtcbiAgICAgICAgc2V0QXBwbHlFcnJvcignJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHVwZGF0ZVRpbWVyUHJlZmVyZW5jZXMocHJlZmVyZW5jZVVwZGF0ZSk7XG4gICAgICAgICAgICBzZXRBcHBseVN0YXRlKCdhcHBsaWVkJyk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBzZXRBcHBseVN0YXRlKCdpZGxlJyk7XG4gICAgICAgICAgICBzZXRBcHBseUVycm9yKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1VuYWJsZSB0byBhcHBseSB0aGUgcmVjb21tZW5kYXRpb24uJyk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnNpZ2h0LXRvYXN0LWNvbnRlbnRcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImluc2lnaHQtdG9hc3QtZXllYnJvd1wiPlxuICAgICAgICAgICAgICAgIHtnZXRTZXZlcml0eUxhYmVsKHJlY29tbWVuZGF0aW9uLnNldmVyaXR5KX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwiaW5zaWdodC10b2FzdC10aXRsZVwiPlxuICAgICAgICAgICAgICAgIHtyZWNvbW1lbmRhdGlvbi50aXRsZSB8fCAnQSBuZXcgcHJvZHVjdGl2aXR5IGluc2lnaHQnfVxuICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICB7cmVjb21tZW5kYXRpb24ubWVzc2FnZSAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaW5zaWdodC10b2FzdC1tZXNzYWdlXCI+e3JlY29tbWVuZGF0aW9uLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHthY3Rpb25MYWJlbCAmJiAoXG4gICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5zaWdodC10b2FzdC1zdWdnZXN0aW9uXCI+e2FjdGlvbkxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbnNpZ2h0LXRvYXN0LWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbnNpZ2h0LXRvYXN0LWFwcGx5LWJ1dHRvbiR7YXBwbHlTdGF0ZSA9PT0gJ2FwcGxpZWQnID8gJyBpcy1hcHBsaWVkJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2FwcGx5U3RhdGUgIT09ICdpZGxlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXBwbHlTdGF0ZSA9PT0gJ2FwcGx5aW5nJyAmJiAnQXBwbHlpbmcuLi4nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBseVN0YXRlID09PSAnYXBwbGllZCcgJiYgJ0FwcGxpZWQnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBseVN0YXRlID09PSAnaWRsZScgJiYgJ0FwcGx5J31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcGx5U3RhdGUgPT09ICdhcHBsaWVkJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5zaWdodC10b2FzdC1hcHBseS1zdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmVmZXJlbmNlIHN1Y2Nlc3NmdWxseSBzYXZlZCFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAge2FwcGx5RXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiaW5zaWdodC10b2FzdC1hcHBseS1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthcHBseUVycm9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn1cblxuZnVuY3Rpb24gc2hvd0luc2lnaHRUb2FzdChyZWNvbW1lbmRhdGlvbiwgaW5kZXgpIHtcbiAgICBjb25zdCB0b2FzdE9wdGlvbnMgPSB7XG4gICAgICAgIHRvYXN0SWQ6IGBrYXRjaHVwLWluc2lnaHQtJHtyZWNvbW1lbmRhdGlvbi5pZCA/PyByZWNvbW1lbmRhdGlvbi50aXRsZSA/PyBpbmRleH1gLFxuICAgICAgICBjbGFzc05hbWU6ICdpbnNpZ2h0LXRvYXN0LXNoZWxsJyxcbiAgICAgICAgYXV0b0Nsb3NlOiA4NTAwLFxuICAgICAgICBjbG9zZU9uQ2xpY2s6IGZhbHNlLFxuICAgICAgICBkZWxheTogaW5kZXggKiA2NTAsXG4gICAgfTtcblxuICAgIGNvbnN0IGNvbnRlbnQgPSA8SW5zaWdodFRvYXN0Q29udGVudCByZWNvbW1lbmRhdGlvbj17cmVjb21tZW5kYXRpb259IC8+O1xuXG4gICAgc3dpdGNoIChyZWNvbW1lbmRhdGlvbi5zZXZlcml0eSkge1xuICAgICAgICBjYXNlICd3YXJuaW5nJzpcbiAgICAgICAgICAgIHRvYXN0Lndhcm4oY29udGVudCwgdG9hc3RPcHRpb25zKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aXAnOlxuICAgICAgICAgICAgdG9hc3Quc3VjY2Vzcyhjb250ZW50LCB0b2FzdE9wdGlvbnMpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0b2FzdC5pbmZvKGNvbnRlbnQsIHRvYXN0T3B0aW9ucyk7XG4gICAgICAgICAgICBicmVhaztcbiAgICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEluc2lnaHRBbGVydCgpIHtcbiAgICBjb25zdCBkaXNwbGF5ZWRSZWNvbW1lbmRhdGlvbnNSZWYgPSB1c2VSZWYobmV3IFNldCgpKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGxldCBpc0N1cnJlbnQgPSB0cnVlO1xuICAgICAgICBcbiAgICAgICAgY29uc3QgbG9hZFJlY29tbWVuZGF0aW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5zaWdodHMgPSBhd2FpdCBnZXRUaW1lckluc2lnaHRzKHsgZGF5czogNyB9KTtcbiAgICAgICAgICAgICAgICBpZiAoIWlzQ3VycmVudCB8fCAhQXJyYXkuaXNBcnJheShpbnNpZ2h0cz8ucmVjb21tZW5kYXRpb25zKSkgcmV0dXJuO1xuXG4gICAgICAgICAgICAgICAgaW5zaWdodHMucmVjb21tZW5kYXRpb25zLmZvckVhY2goKHJlY29tbWVuZGF0aW9uLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXJlY29tbWVuZGF0aW9uIHx8IHR5cGVvZiByZWNvbW1lbmRhdGlvbiAhPT0gJ29iamVjdCcpIHJldHVybjtcblxuICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNUaXRsZSA9IHR5cGVvZiByZWNvbW1lbmRhdGlvbi50aXRsZSA9PT0gJ3N0cmluZycgJiYgcmVjb21tZW5kYXRpb24udGl0bGUudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBoYXNNZXNzYWdlID0gdHlwZW9mIHJlY29tbWVuZGF0aW9uLm1lc3NhZ2UgPT09ICdzdHJpbmcnICYmIHJlY29tbWVuZGF0aW9uLm1lc3NhZ2UudHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWhhc1RpdGxlICYmICFoYXNNZXNzYWdlKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVjb21tZW5kYXRpb25LZXkgPSBTdHJpbmcoXG4gICAgICAgICAgICAgICAgICAgICAgICByZWNvbW1lbmRhdGlvbi5pZCA/PyBgJHtyZWNvbW1lbmRhdGlvbi50aXRsZX0tJHtyZWNvbW1lbmRhdGlvbi5tZXNzYWdlfWAsXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkaXNwbGF5ZWRSZWNvbW1lbmRhdGlvbnNSZWYuY3VycmVudC5oYXMocmVjb21tZW5kYXRpb25LZXkpKSByZXR1cm47XG5cbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheWVkUmVjb21tZW5kYXRpb25zUmVmLmN1cnJlbnQuYWRkKHJlY29tbWVuZGF0aW9uS2V5KTtcbiAgICAgICAgICAgICAgICAgICAgc2hvd0luc2lnaHRUb2FzdChyZWNvbW1lbmRhdGlvbiwgaW5kZXgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIGxvYWQgcmVjb21tZW5kYXRpb25zLicsIHJlcXVlc3RFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgbG9hZFJlY29tbWVuZGF0aW9ucygpO1xuXG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpc0N1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfTtcbiAgICB9LCBbXSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8VG9hc3RDb250YWluZXJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImluc2lnaHQtdG9hc3QtY29udGFpbmVyXCJcbiAgICAgICAgICAgIHBvc2l0aW9uPVwidG9wLWxlZnRcIlxuICAgICAgICAgICAgYXV0b0Nsb3NlPXs4NTAwfVxuICAgICAgICAgICAgY2xvc2VPbkNsaWNrPXtmYWxzZX1cbiAgICAgICAgICAgIG5ld2VzdE9uVG9wXG4gICAgICAgICAgICBwYXVzZU9uRm9jdXNMb3NzXG4gICAgICAgICAgICBwYXVzZU9uSG92ZXJcbiAgICAgICAgICAgIGRyYWdnYWJsZVxuICAgICAgICAgICAgbGltaXQ9ezN9XG4gICAgICAgICAgICB0aGVtZT1cImxpZ2h0XCJcbiAgICAgICAgLz5cbiAgICApO1xufSJdfQ==