import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/home.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import SmartFocusUI from "/src/components/SmartFocusUI.jsx";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/pages/home.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
export default function Home() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "home-page",
		children: /* @__PURE__ */ _jsxDEV("main", { children: /* @__PURE__ */ _jsxDEV("section", {
			id: "smart-focus",
			className: "home-smart-focus",
			children: /* @__PURE__ */ _jsxDEV(SmartFocusUI, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 21
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 17
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 13
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 9
	}, this);
}
_c = Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/home.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/pages/home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/pages/home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/pages/home.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxrQkFBa0I7OztBQUV6QixlQUFlLFNBQVMsT0FBTztDQUMzQixPQUNJLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ1gsd0JBQUMsUUFBRCxZQUNJLHdCQUFDLFdBQUQ7R0FBUyxJQUFHO0dBQWMsV0FBVTthQUNoQyx3QkFBQyxjQUFELENBQWU7Ozs7O0VBQ1Y7Ozs7V0FDUDs7Ozs7Q0FDTDs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJob21lLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU21hcnRGb2N1c1VJIGZyb20gJy4uL2NvbXBvbmVudHMvU21hcnRGb2N1c1VJLmpzeCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob21lLXBhZ2VcIj5cbiAgICAgICAgICAgIDxtYWluPlxuICAgICAgICAgICAgICAgIDxzZWN0aW9uIGlkPVwic21hcnQtZm9jdXNcIiBjbGFzc05hbWU9XCJob21lLXNtYXJ0LWZvY3VzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTbWFydEZvY3VzVUkgLz5cbiAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgICA8L21haW4+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59Il19