import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/authorize.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b4895507";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=b4895507";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/pages/authorize.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$();
export default function Authorize() {
	_s();
	const location = useLocation();
	const navigate = useNavigate();
	const isRegister = location.pathname === "/register";
	const [error, setError] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const handleSubmit = async (e) => {
		e.preventDefault();
		setError("");
		setIsLoading(true);
		const formData = new FormData(e.target);
		const email = formData.get("email");
		const password = formData.get("password");
		const endpoint = isRegister ? "/api/auth/register" : "/api/auth/login";
		try {
			const API_BASE_URL = import.meta.env.VITE_API_URL?.replace(/\/$/, "") || "http://localhost:5050";
			const res = await fetch(`${API_BASE_URL}${endpoint}`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password
				})
			});
			const body = await res.json();
			if (!res.ok) {
				throw new Error(body.error || body.message || "Authentication failed");
			}
			const token = body.session?.access_token;
			if (token) {
				localStorage.setItem("authToken", token);
				navigate("/dashboard");
			} else {
				throw new Error("No access token returned from server.");
			}
		} catch (err) {
			setError(err.message);
		} finally {
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "auth-page",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: isRegister ? "Register" : "Login" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 13
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				style: {
					color: "red",
					marginBottom: "1rem"
				},
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "email",
						children: "Email"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "email",
						name: "email",
						type: "email",
						autoComplete: "email",
						defaultValue: "alex@example.com",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "password",
						children: "Password"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "password",
						name: "password",
						type: "password",
						autoComplete: isRegister ? "new-password" : "current-password",
						defaultValue: "password123",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						disabled: isLoading,
						children: isLoading ? "Processing..." : isRegister ? "Create Account" : "Login"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: [
				isRegister ? "Already have an account?" : "Don't have an account?",
				" ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: isRegister ? "/login" : "/register",
					children: isRegister ? "Login" : "Register"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 17
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 9
	}, this);
}
_s(Authorize, "8K6WrZioSdfEPWXPE+8ADsYhY6E=", false, function() {
	return [useLocation, useNavigate];
});
_c = Authorize;
var _c;
$RefreshReg$(_c, "Authorize");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/authorize.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/pages/authorize.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/pages/authorize.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/pages/authorize.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLGFBQWEsbUJBQW1CO0FBQy9DLFNBQVMsZ0JBQWdCOzs7O0FBRXpCLGVBQWUsU0FBUyxZQUFZOztDQUNoQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLGFBQWEsU0FBUyxhQUFhO0NBRXpDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FFaEQsTUFBTSxlQUFlLE9BQU8sTUFBTTtFQUM5QixFQUFFLGVBQWU7RUFDakIsU0FBUyxFQUFFO0VBQ1gsYUFBYSxJQUFJO0VBRWpCLE1BQU0sV0FBVyxJQUFJLFNBQVMsRUFBRSxNQUFNO0VBQ3RDLE1BQU0sUUFBUSxTQUFTLElBQUksT0FBTztFQUNsQyxNQUFNLFdBQVcsU0FBUyxJQUFJLFVBQVU7RUFDeEMsTUFBTSxXQUFXLGFBQWEsdUJBQXVCO0VBRXJELElBQUk7R0FDQSxNQUFNLGVBQWUsWUFBWSxJQUFJLGNBQWMsUUFBUSxPQUFPLEVBQUUsS0FBSztHQUN6RSxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsZUFBZSxZQUFZO0lBQ2xELFFBQVE7SUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtJQUM5QyxNQUFNLEtBQUssVUFBVTtLQUFFO0tBQU87SUFBUyxDQUFDO0dBQzVDLENBQUM7R0FFRCxNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7R0FDNUIsSUFBSSxDQUFDLElBQUksSUFBSTtJQUNULE1BQU0sSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLFdBQVcsdUJBQXVCO0dBQ3pFO0dBRUEsTUFBTSxRQUFRLEtBQUssU0FBUztHQUM1QixJQUFJLE9BQU87SUFDUCxhQUFhLFFBQVEsYUFBYSxLQUFLO0lBQ3ZDLFNBQVMsWUFBWTtHQUN6QixPQUFPO0lBQ0gsTUFBTSxJQUFJLE1BQU0sdUNBQXVDO0dBQzNEO0VBQ0osU0FBUyxLQUFLO0dBQ1YsU0FBUyxJQUFJLE9BQU87RUFDeEIsVUFBVTtHQUNOLGFBQWEsS0FBSztFQUN0QjtDQUNKO0NBRUEsT0FDSSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUNJLHdCQUFDLE1BQUQsWUFBSyxhQUFhLGFBQWEsUUFBWTs7Ozs7R0FFMUMsU0FDRyx3QkFBQyxPQUFEO0lBQUssT0FBTztLQUFFLE9BQU87S0FBTyxjQUFjO0lBQU87SUFBRyxNQUFLO2NBQ3BEO0dBQ0E7Ozs7O0dBR1Qsd0JBQUMsUUFBRDtJQUFNLFVBQVU7Y0FBaEI7S0FDSSx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBUTtLQUFZOzs7OztLQUNuQyx3QkFBQyxTQUFEO01BQ0ksSUFBRztNQUNILE1BQUs7TUFDTCxNQUFLO01BQ0wsY0FBYTtNQUNiLGNBQWE7TUFDYjtLQUNIOzs7OztLQUVELHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUFXO0tBQWU7Ozs7O0tBQ3pDLHdCQUFDLFNBQUQ7TUFDSSxJQUFHO01BQ0gsTUFBSztNQUNMLE1BQUs7TUFDTCxjQUFjLGFBQWEsaUJBQWlCO01BQzVDLGNBQWE7TUFDYjtLQUNIOzs7OztLQUVELHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVTtnQkFDM0IsWUFBWSxrQkFBbUIsYUFBYSxtQkFBbUI7S0FDNUQ7Ozs7O0lBQ047Ozs7OztHQUVOLHdCQUFDLEtBQUQ7SUFDSyxhQUFhLDZCQUE2QjtJQUEwQjtJQUNyRSx3QkFBQyxNQUFEO0tBQU0sSUFBSSxhQUFhLFdBQVc7ZUFDN0IsYUFBYSxVQUFVO0lBQ3RCOzs7OztHQUNQOzs7OztFQUNEOzs7Ozs7QUFFZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhdXRob3JpemUuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhvcml6ZSgpIHtcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICAgIGNvbnN0IGlzUmVnaXN0ZXIgPSBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy9yZWdpc3Rlcic7XG4gICAgXG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG4gICAgICAgIFxuICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShlLnRhcmdldCk7XG4gICAgICAgIGNvbnN0IGVtYWlsID0gZm9ybURhdGEuZ2V0KCdlbWFpbCcpO1xuICAgICAgICBjb25zdCBwYXNzd29yZCA9IGZvcm1EYXRhLmdldCgncGFzc3dvcmQnKTtcbiAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBpc1JlZ2lzdGVyID8gJy9hcGkvYXV0aC9yZWdpc3RlcicgOiAnL2FwaS9hdXRoL2xvZ2luJztcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgQVBJX0JBU0VfVVJMID0gaW1wb3J0Lm1ldGEuZW52LlZJVEVfQVBJX1VSTD8ucmVwbGFjZSgvXFwvJC8sICcnKSB8fCAnaHR0cDovL2xvY2FsaG9zdDo1MDUwJztcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9CQVNFX1VSTH0ke2VuZHBvaW50fWAsIHtcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVtYWlsLCBwYXNzd29yZCB9KVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXMuanNvbigpO1xuICAgICAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYm9keS5lcnJvciB8fCBib2R5Lm1lc3NhZ2UgfHwgJ0F1dGhlbnRpY2F0aW9uIGZhaWxlZCcpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCB0b2tlbiA9IGJvZHkuc2Vzc2lvbj8uYWNjZXNzX3Rva2VuO1xuICAgICAgICAgICAgaWYgKHRva2VuKSB7XG4gICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2F1dGhUb2tlbicsIHRva2VuKTtcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZSgnL2Rhc2hib2FyZCcpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGFjY2VzcyB0b2tlbiByZXR1cm5lZCBmcm9tIHNlcnZlci4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImF1dGgtcGFnZVwiPlxuICAgICAgICAgICAgPGgxPntpc1JlZ2lzdGVyID8gJ1JlZ2lzdGVyJyA6ICdMb2dpbid9PC9oMT5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAncmVkJywgbWFyZ2luQm90dG9tOiAnMXJlbScgfX0gcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIj5FbWFpbDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cImFsZXhAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPXtpc1JlZ2lzdGVyID8gJ25ldy1wYXNzd29yZCcgOiAnY3VycmVudC1wYXNzd29yZCd9XG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cInBhc3N3b3JkMTIzXCJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzTG9hZGluZ30+XG4gICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAnUHJvY2Vzc2luZy4uLicgOiAoaXNSZWdpc3RlciA/ICdDcmVhdGUgQWNjb3VudCcgOiAnTG9naW4nKX1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAge2lzUmVnaXN0ZXIgPyAnQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/JyA6IFwiRG9uJ3QgaGF2ZSBhbiBhY2NvdW50P1wifXsnICd9XG4gICAgICAgICAgICAgICAgPExpbmsgdG89e2lzUmVnaXN0ZXIgPyAnL2xvZ2luJyA6ICcvcmVnaXN0ZXInfT5cbiAgICAgICAgICAgICAgICAgICAge2lzUmVnaXN0ZXIgPyAnTG9naW4nIDogJ1JlZ2lzdGVyJ31cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgIDwvbWFpbj5cbiAgICApXG59Il19