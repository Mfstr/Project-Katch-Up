import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Dashboard.jsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b4895507";
import { getTasks } from "/src/services/apiClient.js";
import FocusStatisicsChart from "/src/components/FocusStatisticsChart.jsx";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$();
function normalizeTasks(task) {
	return {
		id: task?.id ?? task?.taskId,
		title: task?.title ?? task?.name ?? "Untitled Task",
		description: task?.description ?? "",
		dueDate: task?.dueDate ?? task?.due_date ?? null,
		createdAt: task?.createdAt ?? task?.created_at ?? null,
		isComplete: Boolean(task?.isComplete ?? task?.is_complete ?? false),
		durationSeconds: task?.durationSeconds ?? task?.duration_seconds ?? 20 * 60
	};
}
const EMPTY_EDIT_FORM = {
	title: "",
	description: "",
	dueDate: ""
};
const DAYS_IN_MILLISECONDS = 24 * 60 * 60 * 1e3;
function getDateOnly(value) {
	if (!value) return null;
	const datePart = String(value).slice(0, 10);
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datePart);
	if (!match) return null;
	const year = Number(match[1]);
	const month = Number(match[2]);
	const day = Number(match[3]);
	const date = new Date(year, month - 1, day);
	if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
		return null;
	}
	return date;
}
function getLocalDayNumber(date) {
	return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / DAYS_IN_MILLISECONDS;
}
function getDaysUntilDue(value) {
	const dueDate = getDateOnly(value);
	if (!dueDate) return null;
	const today = new Date();
	return getLocalDayNumber(dueDate) - getLocalDayNumber(today);
}
function formatDueDate(value) {
	const date = getDateOnly(value);
	return date ? date.toLocaleDateString() : null;
}
function toDateInputValue(value) {
	if (!value) return "";
	const datePart = String(value).slice(0, 10);
	return /^\d{4}-\d{2}-\d{2}$/.test(datePart) ? datePart : "";
}
function getCreatedTimestamp(value) {
	if (!value) return null;
	const timestamp = Date.parse(value);
	return Number.isNaN(timestamp) ? null : timestamp;
}
function compareTasks(a, b, sortBy) {
	if (sortBy === "created-newest" || sortBy === "created-oldest") {
		const aCreated = getCreatedTimestamp(a.createdAt);
		const bCreated = getCreatedTimestamp(b.createdAt);
		if (aCreated == null && bCreated != null) return 1;
		if (aCreated != null && bCreated == null) return -1;
		if (aCreated != null && bCreated != null && aCreated !== bCreated) {
			return sortBy === "created-newest" ? bCreated - aCreated : aCreated - bCreated;
		}
	} else {
		const aDue = getDateOnly(a.dueDate);
		const bDue = getDateOnly(b.dueDate);
		if (!aDue && bDue) return 1;
		if (aDue && !bDue) return -1;
		if (aDue && bDue) {
			const difference = getLocalDayNumber(aDue) - getLocalDayNumber(bDue);
			if (difference !== 0) return difference;
		}
	}
	return String(a.title).localeCompare(String(b.title), undefined, { sensitivity: "base" });
}
const TASK_GROUPS = [
	{
		id: "overdue",
		title: "Overdue",
		description: "Tasks that are past their due date"
	},
	{
		id: "today",
		title: "Today",
		description: "Tasks that are due today"
	},
	{
		id: "upcoming",
		title: "Upcoming",
		description: "Tasks that are due within a week"
	},
	{
		id: "later",
		title: "Later",
		description: "Tasks that are due after a week or are without a due date"
	}
];
function getTaskGroup(task) {
	const daysUntilDue = getDaysUntilDue(task.dueDate);
	if (daysUntilDue == null || daysUntilDue > 7) return "later";
	if (daysUntilDue < 0) return task.isComplete ? "later" : "overdue";
	if (daysUntilDue === 0) return "today";
	return "upcoming";
}
const EMPTY_GROUPS = TASK_GROUPS.map(_c = (group) => ({
	...group,
	tasks: []
}));
_c2 = EMPTY_GROUPS;
export default function Dashboard({ selectedTask, onSelectTask, taskSelectionDisabled = false, refreshSignal = 0, onDeleteTask, deletingTaskId = null, onUpdateTask, updatingTaskId = null, taskActionError = "", taskActionNotice = "", taskActionNoticeFading = false, isYoutubePlayerEnabled = true, onLogout }) {
	_s();
	const [tasks, setTasks] = useState([]);
	const [isLoading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const [taskView, setTaskView] = useState("active");
	const [searchQuery, setSearchQuery] = useState("");
	const [sortBy, setSortBy] = useState("due-date");
	const [editingTaskId, setEditingTaskId] = useState(null);
	const [editForm, setEditForm] = useState(EMPTY_EDIT_FORM);
	const [editError, setEditError] = useState("");
	const loadTasks = useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const responseTasks = await getTasks();
			const nextTasks = Array.isArray(responseTasks) ? responseTasks.map(normalizeTasks) : [];
			setTasks(nextTasks);
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Unable to load tasks.");
		} finally {
			setLoading(false);
		}
	}, []);
	useEffect(() => {
		loadTasks();
	}, [loadTasks, refreshSignal]);
	const activeTasks = useMemo(() => tasks.filter((task) => !task.isComplete), [tasks]);
	const completedTasks = useMemo(() => tasks.filter((task) => task.isComplete), [tasks]);
	const overdueTasks = useMemo(() => activeTasks.filter((task) => {
		const daysUntilDue = getDaysUntilDue(task.dueDate);
		return daysUntilDue !== null && daysUntilDue < 0;
	}), [activeTasks]);
	const visibleTasks = useMemo(() => {
		let result;
		if (taskView === "completed") {
			result = completedTasks;
		} else if (taskView === "overdue") {
			result = overdueTasks;
		} else {
			result = activeTasks;
		}
		const normalizedQuery = searchQuery.trim().toLocaleLowerCase();
		if (normalizedQuery) {
			result = result.filter((task) => String(task.title).toLocaleLowerCase().includes(normalizedQuery));
		}
		return [...result].sort((a, b) => compareTasks(a, b, sortBy));
	}, [
		activeTasks,
		completedTasks,
		overdueTasks,
		searchQuery,
		sortBy,
		taskView
	]);
	const groupedTasks = useMemo(() => {
		if (taskView === "completed") {
			return [{
				id: "completed",
				title: "Completed Tasks",
				tasks: visibleTasks
			}];
		}
		const groups = EMPTY_GROUPS.map((group) => ({
			...group,
			tasks: []
		}));
		const groupsById = new Map(groups.map((group) => [group.id, group]));
		visibleTasks.forEach((task) => {
			const groupId = getTaskGroup(task);
			groupsById.get(groupId)?.tasks.push(task);
		});
		return groups.filter((group) => group.tasks.length > 0);
	}, [taskView, visibleTasks]);
	const handleCompletionChange = async (task, isComplete) => {
		if (!onUpdateTask || task.id == null) return;
		await onUpdateTask(task, { is_complete: isComplete });
	};
	const handleEditOpen = (task) => {
		setEditingTaskId(task.id);
		setEditForm({
			title: task.title ?? "",
			description: task.description ?? "",
			dueDate: toDateInputValue(task.dueDate)
		});
		setEditError("");
	};
	const handleEditCancel = () => {
		setEditingTaskId(null);
		setEditForm(EMPTY_EDIT_FORM);
		setEditError("");
	};
	const handleEditSave = async (event, task) => {
		event.preventDefault();
		const title = editForm.title.trim();
		if (!title) {
			setEditError("A task must have a title.");
			return;
		}
		if (!onUpdateTask || task.id == null) {
			setEditError("The task cannot be updated as it has no task ID.");
			return;
		}
		setEditError("");
		const wasUpdated = await onUpdateTask(task, {
			title,
			description: editForm.description.trim() || null,
			due_date: editForm.dueDate || null
		});
		if (wasUpdated) handleEditCancel();
	};
	const hasSearchQuery = searchQuery.trim().length > 0;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "dashboard",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h1", {
					id: "dashboard-heading",
					children: "Your Tasks"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 271,
					columnNumber: 21
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 270,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "dashboard-header-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "refresh-tasks",
						onClick: loadTasks,
						disabled: isLoading,
						children: isLoading ? "Loading..." : "Refresh Tasks"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "logout-button",
						onClick: onLogout,
						children: "Log Out"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 283,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 269,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "task-view-tabs",
				role: "tablist",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						role: "tab",
						id: "active-tasks-tab",
						className: `task-view-tab${taskView === "active" ? " is-active" : ""}`,
						onClick: () => setTaskView("active"),
						children: "Active"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 294,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						role: "tab",
						id: "completed-tasks-tab",
						className: `task-view-tab${taskView === "completed" ? " is-active" : ""}`,
						onClick: () => setTaskView("completed"),
						children: "Completed"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 303,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						role: "tab",
						id: "overdue-tasks-tab",
						className: `task-view-tab${taskView === "overdue" ? " is-active" : ""}`,
						onClick: () => setTaskView("overdue"),
						children: "Overdue"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 312,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 293,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "task-filter-toolbar",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					className: "task-search-field",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Search by Task Title" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 325,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "search",
						value: searchQuery,
						onChange: (event) => setSearchQuery(event.target.value),
						placeholder: "Search your tasks..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 326,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 324,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("label", {
					className: "task-sort-field",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Sort By" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 21
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: sortBy,
						onChange: (event) => setSortBy(event.target.value),
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "due-date",
								children: "Due Date (Descending Order)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "created-newest",
								children: "Creation Date (Descending Order)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "created-oldest",
								children: "Creation Date (Ascending Order)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 21
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 334,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 323,
				columnNumber: 13
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 348,
				columnNumber: 17
			}, this),
			taskActionError && /* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-error",
				role: "alert",
				children: taskActionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 354,
				columnNumber: 17
			}, this),
			taskActionNotice && /* @__PURE__ */ _jsxDEV("div", {
				className: `dashboard-notice auto-dismiss-notice${taskActionNoticeFading ? " is-fading" : ""}`,
				role: "status",
				children: taskActionNotice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 360,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "task-list-panel",
				id: "task-list-panel",
				role: "tabpanel",
				children: [
					isLoading && /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						role: "status",
						children: "Loading tasks..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 367,
						columnNumber: 21
					}, this),
					!isLoading && !error && visibleTasks.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
						className: "empty-state",
						children: hasSearchQuery ? `No ${taskView} tasks match "${searchQuery.trim()}".` : taskView === "active" ? "No active tasks were found." : taskView === "completed" ? "No completed tasks were found." : "You have no overdue tasks."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 371,
						columnNumber: 21
					}, this),
					!isLoading && !error && groupedTasks.map((group) => /* @__PURE__ */ _jsxDEV("section", {
						className: `task-group${group.id === "overdue-view" ? " is-overdue-group" : ""}`,
						children: [
							group.title && /* @__PURE__ */ _jsxDEV("div", {
								className: `task-group-header${group.id === "overdue-view" ? " is-overdue" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: group.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 37
								}, this), group.description && /* @__PURE__ */ _jsxDEV("p", { children: group.description }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 59
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 33
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "task-group-count",
									children: group.tasks.length
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 385,
								columnNumber: 29
							}, this),
							group.tasks.length === 0 && group.id === "completed-view" && /* @__PURE__ */ _jsxDEV("p", {
								className: "empty-state",
								children: hasSearchQuery ? `No completed tasks match "${searchQuery.trim()}".` : "You have no completed tasks."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 395,
								columnNumber: 29
							}, this),
							group.tasks.length === 0 && group.id === "overdue-view" && /* @__PURE__ */ _jsxDEV("p", {
								className: "empty-state",
								children: hasSearchQuery ? `No overdue tasks match "${searchQuery.trim()}".` : "You have no overdue tasks."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 403,
								columnNumber: 29
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "task-list",
								role: "list",
								children: group.tasks.map((task, index) => {
									const dueDate = formatDueDate(task.dueDate);
									const isSelected = task.id != null && String(selectedTask?.id) === String(task.id);
									const isDeleting = String(deletingTaskId) === String(task.id) && deletingTaskId !== null;
									const isUpdating = updatingTaskId != null && String(updatingTaskId) === String(task.id);
									const isEditing = editingTaskId != null && String(editingTaskId) === String(task.id);
									const taskKey = task.id ?? `${group.id}-task-${index}`;
									return /* @__PURE__ */ _jsxDEV("div", {
										className: `task-list-item${task.isComplete ? " is-complete" : ""}${isSelected ? " is-selected" : ""}`,
										role: "listitem",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "task-completion-control",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: task.isComplete,
													onChange: (event) => handleCompletionChange(task, event.target.checked),
													disabled: !onUpdateTask || task.id == null || isUpdating || isDeleting,
													title: task.isComplete ? "Reopen Task" : "Mark as Complete"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 422,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("span", { className: "task-completion-indicator" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 429,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 421,
												columnNumber: 41
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												className: `task-card${isSelected ? " selected" : ""}${task.isComplete ? " completed" : ""}`,
												onClick: () => onSelectTask?.(task),
												disabled: taskSelectionDisabled || task.isComplete,
												title: task.isComplete ? "Reopen this task before selecting it for a focus session." : taskSelectionDisabled ? "Finish or reset the current session before selecting another task." : `Select ${task.title}`,
												children: [
													/* @__PURE__ */ _jsxDEV("span", {
														className: "task-card-title",
														children: task.title
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 443,
														columnNumber: 49
													}, this),
													task.description && /* @__PURE__ */ _jsxDEV("span", {
														className: "task-card-description",
														children: task.description
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 446,
														columnNumber: 53
													}, this),
													dueDate && /* @__PURE__ */ _jsxDEV("span", {
														className: "task-card-due-date",
														children: ["Due ", dueDate]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 452,
														columnNumber: 53
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 432,
												columnNumber: 41
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "task-actions",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: "task-edit-button",
													onClick: () => isEditing ? handleEditCancel() : handleEditOpen(task),
													disabled: isUpdating || isDeleting,
													children: isEditing ? "Cancel" : "Edit"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 459,
													columnNumber: 45
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													className: "task-delete-button",
													onClick: () => onDeleteTask?.(task),
													disabled: !onDeleteTask || task.id == null || isDeleting || isUpdating,
													title: `Delete ${task.title}`,
													children: isDeleting ? "Deleting..." : "Delete"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 467,
													columnNumber: 45
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 458,
												columnNumber: 41
											}, this),
											isEditing && /* @__PURE__ */ _jsxDEV("form", {
												className: "task-edit-form",
												onSubmit: (event) => handleEditSave(event, task),
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "task-edit-grid",
														children: [
															/* @__PURE__ */ _jsxDEV("div", {
																className: "task-edit-field task-edit-title-field",
																children: [/* @__PURE__ */ _jsxDEV("label", {
																	htmlFor: `edit-task-title-${taskKey}`,
																	children: "Task Title"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 482,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("input", {
																	id: `edit-task-title-${taskKey}`,
																	type: "text",
																	value: editForm.title,
																	onChange: (event) => setEditForm((current) => ({
																		...current,
																		title: event.target.value
																	})),
																	maxLength: 120,
																	required: true
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 483,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 481,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "task-edit-field",
																children: [/* @__PURE__ */ _jsxDEV("label", {
																	htmlFor: `edit-task-due-${taskKey}`,
																	children: "Due Date"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 493,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("input", {
																	id: `edit-task-due-${taskKey}`,
																	type: "date",
																	value: editForm.dueDate,
																	onChange: (event) => setEditForm((current) => ({
																		...current,
																		dueDate: event.target.value
																	}))
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 494,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 492,
																columnNumber: 53
															}, this),
															/* @__PURE__ */ _jsxDEV("div", {
																className: "task-edit-field task-edit-description-field",
																children: [/* @__PURE__ */ _jsxDEV("label", {
																	htmlFor: `edit-task-description-${taskKey}`,
																	children: "Description"
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 502,
																	columnNumber: 57
																}, this), /* @__PURE__ */ _jsxDEV("textarea", {
																	id: `edit-task-description-${taskKey}`,
																	value: editForm.description,
																	onChange: (event) => setEditForm((current) => ({
																		...current,
																		description: event.target.value
																	})),
																	rows: 2
																}, void 0, false, {
																	fileName: _jsxFileName,
																	lineNumber: 503,
																	columnNumber: 57
																}, this)]
															}, void 0, true, {
																fileName: _jsxFileName,
																lineNumber: 501,
																columnNumber: 53
															}, this)
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 480,
														columnNumber: 49
													}, this),
													editError && /* @__PURE__ */ _jsxDEV("p", {
														className: "task-edit-error",
														role: "alert",
														children: editError
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 513,
														columnNumber: 53
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "task-edit-actions",
														children: [/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															className: "task-edit-cancel-button",
															onClick: handleEditCancel,
															disabled: isUpdating,
															children: "Cancel"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 517,
															columnNumber: 53
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															type: "submit",
															className: "task-edit-save-button",
															disabled: isUpdating,
															children: isUpdating ? "Saving..." : "Save"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 525,
															columnNumber: 53
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 516,
														columnNumber: 49
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 479,
												columnNumber: 45
											}, this)
										]
									}, taskKey, true, {
										fileName: _jsxFileName,
										lineNumber: 420,
										columnNumber: 37
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 25
							}, this)
						]
					}, group.id, true, {
						fileName: _jsxFileName,
						lineNumber: 383,
						columnNumber: 21
					}, this))
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 365,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(FocusStatisicsChart, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 543,
				columnNumber: 13
			}, this),
			isYoutubePlayerEnabled && /* @__PURE__ */ _jsxDEV("section", {
				className: "dashboard-youtube-music",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "dashboard-youtube-music-header",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						id: "dashboard-youtube-music-heading",
						children: "Lo-fi YouTube Study Stream"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 548,
						columnNumber: 25
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Play background music while you work on your tasks." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 549,
						columnNumber: 25
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 547,
					columnNumber: 21
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "youtube-player-frame",
					children: /* @__PURE__ */ _jsxDEV("iframe", {
						src: "https://www.youtube-nocookie.com/embed/qGohtGC5Rtk?rel=0&playsinline=1",
						title: "Study With Me 📚 Pomodoro",
						loading: "lazy",
						referrerPolicy: "strict-origin-when-cross-origin",
						allow: "accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
						allowFullScreen: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 553,
						columnNumber: 25
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 552,
					columnNumber: 21
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 546,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 268,
		columnNumber: 9
	}, this);
}
_s(Dashboard, "hMGZjatMCNdiF+FwlxuT5Hm0/F8=");
_c3 = Dashboard;
var _c, _c2, _c3;
$RefreshReg$(_c, "EMPTY_GROUPS$TASK_GROUPS.map");
$RefreshReg$(_c2, "EMPTY_GROUPS");
$RefreshReg$(_c3, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Dashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsU0FBUyxnQkFBZ0I7QUFDMUQsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTyx5QkFBeUI7Ozs7QUFFaEMsU0FBUyxlQUFlLE1BQU07Q0FDMUIsT0FBTztFQUNILElBQUksTUFBTSxNQUFNLE1BQU07RUFDdEIsT0FBTyxNQUFNLFNBQVMsTUFBTSxRQUFRO0VBQ3BDLGFBQWEsTUFBTSxlQUFlO0VBQ2xDLFNBQVMsTUFBTSxXQUFXLE1BQU0sWUFBWTtFQUM1QyxXQUFXLE1BQU0sYUFBYSxNQUFNLGNBQWM7RUFDbEQsWUFBWSxRQUFRLE1BQU0sY0FBYyxNQUFNLGVBQWUsS0FBSztFQUNsRSxpQkFBaUIsTUFBTSxtQkFBbUIsTUFBTSxvQkFBb0IsS0FBSztDQUM3RTtBQUNKO0FBRUEsTUFBTSxrQkFBa0I7Q0FBRSxPQUFPO0NBQUksYUFBYTtDQUFJLFNBQVM7QUFBRztBQUNsRSxNQUFNLHVCQUF1QixLQUFLLEtBQUssS0FBSztBQUU1QyxTQUFTLFlBQVksT0FBTztDQUN4QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBRW5CLE1BQU0sV0FBVyxPQUFPLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0NBQzFDLE1BQU0sUUFBUSw0QkFBNEIsS0FBSyxRQUFRO0NBQ3ZELElBQUksQ0FBQyxPQUFPLE9BQU87Q0FFbkIsTUFBTSxPQUFPLE9BQU8sTUFBTSxFQUFFO0NBQzVCLE1BQU0sUUFBUSxPQUFPLE1BQU0sRUFBRTtDQUM3QixNQUFNLE1BQU0sT0FBTyxNQUFNLEVBQUU7Q0FDM0IsTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLFFBQVEsR0FBRyxHQUFHO0NBRTFDLElBQ0ksS0FBSyxZQUFZLE1BQU0sUUFDdkIsS0FBSyxTQUFTLE1BQU0sUUFBUSxLQUM1QixLQUFLLFFBQVEsTUFBTSxLQUNyQjtFQUNFLE9BQU87Q0FDWDtDQUVBLE9BQU87QUFDWDtBQUVBLFNBQVMsa0JBQWtCLE1BQU07Q0FDN0IsT0FBTyxLQUFLLElBQUksS0FBSyxZQUFZLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSyxRQUFRLENBQUMsSUFBSTtBQUMzRTtBQUVBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDNUIsTUFBTSxVQUFVLFlBQVksS0FBSztDQUNqQyxJQUFJLENBQUMsU0FBUyxPQUFPO0NBRXJCLE1BQU0sUUFBUSxJQUFJLEtBQUs7Q0FDdkIsT0FBTyxrQkFBa0IsT0FBTyxJQUFJLGtCQUFrQixLQUFLO0FBQy9EO0FBRUEsU0FBUyxjQUFjLE9BQU87Q0FDMUIsTUFBTSxPQUFPLFlBQVksS0FBSztDQUM5QixPQUFPLE9BQU8sS0FBSyxtQkFBbUIsSUFBSTtBQUM5QztBQUVBLFNBQVMsaUJBQWlCLE9BQU87Q0FDN0IsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixNQUFNLFdBQVcsT0FBTyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRTtDQUMxQyxPQUFPLHNCQUFzQixLQUFLLFFBQVEsSUFBSSxXQUFXO0FBQzdEO0FBRUEsU0FBUyxvQkFBb0IsT0FBTztDQUNoQyxJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLE1BQU0sWUFBWSxLQUFLLE1BQU0sS0FBSztDQUNsQyxPQUFPLE9BQU8sTUFBTSxTQUFTLElBQUksT0FBTztBQUM1QztBQUVBLFNBQVMsYUFBYSxHQUFHLEdBQUcsUUFBUTtDQUNoQyxJQUFJLFdBQVcsb0JBQW9CLFdBQVcsa0JBQWtCO0VBQzVELE1BQU0sV0FBVyxvQkFBb0IsRUFBRSxTQUFTO0VBQ2hELE1BQU0sV0FBVyxvQkFBb0IsRUFBRSxTQUFTO0VBRWhELElBQUksWUFBWSxRQUFRLFlBQVksTUFBTSxPQUFPO0VBQ2pELElBQUksWUFBWSxRQUFRLFlBQVksTUFBTSxPQUFPLENBQUM7RUFFbEQsSUFBSSxZQUFZLFFBQVEsWUFBWSxRQUFRLGFBQWEsVUFBVTtHQUMvRCxPQUFPLFdBQVcsbUJBQ1osV0FBVyxXQUNYLFdBQVc7RUFDckI7Q0FDSixPQUFPO0VBQ0gsTUFBTSxPQUFPLFlBQVksRUFBRSxPQUFPO0VBQ2xDLE1BQU0sT0FBTyxZQUFZLEVBQUUsT0FBTztFQUVsQyxJQUFJLENBQUMsUUFBUSxNQUFNLE9BQU87RUFDMUIsSUFBSSxRQUFRLENBQUMsTUFBTSxPQUFPLENBQUM7RUFFM0IsSUFBSSxRQUFRLE1BQU07R0FDZCxNQUFNLGFBQWEsa0JBQWtCLElBQUksSUFBSSxrQkFBa0IsSUFBSTtHQUNuRSxJQUFJLGVBQWUsR0FBRyxPQUFPO0VBQ2pDO0NBQ0o7Q0FFQSxPQUFPLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQyxjQUFjLE9BQU8sRUFBRSxLQUFLLEdBQUcsV0FBVyxFQUFFLGFBQWEsT0FBTSxDQUFDO0FBQzNGO0FBRUEsTUFBTSxjQUFjO0NBQ2hCO0VBQUUsSUFBSTtFQUFXLE9BQU87RUFBVyxhQUFhO0NBQXFDO0NBQ3JGO0VBQUUsSUFBSTtFQUFTLE9BQU87RUFBUyxhQUFhO0NBQTJCO0NBQ3ZFO0VBQUUsSUFBSTtFQUFZLE9BQU87RUFBWSxhQUFhO0NBQW1DO0NBQ3JGO0VBQUUsSUFBSTtFQUFTLE9BQU87RUFBUyxhQUFhO0NBQTREO0FBQzVHO0FBRUEsU0FBUyxhQUFhLE1BQU07Q0FDeEIsTUFBTSxlQUFlLGdCQUFnQixLQUFLLE9BQU87Q0FFakQsSUFBSSxnQkFBZ0IsUUFBUSxlQUFlLEdBQUcsT0FBTztDQUNyRCxJQUFJLGVBQWUsR0FBRyxPQUFPLEtBQUssYUFBYSxVQUFVO0NBQ3pELElBQUksaUJBQWlCLEdBQUcsT0FBTztDQUMvQixPQUFPO0FBQ1g7QUFFQSxNQUFNLGVBQWUsWUFBWSxVQUFLLFdBQVc7Q0FBRSxHQUFHO0NBQU8sT0FBTyxDQUFDO0FBQUUsRUFBRTs7QUFFekUsZUFBZSxTQUFTLFVBQVUsRUFDOUIsY0FDQSxjQUNBLHdCQUF3QixPQUN4QixnQkFBZ0IsR0FDaEIsY0FDQSxpQkFBaUIsTUFDakIsY0FDQSxpQkFBaUIsTUFDakIsa0JBQWtCLElBQ2xCLG1CQUFtQixJQUNuQix5QkFBeUIsT0FDekIseUJBQXlCLE1BQ3pCLFlBQ0Q7O0NBQ0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsQ0FBQztDQUNyQyxNQUFNLENBQUMsV0FBVyxjQUFjLFNBQVMsS0FBSztDQUM5QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsUUFBUTtDQUNqRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxVQUFVO0NBQy9DLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLElBQUk7Q0FDdkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLGVBQWU7Q0FDeEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUU3QyxNQUFNLFlBQVksWUFBWSxZQUFZO0VBQ3RDLFdBQVcsSUFBSTtFQUNmLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDQSxNQUFNLGdCQUFnQixNQUFNLFNBQVM7R0FDckMsTUFBTSxZQUFZLE1BQU0sUUFBUSxhQUFhLElBQ3ZDLGNBQWMsSUFBSSxjQUFjLElBQ2hDLENBQUM7R0FDUCxTQUFTLFNBQVM7RUFDdEIsU0FBUyxjQUFjO0dBQ25CLFNBQ0ksd0JBQXdCLFFBQ2xCLGFBQWEsVUFDYix1QkFDVjtFQUNKLFVBQVU7R0FDTixXQUFXLEtBQUs7RUFDcEI7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUFFLFVBQVU7Q0FBRyxHQUFHLENBQUMsV0FBVyxhQUFhLENBQUM7Q0FFNUQsTUFBTSxjQUFjLGNBQ1YsTUFBTSxRQUFRLFNBQVMsQ0FBQyxLQUFLLFVBQVUsR0FBRyxDQUFDLEtBQUssQ0FDMUQ7Q0FFQSxNQUFNLGlCQUFpQixjQUNiLE1BQU0sUUFBUSxTQUFTLEtBQUssVUFBVSxHQUFHLENBQUMsS0FBSyxDQUN6RDtDQUVBLE1BQU0sZUFBZSxjQUNYLFlBQVksUUFBUSxTQUFTO0VBQy9CLE1BQU0sZUFBZSxnQkFBZ0IsS0FBSyxPQUFPO0VBQ2pELE9BQU8saUJBQWlCLFFBQVEsZUFBZTtDQUNuRCxDQUFDLEdBQ0QsQ0FBQyxXQUFXLENBQ2hCO0NBRUEsTUFBTSxlQUFlLGNBQWM7RUFDL0IsSUFBSTtFQUVKLElBQUksYUFBYSxhQUFhO0dBQzFCLFNBQVM7RUFDYixPQUFPLElBQUksYUFBYSxXQUFXO0dBQy9CLFNBQVM7RUFDYixPQUFPO0dBQ0gsU0FBUztFQUNiO0VBRUEsTUFBTSxrQkFBa0IsWUFBWSxLQUFLLENBQUMsQ0FBQyxrQkFBa0I7RUFDN0QsSUFBSSxpQkFBaUI7R0FDakIsU0FBUyxPQUFPLFFBQVEsU0FDcEIsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsU0FBUyxlQUFlLENBQ25FO0VBQ0o7RUFFQSxPQUFPLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxhQUFhLEdBQUcsR0FBRyxNQUFNLENBQUM7Q0FDaEUsR0FBRztFQUFDO0VBQWE7RUFBZ0I7RUFBYztFQUFhO0VBQVE7Q0FBUSxDQUFDO0NBRTdFLE1BQU0sZUFBZSxjQUFjO0VBQy9CLElBQUksYUFBYSxhQUFhO0dBQzFCLE9BQU8sQ0FBQztJQUFFLElBQUk7SUFBYSxPQUFPO0lBQW1CLE9BQU87R0FBWSxDQUFDO0VBQzdFO0VBRUEsTUFBTSxTQUFTLGFBQWEsS0FBSyxXQUFXO0dBQUUsR0FBRztHQUFPLE9BQU8sQ0FBQztFQUFFLEVBQUU7RUFDcEUsTUFBTSxhQUFhLElBQUksSUFBSSxPQUFPLEtBQUssVUFBVSxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsQ0FBQztFQUVuRSxhQUFhLFNBQVMsU0FBUztHQUMzQixNQUFNLFVBQVUsYUFBYSxJQUFJO0dBQ2pDLFdBQVcsSUFBSSxPQUFPLENBQUMsRUFBRSxNQUFNLEtBQUssSUFBSTtFQUM1QyxDQUFDO0VBRUQsT0FBTyxPQUFPLFFBQVEsVUFBVSxNQUFNLE1BQU0sU0FBUyxDQUFDO0NBQzFELEdBQUcsQ0FBQyxVQUFVLFlBQVksQ0FBQztDQUUzQixNQUFNLHlCQUF5QixPQUFPLE1BQU0sZUFBZTtFQUN2RCxJQUFJLENBQUMsZ0JBQWdCLEtBQUssTUFBTSxNQUFNO0VBQ3RDLE1BQU0sYUFBYSxNQUFNLEVBQUUsYUFBYSxXQUFXLENBQUM7Q0FDeEQ7Q0FFQSxNQUFNLGtCQUFrQixTQUFTO0VBQzdCLGlCQUFpQixLQUFLLEVBQUU7RUFDeEIsWUFBWTtHQUNSLE9BQU8sS0FBSyxTQUFTO0dBQ3JCLGFBQWEsS0FBSyxlQUFlO0dBQ2pDLFNBQVMsaUJBQWlCLEtBQUssT0FBTztFQUMxQyxDQUFDO0VBQ0QsYUFBYSxFQUFFO0NBQ25CO0NBRUEsTUFBTSx5QkFBeUI7RUFDM0IsaUJBQWlCLElBQUk7RUFDckIsWUFBWSxlQUFlO0VBQzNCLGFBQWEsRUFBRTtDQUNuQjtDQUVBLE1BQU0saUJBQWlCLE9BQU8sT0FBTSxTQUFTO0VBQ3pDLE1BQU0sZUFBZTtFQUVyQixNQUFNLFFBQVEsU0FBUyxNQUFNLEtBQUs7RUFDbEMsSUFBSSxDQUFDLE9BQU87R0FDUixhQUFhLDJCQUEyQjtHQUN4QztFQUNKO0VBRUEsSUFBSSxDQUFDLGdCQUFnQixLQUFLLE1BQU0sTUFBTTtHQUNsQyxhQUFhLGtEQUFrRDtHQUMvRDtFQUNKO0VBRUEsYUFBYSxFQUFFO0VBQ2YsTUFBTSxhQUFhLE1BQU0sYUFBYSxNQUFNO0dBQ3hDO0dBQ0EsYUFBYSxTQUFTLFlBQVksS0FBSyxLQUFLO0dBQzVDLFVBQVUsU0FBUyxXQUFXO0VBQ2xDLENBQUM7RUFFRCxJQUFJLFlBQVksaUJBQWlCO0NBQ3JDO0NBRUEsTUFBTSxpQkFBaUIsWUFBWSxLQUFLLENBQUMsQ0FBQyxTQUFTO0NBRW5ELE9BQ0ksd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDSSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0ksd0JBQUMsT0FBRCxZQUNJLHdCQUFDLE1BQUQ7S0FBSSxJQUFHO2VBQW9CO0lBQWM7Ozs7YUFDeEM7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0ksd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxXQUFVO01BQ1YsU0FBUztNQUNULFVBQVU7Z0JBRVQsWUFBWSxlQUFlO0tBQ3hCOzs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxXQUFVO01BQ1YsU0FBUztnQkFDWjtLQUVPOzs7O2FBQ1A7Ozs7O1lBQ0o7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWlCLE1BQUs7Y0FBckM7S0FDSSx3QkFBQyxVQUFEO01BQ0ksTUFBSztNQUNMLE1BQUs7TUFDTCxJQUFHO01BQ0gsV0FBVyxnQkFBZ0IsYUFBYSxXQUFXLGVBQWU7TUFDbEUsZUFBZSxZQUFZLFFBQVE7Z0JBQ3RDO0tBRU87Ozs7O0tBQ1Isd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxNQUFLO01BQ0wsSUFBRztNQUNILFdBQVcsZ0JBQWdCLGFBQWEsY0FBYyxlQUFlO01BQ3JFLGVBQWUsWUFBWSxXQUFXO2dCQUN6QztLQUVPOzs7OztLQUNSLHdCQUFDLFVBQUQ7TUFDSSxNQUFLO01BQ0wsTUFBSztNQUNMLElBQUc7TUFDSCxXQUFXLGdCQUFnQixhQUFhLFlBQVksZUFBZTtNQUNuRSxlQUFlLFlBQVksU0FBUztnQkFDdkM7S0FFTzs7Ozs7SUFDUDs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNJLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0ksd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztlQUNoQyx3QkFBQyxTQUFEO01BQ0ksTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLFVBQVUsZUFBZSxNQUFNLE9BQU8sS0FBSztNQUN0RCxhQUFZO0tBQ2Y7Ozs7YUFDRTs7Ozs7Y0FFUCx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNJLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O2VBQ25CLHdCQUFDLFVBQUQ7TUFDSSxPQUFPO01BQ1AsV0FBVyxVQUFVLFVBQVUsTUFBTSxPQUFPLEtBQUs7Z0JBRnJEO09BSUksd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVc7T0FBbUM7Ozs7O09BQzVELHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFpQjtPQUF3Qzs7Ozs7T0FDdkUsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWlCO09BQXVDOzs7OztNQUNsRTs7Ozs7YUFDTDs7Ozs7WUFDTjs7Ozs7O0dBRUosU0FDRyx3QkFBQyxPQUFEO0lBQUssV0FBVztJQUFrQixNQUFLO2NBQ2xDO0dBQ0E7Ozs7O0dBR1IsbUJBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBa0IsTUFBSztjQUNqQztHQUNBOzs7OztHQUdSLG9CQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFXLHVDQUF1Qyx5QkFBeUIsZUFBZTtJQUFNLE1BQUs7Y0FDckc7R0FDQTs7Ozs7R0FHVCx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFrQixJQUFHO0lBQWtCLE1BQUs7Y0FBM0Q7S0FDSyxhQUNHLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQWMsTUFBSztnQkFBUztLQUFtQjs7Ozs7S0FHL0QsQ0FBQyxhQUFhLENBQUMsU0FBUyxhQUFhLFdBQVcsS0FDN0Msd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1IsaUJBQ0ssTUFBTSxTQUFTLGdCQUFnQixZQUFZLEtBQUssRUFBRSxNQUNsRCxhQUFhLFdBQ1QsZ0NBQ0EsYUFBYSxjQUNULG1DQUNBO0tBQ2Y7Ozs7O0tBR04sQ0FBQyxhQUFhLENBQUMsU0FBUyxhQUFhLEtBQUssVUFDdkMsd0JBQUMsV0FBRDtNQUFTLFdBQVcsYUFBYSxNQUFNLE9BQU8saUJBQWlCLHNCQUFzQjtnQkFBckY7T0FDSyxNQUFNLFNBQ0gsd0JBQUMsT0FBRDtRQUFLLFdBQVcsb0JBQW9CLE1BQU0sT0FBTyxpQkFBaUIsZ0JBQWdCO2tCQUFsRixDQUNJLHdCQUFDLE9BQUQsYUFDSSx3QkFBQyxNQUFELFlBQUssTUFBTSxNQUFVOzs7O2tCQUNwQixNQUFNLGVBQWUsd0JBQUMsS0FBRCxZQUFJLE1BQU0sWUFBZTs7OztnQkFDOUM7Ozs7a0JBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9CLE1BQU0sTUFBTTtRQUFhOzs7O2dCQUM1RDs7Ozs7O09BR1IsTUFBTSxNQUFNLFdBQVcsS0FBSyxNQUFNLE9BQU8sb0JBQ3RDLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNSLGlCQUNLLDZCQUE2QixZQUFZLEtBQUssRUFBRSxNQUNoRDtPQUNQOzs7OztPQUdOLE1BQU0sTUFBTSxXQUFXLEtBQUssTUFBTSxPQUFPLGtCQUN0Qyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDUixpQkFDSywyQkFBMkIsWUFBWSxLQUFLLEVBQUUsTUFDOUM7T0FDUDs7Ozs7T0FHUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFZLE1BQUs7a0JBQzNCLE1BQU0sTUFBTSxLQUFLLE1BQU0sVUFBVTtTQUM5QixNQUFNLFVBQVUsY0FBYyxLQUFLLE9BQU87U0FDMUMsTUFBTSxhQUFhLEtBQUssTUFBTSxRQUFRLE9BQU8sY0FBYyxFQUFFLE1BQU0sT0FBTyxLQUFLLEVBQUU7U0FDakYsTUFBTSxhQUFhLE9BQU8sY0FBYyxNQUFNLE9BQU8sS0FBSyxFQUFFLEtBQUssbUJBQW1CO1NBQ3BGLE1BQU0sYUFBYSxrQkFBa0IsUUFBUSxPQUFPLGNBQWMsTUFBTSxPQUFPLEtBQUssRUFBRTtTQUN0RixNQUFNLFlBQVksaUJBQWlCLFFBQVEsT0FBTyxhQUFhLE1BQU0sT0FBTyxLQUFLLEVBQUU7U0FDbkYsTUFBTSxVQUFVLEtBQUssTUFBTSxHQUFHLE1BQU0sR0FBRyxRQUFRO1NBRS9DLE9BQ0ksd0JBQUMsT0FBRDtVQUFLLFdBQVcsaUJBQWlCLEtBQUssYUFBYSxpQkFBaUIsS0FBSyxhQUFhLGlCQUFpQjtVQUFvQixNQUFLO29CQUFoSTtXQUNJLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFqQixDQUNJLHdCQUFDLFNBQUQ7YUFDSSxNQUFLO2FBQ0wsU0FBUyxLQUFLO2FBQ2QsV0FBVyxVQUFVLHVCQUF1QixNQUFNLE1BQU0sT0FBTyxPQUFPO2FBQ3RFLFVBQVUsQ0FBQyxnQkFBZ0IsS0FBSyxNQUFNLFFBQVEsY0FBYzthQUM1RCxPQUFPLEtBQUssYUFBYSxnQkFBZ0I7WUFDNUM7Ozs7c0JBQ0Qsd0JBQUMsUUFBRCxFQUFNLFdBQVUsNEJBQTRCOzs7O29CQUN6Qzs7Ozs7O1dBRVAsd0JBQUMsVUFBRDtZQUNJLE1BQUs7WUFDTCxXQUFXLFlBQVksYUFBYSxjQUFjLEtBQUssS0FBSyxhQUFhLGVBQWU7WUFDeEYsZUFBZSxlQUFlLElBQUk7WUFDbEMsVUFBVSx5QkFBeUIsS0FBSztZQUN4QyxPQUFPLEtBQUssYUFDTiw4REFDQSx3QkFDSSx1RUFDQSxVQUFVLEtBQUs7c0JBVDdCO2FBV1Esd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQW1CLEtBQUs7YUFBWTs7Ozs7YUFFbkQsS0FBSyxlQUNGLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUNYLEtBQUs7YUFDSjs7Ozs7YUFHVCxXQUNHLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUFxQyxRQUM1QixPQUNIOzs7Ozs7WUFFVjs7Ozs7O1dBRVIsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDSSx3QkFBQyxVQUFEO2FBQ0ksTUFBSzthQUNMLFdBQVU7YUFDVixlQUFlLFlBQVksaUJBQWlCLElBQUksZUFBZSxJQUFJO2FBQ25FLFVBQVUsY0FBYzt1QkFFdkIsWUFBWSxXQUFXO1lBQ3BCOzs7O3NCQUNSLHdCQUFDLFVBQUQ7YUFDSSxNQUFLO2FBQ0wsV0FBVTthQUNWLGVBQWUsZUFBZSxJQUFJO2FBQ2xDLFVBQVUsQ0FBQyxnQkFBZ0IsS0FBSyxNQUFNLFFBQVEsY0FBYzthQUM1RCxPQUFPLFVBQVUsS0FBSzt1QkFFckIsYUFBYSxnQkFBZ0I7WUFDMUI7Ozs7b0JBQ1A7Ozs7OztXQUVKLGFBQ0csd0JBQUMsUUFBRDtZQUFNLFdBQVU7WUFBaUIsV0FBVyxVQUFVLGVBQWUsT0FBTyxJQUFJO3NCQUFoRjthQUNJLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmO2VBQ0ksd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0ksd0JBQUMsU0FBRDtpQkFBTyxTQUFTLG1CQUFtQjsyQkFBVztnQkFBaUI7Ozs7MEJBQy9ELHdCQUFDLFNBQUQ7aUJBQ0ksSUFBSSxtQkFBbUI7aUJBQ3ZCLE1BQUs7aUJBQ0wsT0FBTyxTQUFTO2lCQUNoQixXQUFXLFVBQVUsYUFBYSxhQUFhO2tCQUFFLEdBQUc7a0JBQVMsT0FBTyxNQUFNLE9BQU87aUJBQU0sRUFBRTtpQkFDekYsV0FBVztpQkFDWDtnQkFDSDs7Ozt3QkFDQTs7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0ksd0JBQUMsU0FBRDtpQkFBTyxTQUFTLGlCQUFpQjsyQkFBVztnQkFBZTs7OzswQkFDM0Qsd0JBQUMsU0FBRDtpQkFDSSxJQUFJLGlCQUFpQjtpQkFDckIsTUFBSztpQkFDTCxPQUFPLFNBQVM7aUJBQ2hCLFdBQVcsVUFBVSxhQUFhLGFBQWE7a0JBQUUsR0FBRztrQkFBUyxTQUFTLE1BQU0sT0FBTztpQkFBTSxFQUFFO2dCQUM5Rjs7Ozt3QkFDQTs7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtnQkFBSyxXQUFVOzBCQUFmLENBQ0ksd0JBQUMsU0FBRDtpQkFBTyxTQUFTLHlCQUF5QjsyQkFBVztnQkFBa0I7Ozs7MEJBQ3RFLHdCQUFDLFlBQUQ7aUJBQ0ksSUFBSSx5QkFBeUI7aUJBQzdCLE9BQU8sU0FBUztpQkFDaEIsV0FBVyxVQUFVLGFBQWEsYUFBYTtrQkFBRSxHQUFHO2tCQUFTLGFBQWEsTUFBTSxPQUFPO2lCQUFNLEVBQUU7aUJBQy9GLE1BQU07Z0JBQ1Q7Ozs7d0JBQ0E7Ozs7OztjQUNKOzs7Ozs7YUFFSixhQUNHLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO2NBQWtCLE1BQUs7d0JBQVM7YUFBYTs7Ozs7YUFHOUQsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDSSx3QkFBQyxVQUFEO2VBQ0ksTUFBSztlQUNMLFdBQVU7ZUFDVixTQUFTO2VBQ1QsVUFBVTt5QkFDYjtjQUVPOzs7O3dCQUNSLHdCQUFDLFVBQUQ7ZUFDSSxNQUFLO2VBQ0wsV0FBVTtlQUNWLFVBQVU7eUJBRVQsYUFBYSxjQUFjO2NBQ3hCOzs7O3NCQUNQOzs7Ozs7WUFDSDs7Ozs7O1VBRVQ7WUFuSDZHOzs7O2dCQW1IN0c7UUFFYixDQUFDO09BQ0E7Ozs7O01BQ0E7UUE1SnVGLE1BQU07Ozs7WUE0SjdGLENBQ1o7SUFDQTs7Ozs7O0dBRUwsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0dBRXJCLDBCQUNHLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO2NBQW5CLENBQ0ksd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNJLHdCQUFDLE1BQUQ7TUFBSSxJQUFHO2dCQUFrQztLQUE4Qjs7OztlQUN2RSx3QkFBQyxLQUFELFlBQUcsc0RBQXNEOzs7O2FBQ3hEOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1gsd0JBQUMsVUFBRDtNQUNJLEtBQUk7TUFDSixPQUFNO01BQ04sU0FBUTtNQUNSLGdCQUFlO01BQ2YsT0FBTTtNQUNOO0tBQ0g7Ozs7O0lBQ0E7Ozs7WUFDQTs7Ozs7O0VBRVI7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0VGFza3MgfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGlDbGllbnQuanMnO1xuaW1wb3J0IEZvY3VzU3RhdGlzaWNzQ2hhcnQgZnJvbSAnLi9Gb2N1c1N0YXRpc3RpY3NDaGFydC5qc3gnO1xuXG5mdW5jdGlvbiBub3JtYWxpemVUYXNrcyh0YXNrKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IHRhc2s/LmlkID8/IHRhc2s/LnRhc2tJZCxcbiAgICAgICAgdGl0bGU6IHRhc2s/LnRpdGxlID8/IHRhc2s/Lm5hbWUgPz8gJ1VudGl0bGVkIFRhc2snLFxuICAgICAgICBkZXNjcmlwdGlvbjogdGFzaz8uZGVzY3JpcHRpb24gPz8gJycsXG4gICAgICAgIGR1ZURhdGU6IHRhc2s/LmR1ZURhdGUgPz8gdGFzaz8uZHVlX2RhdGUgPz8gbnVsbCxcbiAgICAgICAgY3JlYXRlZEF0OiB0YXNrPy5jcmVhdGVkQXQgPz8gdGFzaz8uY3JlYXRlZF9hdCA/PyBudWxsLFxuICAgICAgICBpc0NvbXBsZXRlOiBCb29sZWFuKHRhc2s/LmlzQ29tcGxldGUgPz8gdGFzaz8uaXNfY29tcGxldGUgPz8gZmFsc2UpLFxuICAgICAgICBkdXJhdGlvblNlY29uZHM6IHRhc2s/LmR1cmF0aW9uU2Vjb25kcyA/PyB0YXNrPy5kdXJhdGlvbl9zZWNvbmRzID8/IDIwICogNjAsXG4gICAgfTtcbn1cblxuY29uc3QgRU1QVFlfRURJVF9GT1JNID0geyB0aXRsZTogJycsIGRlc2NyaXB0aW9uOiAnJywgZHVlRGF0ZTogJycgfTtcbmNvbnN0IERBWVNfSU5fTUlMTElTRUNPTkRTID0gMjQgKiA2MCAqIDYwICogMTAwMDtcblxuZnVuY3Rpb24gZ2V0RGF0ZU9ubHkodmFsdWUpIHtcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGRhdGVQYXJ0ID0gU3RyaW5nKHZhbHVlKS5zbGljZSgwLCAxMCk7XG4gICAgY29uc3QgbWF0Y2ggPSAvXihcXGR7NH0pLShcXGR7Mn0pLShcXGR7Mn0pJC8uZXhlYyhkYXRlUGFydCk7XG4gICAgaWYgKCFtYXRjaCkgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB5ZWFyID0gTnVtYmVyKG1hdGNoWzFdKTtcbiAgICBjb25zdCBtb250aCA9IE51bWJlcihtYXRjaFsyXSk7XG4gICAgY29uc3QgZGF5ID0gTnVtYmVyKG1hdGNoWzNdKTtcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoeWVhciwgbW9udGggLSAxLCBkYXkpO1xuXG4gICAgaWYgKFxuICAgICAgICBkYXRlLmdldEZ1bGxZZWFyKCkgIT09IHllYXIgfHxcbiAgICAgICAgZGF0ZS5nZXRNb250aCgpICE9PSBtb250aCAtIDEgfHxcbiAgICAgICAgZGF0ZS5nZXREYXRlKCkgIT09IGRheVxuICAgICkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICByZXR1cm4gZGF0ZTtcbn1cblxuZnVuY3Rpb24gZ2V0TG9jYWxEYXlOdW1iZXIoZGF0ZSkge1xuICAgIHJldHVybiBEYXRlLlVUQyhkYXRlLmdldEZ1bGxZZWFyKCksIGRhdGUuZ2V0TW9udGgoKSwgZGF0ZS5nZXREYXRlKCkpIC8gREFZU19JTl9NSUxMSVNFQ09ORFM7XG59XG5cbmZ1bmN0aW9uIGdldERheXNVbnRpbER1ZSh2YWx1ZSkge1xuICAgIGNvbnN0IGR1ZURhdGUgPSBnZXREYXRlT25seSh2YWx1ZSk7XG4gICAgaWYgKCFkdWVEYXRlKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgICByZXR1cm4gZ2V0TG9jYWxEYXlOdW1iZXIoZHVlRGF0ZSkgLSBnZXRMb2NhbERheU51bWJlcih0b2RheSk7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdER1ZURhdGUodmFsdWUpIHtcbiAgICBjb25zdCBkYXRlID0gZ2V0RGF0ZU9ubHkodmFsdWUpO1xuICAgIHJldHVybiBkYXRlID8gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoKSA6IG51bGw7XG59XG5cbmZ1bmN0aW9uIHRvRGF0ZUlucHV0VmFsdWUodmFsdWUpIHtcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gJyc7XG4gICAgY29uc3QgZGF0ZVBhcnQgPSBTdHJpbmcodmFsdWUpLnNsaWNlKDAsIDEwKTtcbiAgICByZXR1cm4gL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3QoZGF0ZVBhcnQpID8gZGF0ZVBhcnQgOiAnJztcbn1cblxuZnVuY3Rpb24gZ2V0Q3JlYXRlZFRpbWVzdGFtcCh2YWx1ZSkge1xuICAgIGlmICghdmFsdWUpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHRpbWVzdGFtcCA9IERhdGUucGFyc2UodmFsdWUpO1xuICAgIHJldHVybiBOdW1iZXIuaXNOYU4odGltZXN0YW1wKSA/IG51bGwgOiB0aW1lc3RhbXA7XG59XG5cbmZ1bmN0aW9uIGNvbXBhcmVUYXNrcyhhLCBiLCBzb3J0QnkpIHtcbiAgICBpZiAoc29ydEJ5ID09PSAnY3JlYXRlZC1uZXdlc3QnIHx8IHNvcnRCeSA9PT0gJ2NyZWF0ZWQtb2xkZXN0Jykge1xuICAgICAgICBjb25zdCBhQ3JlYXRlZCA9IGdldENyZWF0ZWRUaW1lc3RhbXAoYS5jcmVhdGVkQXQpO1xuICAgICAgICBjb25zdCBiQ3JlYXRlZCA9IGdldENyZWF0ZWRUaW1lc3RhbXAoYi5jcmVhdGVkQXQpO1xuXG4gICAgICAgIGlmIChhQ3JlYXRlZCA9PSBudWxsICYmIGJDcmVhdGVkICE9IG51bGwpIHJldHVybiAxO1xuICAgICAgICBpZiAoYUNyZWF0ZWQgIT0gbnVsbCAmJiBiQ3JlYXRlZCA9PSBudWxsKSByZXR1cm4gLTE7XG5cbiAgICAgICAgaWYgKGFDcmVhdGVkICE9IG51bGwgJiYgYkNyZWF0ZWQgIT0gbnVsbCAmJiBhQ3JlYXRlZCAhPT0gYkNyZWF0ZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBzb3J0QnkgPT09ICdjcmVhdGVkLW5ld2VzdCdcbiAgICAgICAgICAgICAgICA/IGJDcmVhdGVkIC0gYUNyZWF0ZWRcbiAgICAgICAgICAgICAgICA6IGFDcmVhdGVkIC0gYkNyZWF0ZWQ7XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBhRHVlID0gZ2V0RGF0ZU9ubHkoYS5kdWVEYXRlKTtcbiAgICAgICAgY29uc3QgYkR1ZSA9IGdldERhdGVPbmx5KGIuZHVlRGF0ZSk7XG5cbiAgICAgICAgaWYgKCFhRHVlICYmIGJEdWUpIHJldHVybiAxO1xuICAgICAgICBpZiAoYUR1ZSAmJiAhYkR1ZSkgcmV0dXJuIC0xO1xuXG4gICAgICAgIGlmIChhRHVlICYmIGJEdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGRpZmZlcmVuY2UgPSBnZXRMb2NhbERheU51bWJlcihhRHVlKSAtIGdldExvY2FsRGF5TnVtYmVyKGJEdWUpO1xuICAgICAgICAgICAgaWYgKGRpZmZlcmVuY2UgIT09IDApIHJldHVybiBkaWZmZXJlbmNlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIFN0cmluZyhhLnRpdGxlKS5sb2NhbGVDb21wYXJlKFN0cmluZyhiLnRpdGxlKSwgdW5kZWZpbmVkLCB7IHNlbnNpdGl2aXR5OiAnYmFzZSd9KTtcbn1cblxuY29uc3QgVEFTS19HUk9VUFMgPSBbXG4gICAgeyBpZDogJ292ZXJkdWUnLCB0aXRsZTogJ092ZXJkdWUnLCBkZXNjcmlwdGlvbjogJ1Rhc2tzIHRoYXQgYXJlIHBhc3QgdGhlaXIgZHVlIGRhdGUnIH0sXG4gICAgeyBpZDogJ3RvZGF5JywgdGl0bGU6ICdUb2RheScsIGRlc2NyaXB0aW9uOiAnVGFza3MgdGhhdCBhcmUgZHVlIHRvZGF5JyB9LFxuICAgIHsgaWQ6ICd1cGNvbWluZycsIHRpdGxlOiAnVXBjb21pbmcnLCBkZXNjcmlwdGlvbjogJ1Rhc2tzIHRoYXQgYXJlIGR1ZSB3aXRoaW4gYSB3ZWVrJyB9LFxuICAgIHsgaWQ6ICdsYXRlcicsIHRpdGxlOiAnTGF0ZXInLCBkZXNjcmlwdGlvbjogJ1Rhc2tzIHRoYXQgYXJlIGR1ZSBhZnRlciBhIHdlZWsgb3IgYXJlIHdpdGhvdXQgYSBkdWUgZGF0ZScgfSxcbl07XG5cbmZ1bmN0aW9uIGdldFRhc2tHcm91cCh0YXNrKSB7XG4gICAgY29uc3QgZGF5c1VudGlsRHVlID0gZ2V0RGF5c1VudGlsRHVlKHRhc2suZHVlRGF0ZSk7XG5cbiAgICBpZiAoZGF5c1VudGlsRHVlID09IG51bGwgfHwgZGF5c1VudGlsRHVlID4gNykgcmV0dXJuICdsYXRlcic7XG4gICAgaWYgKGRheXNVbnRpbER1ZSA8IDApIHJldHVybiB0YXNrLmlzQ29tcGxldGUgPyAnbGF0ZXInIDogJ292ZXJkdWUnO1xuICAgIGlmIChkYXlzVW50aWxEdWUgPT09IDApIHJldHVybiAndG9kYXknO1xuICAgIHJldHVybiAndXBjb21pbmcnO1xufVxuXG5jb25zdCBFTVBUWV9HUk9VUFMgPSBUQVNLX0dST1VQUy5tYXAoKGdyb3VwKSA9PiAoeyAuLi5ncm91cCwgdGFza3M6IFtdIH0pKTtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGFzaGJvYXJkKHtcbiAgICBzZWxlY3RlZFRhc2ssXG4gICAgb25TZWxlY3RUYXNrLFxuICAgIHRhc2tTZWxlY3Rpb25EaXNhYmxlZCA9IGZhbHNlLFxuICAgIHJlZnJlc2hTaWduYWwgPSAwLFxuICAgIG9uRGVsZXRlVGFzayxcbiAgICBkZWxldGluZ1Rhc2tJZCA9IG51bGwsXG4gICAgb25VcGRhdGVUYXNrLFxuICAgIHVwZGF0aW5nVGFza0lkID0gbnVsbCxcbiAgICB0YXNrQWN0aW9uRXJyb3IgPSAnJyxcbiAgICB0YXNrQWN0aW9uTm90aWNlID0gJycsXG4gICAgdGFza0FjdGlvbk5vdGljZUZhZGluZyA9IGZhbHNlLFxuICAgIGlzWW91dHViZVBsYXllckVuYWJsZWQgPSB0cnVlLFxuICAgIG9uTG9nb3V0LFxufSkge1xuICAgIGNvbnN0IFt0YXNrcywgc2V0VGFza3NdID0gdXNlU3RhdGUoW10pO1xuICAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt0YXNrVmlldywgc2V0VGFza1ZpZXddID0gdXNlU3RhdGUoJ2FjdGl2ZScpO1xuICAgIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzb3J0QnksIHNldFNvcnRCeV0gPSB1c2VTdGF0ZSgnZHVlLWRhdGUnKTtcbiAgICBjb25zdCBbZWRpdGluZ1Rhc2tJZCwgc2V0RWRpdGluZ1Rhc2tJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbZWRpdEZvcm0sIHNldEVkaXRGb3JtXSA9IHVzZVN0YXRlKEVNUFRZX0VESVRfRk9STSk7XG4gICAgY29uc3QgW2VkaXRFcnJvciwgc2V0RWRpdEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcblxuICAgIGNvbnN0IGxvYWRUYXNrcyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZVRhc2tzID0gYXdhaXQgZ2V0VGFza3MoKTtcbiAgICAgICAgICAgIGNvbnN0IG5leHRUYXNrcyA9IEFycmF5LmlzQXJyYXkocmVzcG9uc2VUYXNrcylcbiAgICAgICAgICAgICAgICA/IHJlc3BvbnNlVGFza3MubWFwKG5vcm1hbGl6ZVRhc2tzKVxuICAgICAgICAgICAgICAgIDogW107XG4gICAgICAgICAgICBzZXRUYXNrcyhuZXh0VGFza3MpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCBcbiAgICAgICAgICAgICAgICByZXF1ZXN0RXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgICAgICAgICAgICA/IHJlcXVlc3RFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgIDogJ1VuYWJsZSB0byBsb2FkIHRhc2tzLicsIFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSwgW10pO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHsgbG9hZFRhc2tzKCk7IH0sIFtsb2FkVGFza3MsIHJlZnJlc2hTaWduYWxdKTtcblxuICAgIGNvbnN0IGFjdGl2ZVRhc2tzID0gdXNlTWVtbyhcbiAgICAgICAgKCkgPT4gdGFza3MuZmlsdGVyKCh0YXNrKSA9PiAhdGFzay5pc0NvbXBsZXRlKSwgW3Rhc2tzXVxuICAgICk7XG5cbiAgICBjb25zdCBjb21wbGV0ZWRUYXNrcyA9IHVzZU1lbW8oXG4gICAgICAgICgpID0+IHRhc2tzLmZpbHRlcigodGFzaykgPT4gdGFzay5pc0NvbXBsZXRlKSwgW3Rhc2tzXVxuICAgICk7XG5cbiAgICBjb25zdCBvdmVyZHVlVGFza3MgPSB1c2VNZW1vKFxuICAgICAgICAoKSA9PiBhY3RpdmVUYXNrcy5maWx0ZXIoKHRhc2spID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGRheXNVbnRpbER1ZSA9IGdldERheXNVbnRpbER1ZSh0YXNrLmR1ZURhdGUpO1xuICAgICAgICAgICAgcmV0dXJuIGRheXNVbnRpbER1ZSAhPT0gbnVsbCAmJiBkYXlzVW50aWxEdWUgPCAwO1xuICAgICAgICB9KSxcbiAgICAgICAgW2FjdGl2ZVRhc2tzXSxcbiAgICApO1xuXG4gICAgY29uc3QgdmlzaWJsZVRhc2tzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGxldCByZXN1bHQ7XG5cbiAgICAgICAgaWYgKHRhc2tWaWV3ID09PSAnY29tcGxldGVkJykge1xuICAgICAgICAgICAgcmVzdWx0ID0gY29tcGxldGVkVGFza3M7XG4gICAgICAgIH0gZWxzZSBpZiAodGFza1ZpZXcgPT09ICdvdmVyZHVlJykge1xuICAgICAgICAgICAgcmVzdWx0ID0gb3ZlcmR1ZVRhc2tzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzdWx0ID0gYWN0aXZlVGFza3M7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBub3JtYWxpemVkUXVlcnkgPSBzZWFyY2hRdWVyeS50cmltKCkudG9Mb2NhbGVMb3dlckNhc2UoKTtcbiAgICAgICAgaWYgKG5vcm1hbGl6ZWRRdWVyeSkge1xuICAgICAgICAgICAgcmVzdWx0ID0gcmVzdWx0LmZpbHRlcigodGFzaykgPT5cbiAgICAgICAgICAgICAgICBTdHJpbmcodGFzay50aXRsZSkudG9Mb2NhbGVMb3dlckNhc2UoKS5pbmNsdWRlcyhub3JtYWxpemVkUXVlcnkpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBbLi4ucmVzdWx0XS5zb3J0KChhLCBiKSA9PiBjb21wYXJlVGFza3MoYSwgYiwgc29ydEJ5KSk7XG4gICAgfSwgW2FjdGl2ZVRhc2tzLCBjb21wbGV0ZWRUYXNrcywgb3ZlcmR1ZVRhc2tzLCBzZWFyY2hRdWVyeSwgc29ydEJ5LCB0YXNrVmlld10pO1xuXG4gICAgY29uc3QgZ3JvdXBlZFRhc2tzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgICAgIGlmICh0YXNrVmlldyA9PT0gJ2NvbXBsZXRlZCcpIHtcbiAgICAgICAgICAgIHJldHVybiBbeyBpZDogJ2NvbXBsZXRlZCcsIHRpdGxlOiAnQ29tcGxldGVkIFRhc2tzJywgdGFza3M6IHZpc2libGVUYXNrc31dO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgZ3JvdXBzID0gRU1QVFlfR1JPVVBTLm1hcCgoZ3JvdXApID0+ICh7IC4uLmdyb3VwLCB0YXNrczogW10gfSkpO1xuICAgICAgICBjb25zdCBncm91cHNCeUlkID0gbmV3IE1hcChncm91cHMubWFwKChncm91cCkgPT4gW2dyb3VwLmlkLCBncm91cF0pKTtcblxuICAgICAgICB2aXNpYmxlVGFza3MuZm9yRWFjaCgodGFzaykgPT4ge1xuICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGdldFRhc2tHcm91cCh0YXNrKTtcbiAgICAgICAgICAgIGdyb3Vwc0J5SWQuZ2V0KGdyb3VwSWQpPy50YXNrcy5wdXNoKHRhc2spO1xuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gZ3JvdXBzLmZpbHRlcigoZ3JvdXApID0+IGdyb3VwLnRhc2tzLmxlbmd0aCA+IDApO1xuICAgIH0sIFt0YXNrVmlldywgdmlzaWJsZVRhc2tzXSk7XG5cbiAgICBjb25zdCBoYW5kbGVDb21wbGV0aW9uQ2hhbmdlID0gYXN5bmMgKHRhc2ssIGlzQ29tcGxldGUpID0+IHtcbiAgICAgICAgaWYgKCFvblVwZGF0ZVRhc2sgfHwgdGFzay5pZCA9PSBudWxsKSByZXR1cm47XG4gICAgICAgIGF3YWl0IG9uVXBkYXRlVGFzayh0YXNrLCB7IGlzX2NvbXBsZXRlOiBpc0NvbXBsZXRlIH0pO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVFZGl0T3BlbiA9ICh0YXNrKSA9PiB7XG4gICAgICAgIHNldEVkaXRpbmdUYXNrSWQodGFzay5pZCk7XG4gICAgICAgIHNldEVkaXRGb3JtKHtcbiAgICAgICAgICAgIHRpdGxlOiB0YXNrLnRpdGxlID8/ICcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IHRhc2suZGVzY3JpcHRpb24gPz8gJycsXG4gICAgICAgICAgICBkdWVEYXRlOiB0b0RhdGVJbnB1dFZhbHVlKHRhc2suZHVlRGF0ZSksXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRFZGl0RXJyb3IoJycpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVFZGl0Q2FuY2VsID0gKCkgPT4ge1xuICAgICAgICBzZXRFZGl0aW5nVGFza0lkKG51bGwpO1xuICAgICAgICBzZXRFZGl0Rm9ybShFTVBUWV9FRElUX0ZPUk0pO1xuICAgICAgICBzZXRFZGl0RXJyb3IoJycpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVFZGl0U2F2ZSA9IGFzeW5jIChldmVudCx0YXNrKSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgY29uc3QgdGl0bGUgPSBlZGl0Rm9ybS50aXRsZS50cmltKCk7XG4gICAgICAgIGlmICghdGl0bGUpIHtcbiAgICAgICAgICAgIHNldEVkaXRFcnJvcignQSB0YXNrIG11c3QgaGF2ZSBhIHRpdGxlLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFvblVwZGF0ZVRhc2sgfHwgdGFzay5pZCA9PSBudWxsKSB7XG4gICAgICAgICAgICBzZXRFZGl0RXJyb3IoJ1RoZSB0YXNrIGNhbm5vdCBiZSB1cGRhdGVkIGFzIGl0IGhhcyBubyB0YXNrIElELicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0RWRpdEVycm9yKCcnKTtcbiAgICAgICAgY29uc3Qgd2FzVXBkYXRlZCA9IGF3YWl0IG9uVXBkYXRlVGFzayh0YXNrLCB7IFxuICAgICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogZWRpdEZvcm0uZGVzY3JpcHRpb24udHJpbSgpIHx8IG51bGwsXG4gICAgICAgICAgICBkdWVfZGF0ZTogZWRpdEZvcm0uZHVlRGF0ZSB8fCBudWxsLFxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAod2FzVXBkYXRlZCkgaGFuZGxlRWRpdENhbmNlbCgpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYXNTZWFyY2hRdWVyeSA9IHNlYXJjaFF1ZXJ5LnRyaW0oKS5sZW5ndGggPiAwO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZGFzaGJvYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDEgaWQ9XCJkYXNoYm9hcmQtaGVhZGluZ1wiPllvdXIgVGFza3M8L2gxPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtaGVhZGVyLWFjdGlvbnNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWZyZXNoLXRhc2tzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2xvYWRUYXNrc31cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAnTG9hZGluZy4uLicgOiAnUmVmcmVzaCBUYXNrcyd9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImxvZ291dC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17b25Mb2dvdXR9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIExvZyBPdXRcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YXNrLXZpZXctdGFic1wiIHJvbGU9XCJ0YWJsaXN0XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgcm9sZT1cInRhYlwiXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYWN0aXZlLXRhc2tzLXRhYlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRhc2stdmlldy10YWIke3Rhc2tWaWV3ID09PSAnYWN0aXZlJyA/ICcgaXMtYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhc2tWaWV3KCdhY3RpdmUnKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEFjdGl2ZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIHJvbGU9XCJ0YWJcIlxuICAgICAgICAgICAgICAgICAgICBpZD1cImNvbXBsZXRlZC10YXNrcy10YWJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0YXNrLXZpZXctdGFiJHt0YXNrVmlldyA9PT0gJ2NvbXBsZXRlZCcgPyAnIGlzLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYXNrVmlldygnY29tcGxldGVkJyl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDb21wbGV0ZWRcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICByb2xlPVwidGFiXCJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJvdmVyZHVlLXRhc2tzLXRhYlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRhc2stdmlldy10YWIke3Rhc2tWaWV3ID09PSAnb3ZlcmR1ZScgPyAnIGlzLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYXNrVmlldygnb3ZlcmR1ZScpfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgT3ZlcmR1ZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFzay1maWx0ZXItdG9vbGJhclwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0YXNrLXNlYXJjaC1maWVsZFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZWFyY2ggYnkgVGFzayBUaXRsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2VhcmNoXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldFNlYXJjaFF1ZXJ5KGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCB5b3VyIHRhc2tzLi4uXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRhc2stc29ydC1maWVsZFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Tb3J0IEJ5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c29ydEJ5fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0U29ydEJ5KGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkdWUtZGF0ZVwiPkR1ZSBEYXRlIChEZXNjZW5kaW5nIE9yZGVyKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNyZWF0ZWQtbmV3ZXN0XCI+Q3JlYXRpb24gRGF0ZSAoRGVzY2VuZGluZyBPcmRlcik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcmVhdGVkLW9sZGVzdFwiPkNyZWF0aW9uIERhdGUgKEFzY2VuZGluZyBPcmRlcik8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lID1cImRhc2hib2FyZC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7dGFza0FjdGlvbkVycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICB7dGFza0FjdGlvbkVycm9yfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge3Rhc2tBY3Rpb25Ob3RpY2UgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZGFzaGJvYXJkLW5vdGljZSBhdXRvLWRpc21pc3Mtbm90aWNlJHt0YXNrQWN0aW9uTm90aWNlRmFkaW5nID8gJyBpcy1mYWRpbmcnIDogJyd9YH0gcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICB7dGFza0FjdGlvbk5vdGljZX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFzay1saXN0LXBhbmVsXCIgaWQ9XCJ0YXNrLWxpc3QtcGFuZWxcIiByb2xlPVwidGFicGFuZWxcIj5cbiAgICAgICAgICAgICAgICB7aXNMb2FkaW5nICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZW1wdHktc3RhdGVcIiByb2xlPVwic3RhdHVzXCI+TG9hZGluZyB0YXNrcy4uLjwvcD5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiYgIWVycm9yICYmIHZpc2libGVUYXNrcy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2hhc1NlYXJjaFF1ZXJ5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgTm8gJHt0YXNrVmlld30gdGFza3MgbWF0Y2ggXCIke3NlYXJjaFF1ZXJ5LnRyaW0oKX1cIi5gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB0YXNrVmlldyA9PT0gJ2FjdGl2ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnTm8gYWN0aXZlIHRhc2tzIHdlcmUgZm91bmQuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHRhc2tWaWV3ID09PSAnY29tcGxldGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnTm8gY29tcGxldGVkIHRhc2tzIHdlcmUgZm91bmQuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnWW91IGhhdmUgbm8gb3ZlcmR1ZSB0YXNrcy4nfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHshaXNMb2FkaW5nICYmICFlcnJvciAmJiBncm91cGVkVGFza3MubWFwKChncm91cCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9e2B0YXNrLWdyb3VwJHtncm91cC5pZCA9PT0gJ292ZXJkdWUtdmlldycgPyAnIGlzLW92ZXJkdWUtZ3JvdXAnIDogJyd9YH0ga2V5PXtncm91cC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAudGl0bGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGFzay1ncm91cC1oZWFkZXIke2dyb3VwLmlkID09PSAnb3ZlcmR1ZS12aWV3JyA/ICcgaXMtb3ZlcmR1ZScgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMj57Z3JvdXAudGl0bGV9PC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5kZXNjcmlwdGlvbiAmJiA8cD57Z3JvdXAuZGVzY3JpcHRpb259PC9wPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stZ3JvdXAtY291bnRcIj57Z3JvdXAudGFza3MubGVuZ3RofTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC50YXNrcy5sZW5ndGggPT09IDAgJiYgZ3JvdXAuaWQgPT09ICdjb21wbGV0ZWQtdmlldycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoYXNTZWFyY2hRdWVyeVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgTm8gY29tcGxldGVkIHRhc2tzIG1hdGNoIFwiJHtzZWFyY2hRdWVyeS50cmltKCl9XCIuYFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnWW91IGhhdmUgbm8gY29tcGxldGVkIHRhc2tzLid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLnRhc2tzLmxlbmd0aCA9PT0gMCAmJiBncm91cC5pZCA9PT0gJ292ZXJkdWUtdmlldycgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtoYXNTZWFyY2hRdWVyeVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgTm8gb3ZlcmR1ZSB0YXNrcyBtYXRjaCBcIiR7c2VhcmNoUXVlcnkudHJpbSgpfVwiLmBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ1lvdSBoYXZlIG5vIG92ZXJkdWUgdGFza3MuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbGlzdFwiIHJvbGU9XCJsaXN0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLnRhc2tzLm1hcCgodGFzaywgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZHVlRGF0ZSA9IGZvcm1hdER1ZURhdGUodGFzay5kdWVEYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHRhc2suaWQgIT0gbnVsbCAmJiBTdHJpbmcoc2VsZWN0ZWRUYXNrPy5pZCkgPT09IFN0cmluZyh0YXNrLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEZWxldGluZyA9IFN0cmluZyhkZWxldGluZ1Rhc2tJZCkgPT09IFN0cmluZyh0YXNrLmlkKSAmJiBkZWxldGluZ1Rhc2tJZCAhPT0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNVcGRhdGluZyA9IHVwZGF0aW5nVGFza0lkICE9IG51bGwgJiYgU3RyaW5nKHVwZGF0aW5nVGFza0lkKSA9PT0gU3RyaW5nKHRhc2suaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0VkaXRpbmcgPSBlZGl0aW5nVGFza0lkICE9IG51bGwgJiYgU3RyaW5nKGVkaXRpbmdUYXNrSWQpID09PSBTdHJpbmcodGFzay5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRhc2tLZXkgPSB0YXNrLmlkID8/IGAke2dyb3VwLmlkfS10YXNrLSR7aW5kZXh9YDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0YXNrLWxpc3QtaXRlbSR7dGFzay5pc0NvbXBsZXRlID8gJyBpcy1jb21wbGV0ZScgOiAnJ30ke2lzU2VsZWN0ZWQgPyAnIGlzLXNlbGVjdGVkJyA6ICcnfWB9IGtleT17dGFza0tleX0gcm9sZT1cImxpc3RpdGVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRhc2stY29tcGxldGlvbi1jb250cm9sXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Rhc2suaXNDb21wbGV0ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IGhhbmRsZUNvbXBsZXRpb25DaGFuZ2UodGFzaywgZXZlbnQudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFvblVwZGF0ZVRhc2sgfHwgdGFzay5pZCA9PSBudWxsIHx8IGlzVXBkYXRpbmcgfHwgaXNEZWxldGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0YXNrLmlzQ29tcGxldGUgPyAnUmVvcGVuIFRhc2snIDogJ01hcmsgYXMgQ29tcGxldGUnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YXNrLWNvbXBsZXRpb24taW5kaWNhdG9yXCIvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRhc2stY2FyZCR7aXNTZWxlY3RlZCA/ICcgc2VsZWN0ZWQnIDogJyd9JHt0YXNrLmlzQ29tcGxldGUgPyAnIGNvbXBsZXRlZCcgOiAnJ31gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdFRhc2s/Lih0YXNrKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3Rhc2tTZWxlY3Rpb25EaXNhYmxlZCB8fCB0YXNrLmlzQ29tcGxldGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0YXNrLmlzQ29tcGxldGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ1Jlb3BlbiB0aGlzIHRhc2sgYmVmb3JlIHNlbGVjdGluZyBpdCBmb3IgYSBmb2N1cyBzZXNzaW9uLidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdGFza1NlbGVjdGlvbkRpc2FibGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnRmluaXNoIG9yIHJlc2V0IHRoZSBjdXJyZW50IHNlc3Npb24gYmVmb3JlIHNlbGVjdGluZyBhbm90aGVyIHRhc2suJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYFNlbGVjdCAke3Rhc2sudGl0bGV9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YXNrLWNhcmQtdGl0bGVcIj57dGFzay50aXRsZX08L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YXNrLWNhcmQtZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2suZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2R1ZURhdGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stY2FyZC1kdWUtZGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEdWUge2R1ZURhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFzay1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFzay1lZGl0LWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBpc0VkaXRpbmcgPyBoYW5kbGVFZGl0Q2FuY2VsKCkgOiBoYW5kbGVFZGl0T3Blbih0YXNrKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1VwZGF0aW5nIHx8IGlzRGVsZXRpbmd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyAnQ2FuY2VsJyA6ICdFZGl0J31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFzay1kZWxldGUtYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGVsZXRlVGFzaz8uKHRhc2spfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFvbkRlbGV0ZVRhc2sgfHwgdGFzay5pZCA9PSBudWxsIHx8IGlzRGVsZXRpbmcgfHwgaXNVcGRhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgRGVsZXRlICR7dGFzay50aXRsZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNEZWxldGluZyA/ICdEZWxldGluZy4uLicgOiAnRGVsZXRlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFZGl0aW5nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwidGFzay1lZGl0LWZvcm1cIiBvblN1Ym1pdD17KGV2ZW50KSA9PiBoYW5kbGVFZGl0U2F2ZShldmVudCwgdGFzayl9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YXNrLWVkaXQtZ3JpZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGFzay1lZGl0LWZpZWxkIHRhc2stZWRpdC10aXRsZS1maWVsZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YGVkaXQtdGFzay10aXRsZS0ke3Rhc2tLZXl9YH0+VGFzayBUaXRsZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BlZGl0LXRhc2stdGl0bGUtJHt0YXNrS2V5fWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdEZvcm0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFZGl0Rm9ybSgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgdGl0bGU6IGV2ZW50LnRhcmdldC52YWx1ZSB9KSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezEyMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0YXNrLWVkaXQtZmllbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BlZGl0LXRhc2stZHVlLSR7dGFza0tleX1gfT5EdWUgRGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BlZGl0LXRhc2stZHVlLSR7dGFza0tleX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRGb3JtLmR1ZURhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRFZGl0Rm9ybSgoY3VycmVudCkgPT4gKHsgLi4uY3VycmVudCwgZHVlRGF0ZTogZXZlbnQudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stZWRpdC1maWVsZCB0YXNrLWVkaXQtZGVzY3JpcHRpb24tZmllbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BlZGl0LXRhc2stZGVzY3JpcHRpb24tJHt0YXNrS2V5fWB9PkRlc2NyaXB0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD17YGVkaXQtdGFzay1kZXNjcmlwdGlvbi0ke3Rhc2tLZXl9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0Rm9ybS5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEVkaXRGb3JtKChjdXJyZW50KSA9PiAoeyAuLi5jdXJyZW50LCBkZXNjcmlwdGlvbjogZXZlbnQudGFyZ2V0LnZhbHVlIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VkaXRFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGFzay1lZGl0LWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2VkaXRFcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stZWRpdC1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFzay1lZGl0LWNhbmNlbC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFZGl0Q2FuY2VsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNVcGRhdGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRhc2stZWRpdC1zYXZlLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1VwZGF0aW5nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVXBkYXRpbmcgPyAnU2F2aW5nLi4uJyA6ICdTYXZlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8Rm9jdXNTdGF0aXNpY3NDaGFydCAvPlxuXG4gICAgICAgICAgICB7aXNZb3V0dWJlUGxheWVyRW5hYmxlZCAmJiAoXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXlvdXR1YmUtbXVzaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQteW91dHViZS1tdXNpYy1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBpZD1cImRhc2hib2FyZC15b3V0dWJlLW11c2ljLWhlYWRpbmdcIj5Mby1maSBZb3VUdWJlIFN0dWR5IFN0cmVhbTwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5QbGF5IGJhY2tncm91bmQgbXVzaWMgd2hpbGUgeW91IHdvcmsgb24geW91ciB0YXNrcy48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwieW91dHViZS1wbGF5ZXItZnJhbWVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpZnJhbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9XCJodHRwczovL3d3dy55b3V0dWJlLW5vY29va2llLmNvbS9lbWJlZC9xR29odEdDNVJ0az9yZWw9MCZwbGF5c2lubGluZT0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlN0dWR5IFdpdGggTWUg8J+TmiBQb21vZG9yb1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz1cImxhenlcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PSdzdHJpY3Qtb3JpZ2luLXdoZW4tY3Jvc3Mtb3JpZ2luJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93PVwiYWNjZWxlcm9tZXRlcjsgY2xpcGJvYXJkLXdyaXRlOyBlbmNyeXB0ZWQtbWVkaWE7IGd5cm9zY29wZTsgcGljdHVyZS1pbi1waWN0dXJlOyB3ZWItc2hhcmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsbG93RnVsbFNjcmVlblxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgICk7XG59Il19