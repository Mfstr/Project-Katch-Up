import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SmartFocusUI.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=b4895507";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b4895507";
import { createTask, deleteTask, getTimerStatus, logout, pauseTimer, resetTimer, startTimer, stopTimer, updateTask } from "/src/services/apiClient.js";
import StartSessionButton from "/src/components/StartSessionButton.jsx";
import Dashboard from "/src/components/Dashboard.jsx";
import PomodoroTimer from "/src/components/PomodoroTimer.jsx";
import SettingsPanel from "/src/components/SettingsPanel.jsx";
import InsightAlert from "/src/components/InsightAlert.jsx";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b4895507";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const DEFAULT_FOCUS_SECONDS = 20 * 60;
const SHORT_BREAK_SECONDS = 5 * 60;
const EMPTY_TASK_FORM = {
	title: "",
	description: "",
	dueDate: ""
};
function readSavedTask() {
	try {
		const savedTask = window.localStorage.getItem("project-katchup-selected-task");
		return savedTask ? JSON.parse(savedTask) : null;
	} catch {
		return null;
	}
}
function useAutoDismissNotice(notice, clearNotice, fadeAfterMs = 3500, fadeDurationMs = 450) {
	_s();
	const [isFading, setIsFading] = useState(false);
	useEffect(() => {
		if (!notice) {
			setIsFading(false);
			return undefined;
		}
		setIsFading(false);
		const fadeTimeout = window.setTimeout(() => setIsFading(true), fadeAfterMs);
		const clearTimeoutId = window.setTimeout(clearNotice, fadeAfterMs + fadeDurationMs);
		return () => {
			window.clearTimeout(fadeTimeout);
			window.clearTimeout(clearTimeoutId);
		};
	}, [
		notice,
		clearNotice,
		fadeAfterMs,
		fadeDurationMs
	]);
	return isFading;
}
_s(useAutoDismissNotice, "lmqng1GcDj1d3lPdAAp1zhQA/e4=");
export default function SmartFocusUI() {
	_s2();
	const navigate = useNavigate();
	const [task, setTask] = useState(readSavedTask);
	const [phase, setPhase] = useState("FOCUS");
	const [remainingSeconds, setRemainingSeconds] = useState(DEFAULT_FOCUS_SECONDS);
	const [endTime, setEndTime] = useState(null);
	const [isActive, setActive] = useState(false);
	const [hasStartedSession, setHasStartedSession] = useState(() => {
		try {
			return window.sessionStorage.getItem("project-katchup-session-started") === "true";
		} catch {
			return false;
		}
	});
	const [isLoading, setLoading] = useState(false);
	const [message, setMessage] = useState("");
	const [error, setError] = useState("");
	const [sessionCompleted, setSessionCompleted] = useState(false);
	const [taskRefreshSignal, setTaskRefreshSignal] = useState(0);
	const [isTaskManagerOpen, setTaskManagerOpen] = useState(false);
	const [taskForm, setTaskForm] = useState(EMPTY_TASK_FORM);
	const [isCreatingTask, setCreatingTask] = useState(false);
	const [deletingTaskId, setDeletingTaskId] = useState(null);
	const [updatingTaskId, setUpdatingTaskId] = useState(null);
	const [taskError, setTaskError] = useState("");
	const [taskNotice, setTaskNotice] = useState("");
	const [taskActionError, setTaskActionError] = useState("");
	const [taskActionNotice, setTaskActionNotice] = useState("");
	const clearMessageNotice = useCallback(() => setMessage(""), []);
	const clearTaskNotice = useCallback(() => setTaskNotice(""), []);
	const clearTaskActionNotice = useCallback(() => setTaskActionNotice(""), []);
	const isMessageFading = useAutoDismissNotice(message, clearMessageNotice);
	const isTaskNoticeFading = useAutoDismissNotice(taskNotice, clearTaskNotice);
	const isTaskActionNoticeFading = useAutoDismissNotice(taskActionNotice, clearTaskActionNotice);
	const chimeRef = useRef(null);
	const completionHandledRef = useRef(false);
	const notificationPermRequestRef = useRef(false);
	const [background, setBackground] = useState(() => {
		try {
			return window.localStorage.getItem("project-katchup-background") || "plain";
		} catch {
			return "plain";
		}
	});
	const [isYoutubePlayerEnabled, setYoutubePlayerEnabled] = useState(() => {
		try {
			return window.localStorage.getItem("project-katchup-youtube-player-enabled") === "true";
		} catch {
			return false;
		}
	});
	const updateSessionStarted = useCallback((started) => {
		setHasStartedSession(started);
		try {
			if (started) {
				window.sessionStorage.setItem("project-katchup-session-started", "true");
			} else {
				window.sessionStorage.removeItem("project-katchup-session-started");
			}
		} catch {}
	}, []);
	const applyTimerStatus = useCallback((status) => {
		if (!status) return;
		const nextPhase = status.phase ?? "FOCUS";
		const nextRemaining = Number(status.remainingSeconds);
		setPhase(nextPhase);
		setRemainingSeconds(Number.isFinite(nextRemaining) ? nextRemaining : nextPhase === "SHORT_BREAK" ? SHORT_BREAK_SECONDS : DEFAULT_FOCUS_SECONDS);
		setActive(Boolean(status.isActive));
		setEndTime(status.endTime ? new Date(status.endTime).getTime() : null);
		if (status.isActive) {
			updateSessionStarted(true);
		} else if (Number.isFinite(nextRemaining) && nextRemaining <= 0) {
			updateSessionStarted(false);
			setSessionCompleted(true);
		}
	}, [updateSessionStarted]);
	const refreshTimer = useCallback(async () => {
		const status = await getTimerStatus();
		applyTimerStatus(status);
	}, [applyTimerStatus]);
	useEffect(() => {
		if (typeof window === "undefined" || !("Notification" in window)) return;
		if (Notification.permission !== "default") return;
		if (notificationPermRequestRef.current) return;
		notificationPermRequestRef.current = true;
		try {
			Notification.requestPermission().catch((permissionError) => {
				console.warn("Unable to request notification permission.", permissionError);
			});
		} catch (permissionError) {
			console.warn("Unable to request notification permission.", permissionError);
		}
	}, []);
	const showCompletionNotification = useCallback(() => {
		if (typeof window === "undefined" || !("Notification" in window)) return;
		if (Notification.permission !== "granted") return;
		try {
			const notification = new Notification("Timer Complete", {
				body: task?.title ? `Your session for "${task.title}" is complete.` : "Your timer has finished.",
				tag: "project-katchup-timer-complete"
			});
			notification.onClick = () => {
				window.focus();
				notification.close();
			};
		} catch (notificationError) {
			console.warn("Unable to show the timer completion notification.", notificationError);
		}
	}, [task?.title]);
	useEffect(() => {
		if (typeof Audio === "undefined") return undefined;
		const chime = new Audio(`${import.meta.env.BASE_URL}audio/timer-chime.mp3`);
		chime.preload = "auto";
		chime.volume = .75;
		chimeRef.current = chime;
		return () => {
			chime.pause();
			chime.currentTime = 0;
			chimeRef.current = null;
		};
	}, []);
	const playCompletionChime = useCallback(() => {
		const chime = chimeRef.current;
		if (!chime) return;
		chime.currentTime = 0;
		chime.play().catch((playbackError) => {
			console.warn("Unable to play the timer completion chime.", playbackError);
		});
	}, []);
	useEffect(() => {
		refreshTimer().catch(() => {
			// Default local timer state can still be used if server is down.
		});
	}, [refreshTimer]);
	useEffect(() => {
		if (!isActive || !endTime) return undefined;
		const updateCountdown = () => {
			const nextRemaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1e3));
			setRemainingSeconds(nextRemaining);
			if (nextRemaining === 0 && !completionHandledRef.current) {
				completionHandledRef.current = true;
				setSessionCompleted(true);
				updateSessionStarted(false);
				playCompletionChime();
				showCompletionNotification();
				refreshTimer().catch(() => setActive(false));
			}
		};
		updateCountdown();
		const intervalId = window.setInterval(updateCountdown, 250);
		return () => window.clearInterval(intervalId);
	}, [
		endTime,
		isActive,
		playCompletionChime,
		refreshTimer,
		showCompletionNotification,
		updateSessionStarted
	]);
	const runTimerAction = async (action, onSuccess) => {
		setLoading(true);
		setError("");
		try {
			const response = await action();
			onSuccess?.(response);
			if (response?.endTime) {
				setEndTime(new Date(response.endTime).getTime());
			}
			await refreshTimer();
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Unable to update the timer.");
		} finally {
			setLoading(false);
		}
	};
	const startSession = async () => {
		if (!task || task.id == null) {
			setError("Select a task from the dashboard before starting a session.");
			return;
		}
		if (isActive || hasStartedSession || isLoading) return;
		completionHandledRef.current = false;
		setSessionCompleted(false);
		setLoading(true);
		setMessage("");
		setError("");
		try {
			await resetTimer();
			setPhase("FOCUS");
			setEndTime(null);
			const response = await startTimer({
				taskId: task.id,
				durationSeconds: task.durationSeconds ?? DEFAULT_FOCUS_SECONDS
			});
			updateSessionStarted(true);
			if (response?.endTime) {
				setEndTime(new Date(response.endTime).getTime());
			}
			setMessage(`Session Started: ${task.title}`);
			await refreshTimer();
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Session was unable to start.");
		} finally {
			setLoading(false);
		}
	};
	const handleLogout = async () => {
		const confirmed = window.confirm("Are you sure you want to log out?");
		if (!confirmed) return;
		try {
			await logout();
		} catch {} finally {
			try {
				window.sessionStorage.removeItem("project-katchup-session-started");
				window.sessionStorage.removeItem("project-katchup-selected-task");
				window.localStorage.removeItem("project-katchup-selected-task");
			} catch {}
			navigate("/login", { replace: true });
		}
	};
	const handleBackgroundChange = (nextBackground) => {
		setBackground(nextBackground);
		try {
			window.localStorage.setItem("project-katchup-background", nextBackground);
		} catch {}
	};
	const handleYoutubePlayerToggle = () => {
		const nextEnabled = !isYoutubePlayerEnabled;
		setYoutubePlayerEnabled(nextEnabled);
		try {
			window.localStorage.setItem("project-katchup-youtube-player-enabled", String(nextEnabled));
		} catch {}
	};
	const handleSelectTask = (selectedTask) => {
		if (hasStartedSession) return;
		setTask(selectedTask);
		try {
			window.sessionStorage.setItem("project-katchup-selected-task", JSON.stringify(selectedTask));
		} catch {}
		setMessage("");
		setError("");
	};
	const handleTasksChanged = useCallback((deletedTaskId = null) => {
		setTaskRefreshSignal((currentSignal) => currentSignal + 1);
		if (deletedTaskId !== null && String(task?.id) === String(deletedTaskId) && !isActive && !hasStartedSession) {
			setTask(null);
			try {
				window.sessionStorage.removeItem("project-katchup-selected-task");
			} catch {}
		}
	}, [
		hasStartedSession,
		isActive,
		task?.id
	]);
	const handleTaskManagerToggle = () => {
		setTaskManagerOpen((isOpen) => !isOpen);
		setTaskNotice("");
		setTaskError("");
	};
	const handleTaskManagerClose = () => setTaskManagerOpen(false);
	const handleTaskFormChange = (field, value) => {
		setTaskForm((currentForm) => ({
			...currentForm,
			[field]: value
		}));
	};
	const handleCreateTask = async (event) => {
		event.preventDefault();
		const title = taskForm.title.trim();
		if (!title) {
			setTaskError("Enter a title for your task.");
			return;
		}
		setCreatingTask(true);
		setTaskError("");
		setTaskNotice("");
		try {
			await createTask({
				title,
				description: taskForm.description.trim() || null,
				due_date: taskForm.dueDate || null
			});
			setTaskForm(EMPTY_TASK_FORM);
			setTaskNotice(`Added "${title}" to your tasks.`);
			setTaskRefreshSignal((currentSignal) => currentSignal + 1);
		} catch (requestError) {
			setTaskError(requestError instanceof Error ? requestError.message : "Unable to create your task.");
		} finally {
			setCreatingTask(false);
		}
	};
	const handleDeleteTask = async (tasktoDelete) => {
		const taskId = tasktoDelete?.id ?? tasktoDelete?.taskId;
		const taskTitle = tasktoDelete?.title ?? tasktoDelete?.name ?? "Untitled task";
		if (taskId == null) {
			setTaskActionError("This task cannot be deleted because it has no task ID.");
			return;
		}
		const confirmed = window.confirm(`Are you sure you want to delete "${taskTitle}"? This will remove it from your active task list.`);
		if (!confirmed) return;
		setDeletingTaskId(taskId);
		setTaskActionError("");
		setTaskActionNotice("");
		try {
			await deleteTask(taskId);
			setTaskActionNotice(`Deleted "${taskTitle}".`);
			handleTasksChanged(taskId);
		} catch (requestError) {
			setTaskActionError(requestError instanceof Error ? requestError.message : "Unable to delete your task.");
		} finally {
			setDeletingTaskId(null);
		}
	};
	const handleUpdateTask = async (taskToUpdate, updates) => {
		const taskId = taskToUpdate?.id ?? taskToUpdate?.taskId;
		const taskTitle = taskToUpdate?.title ?? taskToUpdate?.name ?? "Untitled Task";
		if (taskId == null) {
			setTaskActionError("This task cannot be updated because it does not have a task ID.");
			return false;
		}
		setUpdatingTaskId(taskId);
		setTaskActionError("");
		setTaskActionNotice("");
		try {
			const updatedTask = await updateTask(taskId, updates);
			if (!updatedTask) {
				throw new Error("The given task could not be found. Refresh your task list and try again.");
			}
			setTask((currentTask) => {
				if (!currentTask || String(currentTask.id) !== String(taskId)) {
					return currentTask;
				}
				const hasOwn = (key) => Object.prototype.hasOwnProperty.call(updatedTask, key);
				const nextDueDate = hasOwn("dueDate") ? updatedTask.dueDate : hasOwn("due_date") ? updatedTask.due_date : updates.due_date ?? updates.dueDate ?? currentTask.dueDate;
				const nextDescription = hasOwn("description") ? updatedTask.description : updates.description ?? currentTask.description;
				const nextIsComplete = updatedTask.isComplete ?? updatedTask.is_complete ?? updates.is_complete ?? updates.isComplete ?? currentTask.isComplete;
				return {
					...currentTask,
					...updatedTask,
					title: updatedTask.title ?? updates.title ?? currentTask.title,
					description: nextDescription,
					dueDate: nextDueDate,
					isComplete: Boolean(nextIsComplete)
				};
			});
			if (updates.is_complete !== undefined || updates.isComplete !== undefined) {
				const isNowComplete = Boolean(updates.is_complete ?? updates.isComplete);
				setTaskActionNotice(isNowComplete ? `Marked "${taskTitle}" as completed.` : `Reopened "${taskTitle}".`);
			} else {
				setTaskActionNotice(`Updated "${updates.title?.trim() || taskTitle}".`);
			}
			setTaskRefreshSignal((currentSignal) => currentSignal + 1);
			return true;
		} catch (requestError) {
			setTaskActionError(requestError instanceof Error ? requestError.message : "Unable to update your task.");
			return false;
		} finally {
			setUpdatingTaskId(null);
		}
	};
	const handleResume = () => {
		if (!hasStartedSession || isActive || remainingSeconds <= 0 || isLoading) return;
		completionHandledRef.current = false;
		setSessionCompleted(false);
		return runTimerAction(startTimer);
	};
	const handlePause = () => runTimerAction(pauseTimer);
	const handleStop = () => {
		completionHandledRef.current = true;
		setSessionCompleted(false);
		return runTimerAction(stopTimer, () => updateSessionStarted(true));
	};
	const handleReset = () => {
		completionHandledRef.current = false;
		setSessionCompleted(false);
		return runTimerAction(resetTimer, () => {
			setPhase("FOCUS");
			setRemainingSeconds(DEFAULT_FOCUS_SECONDS);
			setEndTime(null);
			setActive(false);
			updateSessionStarted(false);
		});
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(InsightAlert, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 578,
		columnNumber: 13
	}, this), /* @__PURE__ */ _jsxDEV("main", {
		className: `smart-focus-ui workspace-background-${background}`,
		children: [
			/* @__PURE__ */ _jsxDEV(Dashboard, {
				selectedTask: task,
				taskSelectionDisabled: hasStartedSession,
				onSelectTask: handleSelectTask,
				refreshSignal: taskRefreshSignal,
				onDeleteTask: handleDeleteTask,
				deletingTaskId,
				onUpdateTask: handleUpdateTask,
				updatingTaskId,
				taskActionError,
				taskActionNotice,
				taskActionNoticeFading: isTaskActionNoticeFading,
				isYoutubePlayerEnabled,
				onLogout: handleLogout
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 580,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(SettingsPanel, {
				background,
				onBackgroundChange: handleBackgroundChange,
				isYoutubePlayerEnabled,
				onYoutubePlayerToggle: handleYoutubePlayerToggle,
				isTaskManagerOpen,
				taskForm,
				isCreatingTask,
				taskError,
				taskNotice,
				taskNoticeFading: isTaskNoticeFading,
				onTaskManagerToggle: handleTaskManagerToggle,
				onTaskManagerClose: handleTaskManagerClose,
				onTaskFormChange: handleTaskFormChange,
				onCreateTask: handleCreateTask
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 596,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "smart-focus-session-button",
				children: /* @__PURE__ */ _jsxDEV(StartSessionButton, {
					onClick: startSession,
					loading: isLoading,
					disabled: isActive || hasStartedSession || !task
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 614,
					columnNumber: 21
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 613,
				columnNumber: 17
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "smart-focus-error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 622,
				columnNumber: 21
			}, this),
			message && !error && /* @__PURE__ */ _jsxDEV("div", {
				className: `smart-focus-message auto-dismiss-notice${isMessageFading ? " is-fading" : ""}`,
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 628,
				columnNumber: 21
			}, this),
			/* @__PURE__ */ _jsxDEV(PomodoroTimer, {
				task,
				phase,
				remainingSeconds,
				isActive,
				isLoading,
				sessionCompleted,
				error: "",
				onResume: handleResume,
				canResume: hasStartedSession && !isActive && remainingSeconds > 0 && !sessionCompleted,
				onPause: handlePause,
				onStop: handleStop,
				onReset: handleReset
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 633,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 579,
		columnNumber: 13
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 577,
		columnNumber: 9
	}, this);
}
_s2(SmartFocusUI, "eFGSCaKKyFC1rTHeGB/YGdvDSSA=", false, function() {
	return [
		useNavigate,
		useAutoDismissNotice,
		useAutoDismissNotice,
		useAutoDismissNotice
	];
});
_c = SmartFocusUI;
var _c;
$RefreshReg$(_c, "SmartFocusUI");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SmartFocusUI.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsUUFBUSxnQkFBZ0I7QUFDekQsU0FBUyxtQkFBbUI7QUFFNUIsU0FDSSxZQUNBLFlBQ0EsZ0JBQ0EsUUFDQSxZQUNBLFlBQ0EsWUFDQSxXQUNBLGtCQUNHO0FBRVAsT0FBTyx3QkFBd0I7QUFDL0IsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8sbUJBQW1CO0FBQzFCLE9BQU8sa0JBQWtCOzs7O0FBRXpCLE1BQU0sd0JBQXdCLEtBQUs7QUFDbkMsTUFBTSxzQkFBc0IsSUFBSTtBQUNoQyxNQUFNLGtCQUFrQjtDQUFFLE9BQU87Q0FBSSxhQUFhO0NBQUksU0FBUztBQUFHO0FBRWxFLFNBQVMsZ0JBQWdCO0NBQ3JCLElBQUk7RUFDQSxNQUFNLFlBQVksT0FBTyxhQUFhLFFBQVEsK0JBQStCO0VBQzdFLE9BQU8sWUFBWSxLQUFLLE1BQU0sU0FBUyxJQUFJO0NBQy9DLFFBQVE7RUFDSixPQUFPO0NBQ1g7QUFDSjtBQUVBLFNBQVMscUJBQXFCLFFBQVEsYUFBYSxjQUFjLE1BQU0saUJBQWlCLEtBQUs7O0NBQ3pGLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBRTlDLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxRQUFRO0dBQ1QsWUFBWSxLQUFLO0dBQ2pCLE9BQU87RUFDWDtFQUVBLFlBQVksS0FBSztFQUNqQixNQUFNLGNBQWMsT0FBTyxpQkFBaUIsWUFBWSxJQUFJLEdBQUcsV0FBVztFQUMxRSxNQUFNLGlCQUFpQixPQUFPLFdBQzFCLGFBQ0EsY0FBYyxjQUNsQjtFQUVBLGFBQWE7R0FDVCxPQUFPLGFBQWEsV0FBVztHQUMvQixPQUFPLGFBQWEsY0FBYztFQUN0QztDQUNKLEdBQUc7RUFBQztFQUFRO0VBQWE7RUFBYTtDQUFjLENBQUM7Q0FFckQsT0FBTztBQUNYOztBQUVBLGVBQWUsU0FBUyxlQUFlOztDQUNuQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsYUFBYTtDQUM5QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsT0FBTztDQUMxQyxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLHFCQUFxQjtDQUM5RSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsVUFBVSxhQUFhLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixlQUFlO0VBQzdELElBQUk7R0FDQSxPQUFPLE9BQU8sZUFBZSxRQUFRLGlDQUFpQyxNQUFNO0VBQ2hGLFFBQVE7R0FDSixPQUFPO0VBQ1g7Q0FDSixDQUFDO0NBQ0QsTUFBTSxDQUFDLFdBQVcsY0FBYyxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxLQUFLO0NBQzlELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsQ0FBQztDQUM1RCxNQUFNLENBQUMsbUJBQW1CLHNCQUFzQixTQUFTLEtBQUs7Q0FDOUQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLGVBQWU7Q0FDeEQsTUFBTSxDQUFDLGdCQUFnQixtQkFBbUIsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsSUFBSTtDQUN6RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLElBQUk7Q0FDekQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxxQkFBcUIsa0JBQWtCLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUMvRCxNQUFNLGtCQUFrQixrQkFBa0IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0NBQy9ELE1BQU0sd0JBQXdCLGtCQUFrQixvQkFBb0IsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUMzRSxNQUFNLGtCQUFrQixxQkFBcUIsU0FBUyxrQkFBa0I7Q0FDeEUsTUFBTSxxQkFBcUIscUJBQXFCLFlBQVksZUFBZTtDQUMzRSxNQUFNLDJCQUEyQixxQkFBcUIsa0JBQWtCLHFCQUFxQjtDQUM3RixNQUFNLFdBQVcsT0FBTyxJQUFJO0NBQzVCLE1BQU0sdUJBQXVCLE9BQU8sS0FBSztDQUN6QyxNQUFNLDZCQUE2QixPQUFPLEtBQUs7Q0FDL0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLGVBQWU7RUFDL0MsSUFBSTtHQUNBLE9BQU8sT0FBTyxhQUFhLFFBQVEsNEJBQTRCLEtBQUs7RUFDeEUsUUFBUTtHQUNKLE9BQU87RUFDWDtDQUNKLENBQUM7Q0FFRCxNQUFNLENBQUMsd0JBQXdCLDJCQUEyQixlQUFlO0VBQ3JFLElBQUk7R0FDQSxPQUFPLE9BQU8sYUFBYSxRQUFRLHdDQUF3QyxNQUFNO0VBQ3JGLFFBQVE7R0FDSixPQUFPO0VBQ1g7Q0FDSixDQUFDO0NBRUQsTUFBTSx1QkFBdUIsYUFBYSxZQUFZO0VBQ2xELHFCQUFxQixPQUFPO0VBQzVCLElBQUk7R0FDQSxJQUFJLFNBQVM7SUFDVCxPQUFPLGVBQWUsUUFBUSxtQ0FBbUMsTUFBTTtHQUMzRSxPQUFPO0lBQ0gsT0FBTyxlQUFlLFdBQVcsaUNBQWlDO0dBQ3RFO0VBQ0osUUFBUSxDQUVSO0NBQ0osR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLG1CQUFtQixhQUFhLFdBQVc7RUFDN0MsSUFBSSxDQUFDLFFBQVE7RUFFYixNQUFNLFlBQVksT0FBTyxTQUFTO0VBQ2xDLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxnQkFBZ0I7RUFFcEQsU0FBUyxTQUFTO0VBQ2xCLG9CQUNJLE9BQU8sU0FBUyxhQUFhLElBQ3ZCLGdCQUNBLGNBQWMsZ0JBQ1Ysc0JBQ0EscUJBQ2Q7RUFFQSxVQUFVLFFBQVEsT0FBTyxRQUFRLENBQUM7RUFDbEMsV0FBVyxPQUFPLFVBQVUsSUFBSSxLQUFLLE9BQU8sT0FBTyxDQUFDLENBQUMsUUFBUSxJQUFJLElBQUk7RUFFckUsSUFBSSxPQUFPLFVBQVU7R0FDakIscUJBQXFCLElBQUk7RUFDN0IsT0FBTyxJQUFJLE9BQU8sU0FBUyxhQUFhLEtBQUssaUJBQWlCLEdBQUc7R0FDN0QscUJBQXFCLEtBQUs7R0FDMUIsb0JBQW9CLElBQUk7RUFDNUI7Q0FDSixHQUFHLENBQUMsb0JBQW9CLENBQUM7Q0FFekIsTUFBTSxlQUFlLFlBQVksWUFBWTtFQUN6QyxNQUFNLFNBQVMsTUFBTSxlQUFlO0VBQ3BDLGlCQUFpQixNQUFNO0NBQzNCLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztDQUVyQixnQkFBZ0I7RUFDWixJQUFJLE9BQU8sV0FBVyxlQUFlLEVBQUUsa0JBQWtCLFNBQVM7RUFDbEUsSUFBSSxhQUFhLGVBQWUsV0FBVztFQUMzQyxJQUFJLDJCQUEyQixTQUFTO0VBRXhDLDJCQUEyQixVQUFVO0VBRXJDLElBQUk7R0FDQSxhQUFhLGtCQUFrQixDQUFDLENBQUMsT0FBTyxvQkFBb0I7SUFDeEQsUUFBUSxLQUFLLDhDQUE4QyxlQUFlO0dBQzlFLENBQUM7RUFDTCxTQUFTLGlCQUFpQjtHQUN0QixRQUFRLEtBQUssOENBQThDLGVBQWU7RUFDOUU7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sNkJBQTZCLGtCQUFrQjtFQUNqRCxJQUFJLE9BQU8sV0FBVyxlQUFlLEVBQUUsa0JBQWtCLFNBQVM7RUFDbEUsSUFBSSxhQUFhLGVBQWUsV0FBVztFQUUzQyxJQUFJO0dBQ0EsTUFBTSxlQUFlLElBQUksYUFBYSxrQkFBa0I7SUFDcEQsTUFBTSxNQUFNLFFBQ04scUJBQXFCLEtBQUssTUFBTSxrQkFDaEM7SUFDTixLQUFLO0dBQ1QsQ0FBQztHQUVELGFBQWEsZ0JBQWdCO0lBQ3pCLE9BQU8sTUFBTTtJQUNiLGFBQWEsTUFBTTtHQUN2QjtFQUNKLFNBQVMsbUJBQW1CO0dBQ3hCLFFBQVEsS0FBSyxxREFBcUQsaUJBQWlCO0VBQ3ZGO0NBQ0osR0FBRyxDQUFDLE1BQU0sS0FBSyxDQUFDO0NBRWhCLGdCQUFnQjtFQUNaLElBQUksT0FBTyxVQUFVLGFBQWEsT0FBTztFQUV6QyxNQUFNLFFBQVEsSUFBSSxNQUFNLEdBQUcsWUFBWSxJQUFJLFNBQVMsc0JBQXNCO0VBQzFFLE1BQU0sVUFBVTtFQUNoQixNQUFNLFNBQVM7RUFDZixTQUFTLFVBQVU7RUFFbkIsYUFBYTtHQUNULE1BQU0sTUFBTTtHQUNaLE1BQU0sY0FBYztHQUNwQixTQUFTLFVBQVU7RUFDdkI7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sc0JBQXNCLGtCQUFrQjtFQUMxQyxNQUFNLFFBQVEsU0FBUztFQUN2QixJQUFJLENBQUMsT0FBTztFQUVaLE1BQU0sY0FBYztFQUNwQixNQUFNLEtBQUssQ0FBQyxDQUFDLE9BQU8sa0JBQWtCO0dBQ2xDLFFBQVEsS0FBSyw4Q0FBOEMsYUFBYTtFQUM1RSxDQUFDO0NBQ0wsR0FBRyxDQUFDLENBQUM7Q0FFTCxnQkFBZ0I7RUFDWixhQUFhLENBQUMsQ0FBQyxZQUFZOztFQUUzQixDQUFDO0NBQ0wsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUVqQixnQkFBZ0I7RUFDWixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsT0FBTztFQUVsQyxNQUFNLHdCQUF3QjtHQUMxQixNQUFNLGdCQUFnQixLQUFLLElBQ3ZCLEdBQ0EsS0FBSyxNQUFNLFVBQVUsS0FBSyxJQUFJLEtBQUssR0FBSSxDQUMzQztHQUVBLG9CQUFvQixhQUFhO0dBRWpDLElBQUksa0JBQWtCLEtBQUssQ0FBQyxxQkFBcUIsU0FBUztJQUN0RCxxQkFBcUIsVUFBVTtJQUMvQixvQkFBb0IsSUFBSTtJQUN4QixxQkFBcUIsS0FBSztJQUMxQixvQkFBb0I7SUFDcEIsMkJBQTJCO0lBQzNCLGFBQWEsQ0FBQyxDQUFDLFlBQVksVUFBVSxLQUFLLENBQUM7R0FDL0M7RUFDSjtFQUVBLGdCQUFnQjtFQUNoQixNQUFNLGFBQWEsT0FBTyxZQUFZLGlCQUFpQixHQUFHO0VBRTFELGFBQWEsT0FBTyxjQUFjLFVBQVU7Q0FDaEQsR0FBRztFQUFDO0VBQVM7RUFBVTtFQUFxQjtFQUFjO0VBQTRCO0NBQW9CLENBQUM7Q0FFM0csTUFBTSxpQkFBaUIsT0FBTyxRQUFRLGNBQWM7RUFDaEQsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNBLE1BQU0sV0FBVyxNQUFNLE9BQU87R0FDOUIsWUFBWSxRQUFRO0dBRXBCLElBQUksVUFBVSxTQUFTO0lBQ25CLFdBQVcsSUFBSSxLQUFLLFNBQVMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDO0dBQ25EO0dBRUEsTUFBTSxhQUFhO0VBQ3ZCLFNBQVMsY0FBYztHQUNuQixTQUNJLHdCQUF3QixRQUNsQixhQUFhLFVBQ2IsNkJBQ1Y7RUFDSixVQUFVO0dBQ04sV0FBVyxLQUFLO0VBQ3BCO0NBQ0o7Q0FFQSxNQUFNLGVBQWUsWUFBWTtFQUM3QixJQUFJLENBQUMsUUFBUSxLQUFLLE1BQU0sTUFBTTtHQUMxQixTQUFTLDZEQUE2RDtHQUN0RTtFQUNKO0VBRUEsSUFBSSxZQUFZLHFCQUFxQixXQUFXO0VBRWhELHFCQUFxQixVQUFVO0VBQy9CLG9CQUFvQixLQUFLO0VBQ3pCLFdBQVcsSUFBSTtFQUNmLFdBQVcsRUFBRTtFQUNiLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDQSxNQUFNLFdBQVc7R0FDakIsU0FBUyxPQUFPO0dBQ2hCLFdBQVcsSUFBSTtHQUVmLE1BQU0sV0FBVyxNQUFNLFdBQVc7SUFDOUIsUUFBUSxLQUFLO0lBQ2IsaUJBQWlCLEtBQUssbUJBQW1CO0dBQzdDLENBQUM7R0FFRCxxQkFBcUIsSUFBSTtHQUN6QixJQUFJLFVBQVUsU0FBUztJQUNuQixXQUFXLElBQUksS0FBSyxTQUFTLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQztHQUNuRDtHQUVBLFdBQVcsb0JBQW9CLEtBQUssT0FBTztHQUMzQyxNQUFNLGFBQWE7RUFDdkIsU0FBUyxjQUFjO0dBQ25CLFNBQ0ksd0JBQXdCLFFBQ3RCLGFBQWEsVUFDYiw4QkFDTjtFQUNKLFVBQVU7R0FDTixXQUFXLEtBQUs7RUFDcEI7Q0FDSjtDQUVBLE1BQU0sZUFBZSxZQUFZO0VBQzdCLE1BQU0sWUFBWSxPQUFPLFFBQVEsbUNBQW1DO0VBQ3BFLElBQUksQ0FBQyxXQUFXO0VBRWhCLElBQUk7R0FDQSxNQUFNLE9BQU87RUFDakIsUUFBUSxDQUVSLFVBQVU7R0FDTixJQUFJO0lBQ0EsT0FBTyxlQUFlLFdBQVcsaUNBQWlDO0lBQ2xFLE9BQU8sZUFBZSxXQUFXLCtCQUErQjtJQUNoRSxPQUFPLGFBQWEsV0FBVywrQkFBK0I7R0FDbEUsUUFBUSxDQUVSO0dBRUEsU0FBUyxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDeEM7Q0FDSjtDQUVBLE1BQU0sMEJBQTBCLG1CQUFtQjtFQUMvQyxjQUFjLGNBQWM7RUFDNUIsSUFBSTtHQUNBLE9BQU8sYUFBYSxRQUFRLDhCQUE4QixjQUFjO0VBQzVFLFFBQVEsQ0FFUjtDQUNKO0NBRUEsTUFBTSxrQ0FBa0M7RUFDcEMsTUFBTSxjQUFjLENBQUM7RUFDckIsd0JBQXdCLFdBQVc7RUFDbkMsSUFBSTtHQUNBLE9BQU8sYUFBYSxRQUNoQiwwQ0FDQSxPQUFPLFdBQVcsQ0FDdEI7RUFDSixRQUFRLENBRVI7Q0FDSjtDQUVBLE1BQU0sb0JBQW9CLGlCQUFpQjtFQUN2QyxJQUFJLG1CQUFtQjtFQUV2QixRQUFRLFlBQVk7RUFFcEIsSUFBSTtHQUNBLE9BQU8sZUFBZSxRQUFRLGlDQUFpQyxLQUFLLFVBQVUsWUFBWSxDQUFDO0VBQy9GLFFBQVEsQ0FFUjtFQUVBLFdBQVcsRUFBRTtFQUNiLFNBQVMsRUFBRTtDQUNmO0NBRUEsTUFBTSxxQkFBcUIsYUFBYSxnQkFBZ0IsU0FBUztFQUM3RCxzQkFBc0Isa0JBQWtCLGdCQUFnQixDQUFDO0VBRXpELElBQ0ksa0JBQWtCLFFBQ2xCLE9BQU8sTUFBTSxFQUFFLE1BQU0sT0FBTyxhQUFhLEtBQ3pDLENBQUMsWUFDRCxDQUFDLG1CQUNIO0dBQ0UsUUFBUSxJQUFJO0dBQ1osSUFBSTtJQUNBLE9BQU8sZUFBZSxXQUFXLCtCQUErQjtHQUNwRSxRQUFRLENBRVI7RUFDSjtDQUNKLEdBQUc7RUFBQztFQUFtQjtFQUFVLE1BQU07Q0FBRSxDQUFDO0NBRTFDLE1BQU0sZ0NBQWdDO0VBQ2xDLG9CQUFvQixXQUFXLENBQUMsTUFBTTtFQUN0QyxjQUFjLEVBQUU7RUFDaEIsYUFBYSxFQUFFO0NBQ25CO0NBRUEsTUFBTSwrQkFBK0IsbUJBQW1CLEtBQUs7Q0FFN0QsTUFBTSx3QkFBd0IsT0FBTyxVQUFVO0VBQzNDLGFBQWEsaUJBQWlCO0dBQUUsR0FBRztJQUFjLFFBQVE7RUFBTSxFQUFFO0NBQ3JFO0NBRUEsTUFBTSxtQkFBbUIsT0FBTyxVQUFVO0VBQ3RDLE1BQU0sZUFBZTtFQUVyQixNQUFNLFFBQVEsU0FBUyxNQUFNLEtBQUs7RUFDbEMsSUFBSSxDQUFDLE9BQU87R0FDUixhQUFhLDhCQUE4QjtHQUMzQztFQUNKO0VBRUEsZ0JBQWdCLElBQUk7RUFDcEIsYUFBYSxFQUFFO0VBQ2YsY0FBYyxFQUFFO0VBRWhCLElBQUk7R0FDQSxNQUFNLFdBQVc7SUFDYjtJQUNBLGFBQWEsU0FBUyxZQUFZLEtBQUssS0FBSztJQUM1QyxVQUFVLFNBQVMsV0FBVztHQUNsQyxDQUFDO0dBRUQsWUFBWSxlQUFlO0dBQzNCLGNBQWMsVUFBVSxNQUFNLGlCQUFpQjtHQUMvQyxzQkFBc0Isa0JBQWtCLGdCQUFnQixDQUFDO0VBQzdELFNBQVMsY0FBYztHQUNuQixhQUNJLHdCQUF3QixRQUNsQixhQUFhLFVBQ2IsNkJBQ1Y7RUFDSixVQUFVO0dBQ04sZ0JBQWdCLEtBQUs7RUFDekI7Q0FDSjtDQUVBLE1BQU0sbUJBQW1CLE9BQU8saUJBQWlCO0VBQzdDLE1BQU0sU0FBUyxjQUFjLE1BQU0sY0FBYztFQUNqRCxNQUFNLFlBQVksY0FBYyxTQUFTLGNBQWMsUUFBUTtFQUUvRCxJQUFJLFVBQVUsTUFBTTtHQUNoQixtQkFBbUIsd0RBQXdEO0dBQzNFO0VBQ0o7RUFFQSxNQUFNLFlBQVksT0FBTyxRQUNyQixvQ0FBb0MsVUFBVSxtREFDbEQ7RUFFQSxJQUFJLENBQUMsV0FBVztFQUVoQixrQkFBa0IsTUFBTTtFQUN4QixtQkFBbUIsRUFBRTtFQUNyQixvQkFBb0IsRUFBRTtFQUV0QixJQUFJO0dBQ0EsTUFBTSxXQUFXLE1BQU07R0FDdkIsb0JBQW9CLFlBQVksVUFBVSxHQUFHO0dBQzdDLG1CQUFtQixNQUFNO0VBQzdCLFNBQVMsY0FBYztHQUNuQixtQkFDSSx3QkFBd0IsUUFDdEIsYUFBYSxVQUNiLDZCQUNOO0VBQ0osVUFBVTtHQUNOLGtCQUFrQixJQUFJO0VBQzFCO0NBQ0o7Q0FFQSxNQUFNLG1CQUFtQixPQUFPLGNBQWMsWUFBWTtFQUN0RCxNQUFNLFNBQVMsY0FBYyxNQUFNLGNBQWM7RUFDakQsTUFBTSxZQUFZLGNBQWMsU0FBUyxjQUFjLFFBQVE7RUFFL0QsSUFBSSxVQUFVLE1BQU07R0FDaEIsbUJBQW1CLGlFQUFpRTtHQUNwRixPQUFPO0VBQ1g7RUFFQSxrQkFBa0IsTUFBTTtFQUN4QixtQkFBbUIsRUFBRTtFQUNyQixvQkFBb0IsRUFBRTtFQUV0QixJQUFJO0dBQ0EsTUFBTSxjQUFjLE1BQU0sV0FBVyxRQUFRLE9BQU87R0FDcEQsSUFBSSxDQUFDLGFBQWE7SUFDZCxNQUFNLElBQUksTUFBTSwwRUFBMEU7R0FDOUY7R0FFQSxTQUFTLGdCQUFnQjtJQUNyQixJQUFJLENBQUMsZUFBZSxPQUFPLFlBQVksRUFBRSxNQUFNLE9BQU8sTUFBTSxHQUFHO0tBQzNELE9BQU87SUFDWDtJQUVBLE1BQU0sVUFBVSxRQUFRLE9BQU8sVUFBVSxlQUFlLEtBQUssYUFBYSxHQUFHO0lBQzdFLE1BQU0sY0FBYyxPQUFPLFNBQVMsSUFDOUIsWUFBWSxVQUNaLE9BQU8sVUFBVSxJQUNiLFlBQVksV0FDWixRQUFRLFlBQVksUUFBUSxXQUFXLFlBQVk7SUFDN0QsTUFBTSxrQkFBa0IsT0FBTyxhQUFhLElBQ3RDLFlBQVksY0FDWixRQUFRLGVBQWUsWUFBWTtJQUN6QyxNQUFNLGlCQUFpQixZQUFZLGNBQzVCLFlBQVksZUFDWixRQUFRLGVBQ1IsUUFBUSxjQUNSLFlBQVk7SUFFbkIsT0FBTztLQUNILEdBQUc7S0FDSCxHQUFHO0tBQ0gsT0FBTyxZQUFZLFNBQVMsUUFBUSxTQUFTLFlBQVk7S0FDekQsYUFBYTtLQUNiLFNBQVM7S0FDVCxZQUFZLFFBQVEsY0FBYztJQUN0QztHQUNKLENBQUM7R0FFRCxJQUFJLFFBQVEsZ0JBQWdCLGFBQWEsUUFBUSxlQUFlLFdBQVc7SUFDdkUsTUFBTSxnQkFBZ0IsUUFBUSxRQUFRLGVBQWUsUUFBUSxVQUFVO0lBQ3ZFLG9CQUNJLGdCQUNNLFdBQVcsVUFBVSxtQkFDckIsYUFBYSxVQUFVLEdBQ2pDO0dBQ0osT0FBTztJQUNILG9CQUFvQixZQUFZLFFBQVEsT0FBTyxLQUFLLEtBQUssVUFBVSxHQUFHO0dBQzFFO0dBRUEsc0JBQXNCLGtCQUFrQixnQkFBZ0IsQ0FBQztHQUN6RCxPQUFPO0VBQ1gsU0FBUyxjQUFjO0dBQ25CLG1CQUNJLHdCQUF3QixRQUNsQixhQUFhLFVBQ2IsNkJBQ1Y7R0FDQSxPQUFPO0VBQ1gsVUFBVTtHQUNOLGtCQUFrQixJQUFJO0VBQzFCO0NBQ0o7Q0FFQSxNQUFNLHFCQUFxQjtFQUN2QixJQUFJLENBQUMscUJBQXFCLFlBQVksb0JBQW9CLEtBQUssV0FBVztFQUUxRSxxQkFBcUIsVUFBVTtFQUMvQixvQkFBb0IsS0FBSztFQUN6QixPQUFPLGVBQWUsVUFBVTtDQUNwQztDQUVBLE1BQU0sb0JBQW9CLGVBQWUsVUFBVTtDQUVuRCxNQUFNLG1CQUFtQjtFQUNyQixxQkFBcUIsVUFBVTtFQUMvQixvQkFBb0IsS0FBSztFQUN6QixPQUFPLGVBQWUsaUJBQWlCLHFCQUFxQixJQUFJLENBQUM7Q0FDckU7Q0FFQSxNQUFNLG9CQUFvQjtFQUN0QixxQkFBcUIsVUFBVTtFQUMvQixvQkFBb0IsS0FBSztFQUN6QixPQUFPLGVBQWUsa0JBQWtCO0dBQ3BDLFNBQVMsT0FBTztHQUNoQixvQkFBb0IscUJBQXFCO0dBQ3pDLFdBQVcsSUFBSTtHQUNmLFVBQVUsS0FBSztHQUNmLHFCQUFxQixLQUFLO0VBQzlCLENBQUM7Q0FDTDtDQUVBLE9BQ0ksZ0RBQ0ksd0JBQUMsY0FBRCxDQUFlOzs7O1dBQ2Ysd0JBQUMsUUFBRDtFQUFNLFdBQVcsdUNBQXVDO1lBQXhEO0dBQ0ksd0JBQUMsV0FBRDtJQUNJLGNBQWM7SUFDZCx1QkFBdUI7SUFDdkIsY0FBYztJQUNkLGVBQWU7SUFDZixjQUFjO0lBQ0U7SUFDaEIsY0FBYztJQUNFO0lBQ0M7SUFDQztJQUNsQix3QkFBd0I7SUFDQTtJQUN4QixVQUFVO0dBQ2I7Ozs7O0dBRUQsd0JBQUMsZUFBRDtJQUNnQjtJQUNaLG9CQUFvQjtJQUNJO0lBQ3hCLHVCQUF1QjtJQUNKO0lBQ1Q7SUFDTTtJQUNMO0lBQ0M7SUFDWixrQkFBa0I7SUFDbEIscUJBQXFCO0lBQ3JCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsY0FBYztHQUNqQjs7Ozs7R0FFRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLG9CQUFEO0tBQ0ksU0FBUztLQUNULFNBQVM7S0FDVCxVQUFVLFlBQVkscUJBQXFCLENBQUM7SUFDL0M7Ozs7O0dBQ0E7Ozs7O0dBRUosU0FDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFvQixNQUFLO2NBQ25DO0dBQ0E7Ozs7O0dBR1IsV0FBVyxDQUFDLFNBQ1Qsd0JBQUMsT0FBRDtJQUFLLFdBQVcsMENBQTBDLGtCQUFrQixlQUFlO0lBQU0sTUFBSztjQUNqRztHQUNBOzs7OztHQUdULHdCQUFDLGVBQUQ7SUFDVTtJQUNDO0lBQ1c7SUFDUjtJQUNDO0lBQ087SUFDbEIsT0FBTztJQUNQLFVBQVU7SUFDVixXQUFXLHFCQUFxQixDQUFDLFlBQVksbUJBQW1CLEtBQUssQ0FBQztJQUN0RSxTQUFTO0lBQ1QsUUFBUTtJQUNSLFNBQVM7R0FDWjs7Ozs7RUFDQzs7Ozs7U0FDUjs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTbWFydEZvY3VzVUkuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmltcG9ydCB7XG4gICAgY3JlYXRlVGFzayxcbiAgICBkZWxldGVUYXNrLFxuICAgIGdldFRpbWVyU3RhdHVzLFxuICAgIGxvZ291dCxcbiAgICBwYXVzZVRpbWVyLFxuICAgIHJlc2V0VGltZXIsXG4gICAgc3RhcnRUaW1lcixcbiAgICBzdG9wVGltZXIsXG4gICAgdXBkYXRlVGFzayxcbn0gZnJvbSAnLi4vc2VydmljZXMvYXBpQ2xpZW50LmpzJztcblxuaW1wb3J0IFN0YXJ0U2Vzc2lvbkJ1dHRvbiBmcm9tICcuL1N0YXJ0U2Vzc2lvbkJ1dHRvbi5qc3gnO1xuaW1wb3J0IERhc2hib2FyZCBmcm9tICcuL0Rhc2hib2FyZC5qc3gnO1xuaW1wb3J0IFBvbW9kb3JvVGltZXIgZnJvbSAnLi9Qb21vZG9yb1RpbWVyLmpzeCc7XG5pbXBvcnQgU2V0dGluZ3NQYW5lbCBmcm9tICcuL1NldHRpbmdzUGFuZWwuanN4JztcbmltcG9ydCBJbnNpZ2h0QWxlcnQgZnJvbSAnLi9JbnNpZ2h0QWxlcnQuanN4JztcblxuY29uc3QgREVGQVVMVF9GT0NVU19TRUNPTkRTID0gMjAgKiA2MDtcbmNvbnN0IFNIT1JUX0JSRUFLX1NFQ09ORFMgPSA1ICogNjA7XG5jb25zdCBFTVBUWV9UQVNLX0ZPUk0gPSB7IHRpdGxlOiAnJywgZGVzY3JpcHRpb246ICcnLCBkdWVEYXRlOiAnJyB9O1xuXG5mdW5jdGlvbiByZWFkU2F2ZWRUYXNrKCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHNhdmVkVGFzayA9IHdpbmRvdy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbSgncHJvamVjdC1rYXRjaHVwLXNlbGVjdGVkLXRhc2snKTtcbiAgICAgICAgcmV0dXJuIHNhdmVkVGFzayA/IEpTT04ucGFyc2Uoc2F2ZWRUYXNrKSA6IG51bGw7XG4gICAgfSBjYXRjaCB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gdXNlQXV0b0Rpc21pc3NOb3RpY2Uobm90aWNlLCBjbGVhck5vdGljZSwgZmFkZUFmdGVyTXMgPSAzNTAwLCBmYWRlRHVyYXRpb25NcyA9IDQ1MCkge1xuICAgIGNvbnN0IFtpc0ZhZGluZywgc2V0SXNGYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFub3RpY2UpIHtcbiAgICAgICAgICAgIHNldElzRmFkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc0ZhZGluZyhmYWxzZSk7XG4gICAgICAgIGNvbnN0IGZhZGVUaW1lb3V0ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4gc2V0SXNGYWRpbmcodHJ1ZSksIGZhZGVBZnRlck1zKTtcbiAgICAgICAgY29uc3QgY2xlYXJUaW1lb3V0SWQgPSB3aW5kb3cuc2V0VGltZW91dChcbiAgICAgICAgICAgIGNsZWFyTm90aWNlLFxuICAgICAgICAgICAgZmFkZUFmdGVyTXMgKyBmYWRlRHVyYXRpb25NcyxcbiAgICAgICAgKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgd2luZG93LmNsZWFyVGltZW91dChmYWRlVGltZW91dCk7XG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KGNsZWFyVGltZW91dElkKTtcbiAgICAgICAgfTtcbiAgICB9LCBbbm90aWNlLCBjbGVhck5vdGljZSwgZmFkZUFmdGVyTXMsIGZhZGVEdXJhdGlvbk1zXSk7XG5cbiAgICByZXR1cm4gaXNGYWRpbmc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNtYXJ0Rm9jdXNVSSgpIHtcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gICAgY29uc3QgW3Rhc2ssIHNldFRhc2tdID0gdXNlU3RhdGUocmVhZFNhdmVkVGFzayk7XG4gICAgY29uc3QgW3BoYXNlLCBzZXRQaGFzZV0gPSB1c2VTdGF0ZSgnRk9DVVMnKTtcbiAgICBjb25zdCBbcmVtYWluaW5nU2Vjb25kcywgc2V0UmVtYWluaW5nU2Vjb25kc10gPSB1c2VTdGF0ZShERUZBVUxUX0ZPQ1VTX1NFQ09ORFMpO1xuICAgIGNvbnN0IFtlbmRUaW1lLCBzZXRFbmRUaW1lXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtpc0FjdGl2ZSwgc2V0QWN0aXZlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaGFzU3RhcnRlZFNlc3Npb24sIHNldEhhc1N0YXJ0ZWRTZXNzaW9uXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgncHJvamVjdC1rYXRjaHVwLXNlc3Npb24tc3RhcnRlZCcpID09PSAndHJ1ZSc7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzZXNzaW9uQ29tcGxldGVkLCBzZXRTZXNzaW9uQ29tcGxldGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdGFza1JlZnJlc2hTaWduYWwsIHNldFRhc2tSZWZyZXNoU2lnbmFsXSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFtpc1Rhc2tNYW5hZ2VyT3Blbiwgc2V0VGFza01hbmFnZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdGFza0Zvcm0sIHNldFRhc2tGb3JtXSA9IHVzZVN0YXRlKEVNUFRZX1RBU0tfRk9STSk7XG4gICAgY29uc3QgW2lzQ3JlYXRpbmdUYXNrLCBzZXRDcmVhdGluZ1Rhc2tdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtkZWxldGluZ1Rhc2tJZCwgc2V0RGVsZXRpbmdUYXNrSWRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW3VwZGF0aW5nVGFza0lkLCBzZXRVcGRhdGluZ1Rhc2tJZF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgICBjb25zdCBbdGFza0Vycm9yLCBzZXRUYXNrRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt0YXNrTm90aWNlLCBzZXRUYXNrTm90aWNlXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbdGFza0FjdGlvbkVycm9yLCBzZXRUYXNrQWN0aW9uRXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFt0YXNrQWN0aW9uTm90aWNlLCBzZXRUYXNrQWN0aW9uTm90aWNlXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBjbGVhck1lc3NhZ2VOb3RpY2UgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRNZXNzYWdlKCcnKSwgW10pO1xuICAgIGNvbnN0IGNsZWFyVGFza05vdGljZSA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFRhc2tOb3RpY2UoJycpLCBbXSk7XG4gICAgY29uc3QgY2xlYXJUYXNrQWN0aW9uTm90aWNlID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0VGFza0FjdGlvbk5vdGljZSgnJyksIFtdKTtcbiAgICBjb25zdCBpc01lc3NhZ2VGYWRpbmcgPSB1c2VBdXRvRGlzbWlzc05vdGljZShtZXNzYWdlLCBjbGVhck1lc3NhZ2VOb3RpY2UpO1xuICAgIGNvbnN0IGlzVGFza05vdGljZUZhZGluZyA9IHVzZUF1dG9EaXNtaXNzTm90aWNlKHRhc2tOb3RpY2UsIGNsZWFyVGFza05vdGljZSk7XG4gICAgY29uc3QgaXNUYXNrQWN0aW9uTm90aWNlRmFkaW5nID0gdXNlQXV0b0Rpc21pc3NOb3RpY2UodGFza0FjdGlvbk5vdGljZSwgY2xlYXJUYXNrQWN0aW9uTm90aWNlKTtcbiAgICBjb25zdCBjaGltZVJlZiA9IHVzZVJlZihudWxsKTtcbiAgICBjb25zdCBjb21wbGV0aW9uSGFuZGxlZFJlZiA9IHVzZVJlZihmYWxzZSk7XG4gICAgY29uc3Qgbm90aWZpY2F0aW9uUGVybVJlcXVlc3RSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IFtiYWNrZ3JvdW5kLCBzZXRCYWNrZ3JvdW5kXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1iYWNrZ3JvdW5kJykgfHwgJ3BsYWluJztcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICByZXR1cm4gJ3BsYWluJztcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgW2lzWW91dHViZVBsYXllckVuYWJsZWQsIHNldFlvdXR1YmVQbGF5ZXJFbmFibGVkXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC15b3V0dWJlLXBsYXllci1lbmFibGVkJykgPT09ICd0cnVlJztcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IHVwZGF0ZVNlc3Npb25TdGFydGVkID0gdXNlQ2FsbGJhY2soKHN0YXJ0ZWQpID0+IHtcbiAgICAgICAgc2V0SGFzU3RhcnRlZFNlc3Npb24oc3RhcnRlZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoc3RhcnRlZCkge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdwcm9qZWN0LWthdGNodXAtc2Vzc2lvbi1zdGFydGVkJywgJ3RydWUnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZXNzaW9uLXN0YXJ0ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBUaW1lciBjb250cm9scyB3aWxsIHN0aWxsIHdvcmsgd2hlbiBicm93c2VyIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGUuXG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBhcHBseVRpbWVyU3RhdHVzID0gdXNlQ2FsbGJhY2soKHN0YXR1cykgPT4ge1xuICAgICAgICBpZiAoIXN0YXR1cykgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IG5leHRQaGFzZSA9IHN0YXR1cy5waGFzZSA/PyAnRk9DVVMnO1xuICAgICAgICBjb25zdCBuZXh0UmVtYWluaW5nID0gTnVtYmVyKHN0YXR1cy5yZW1haW5pbmdTZWNvbmRzKTtcblxuICAgICAgICBzZXRQaGFzZShuZXh0UGhhc2UpO1xuICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKFxuICAgICAgICAgICAgTnVtYmVyLmlzRmluaXRlKG5leHRSZW1haW5pbmcpXG4gICAgICAgICAgICAgICAgPyBuZXh0UmVtYWluaW5nXG4gICAgICAgICAgICAgICAgOiBuZXh0UGhhc2UgPT09ICdTSE9SVF9CUkVBSydcbiAgICAgICAgICAgICAgICAgICAgPyBTSE9SVF9CUkVBS19TRUNPTkRTXG4gICAgICAgICAgICAgICAgICAgIDogREVGQVVMVF9GT0NVU19TRUNPTkRTLFxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgc2V0QWN0aXZlKEJvb2xlYW4oc3RhdHVzLmlzQWN0aXZlKSk7XG4gICAgICAgIHNldEVuZFRpbWUoc3RhdHVzLmVuZFRpbWUgPyBuZXcgRGF0ZShzdGF0dXMuZW5kVGltZSkuZ2V0VGltZSgpIDogbnVsbCk7XG5cbiAgICAgICAgaWYgKHN0YXR1cy5pc0FjdGl2ZSkge1xuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQodHJ1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoTnVtYmVyLmlzRmluaXRlKG5leHRSZW1haW5pbmcpICYmIG5leHRSZW1haW5pbmcgPD0gMCkge1xuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQoZmFsc2UpO1xuICAgICAgICAgICAgc2V0U2Vzc2lvbkNvbXBsZXRlZCh0cnVlKTtcbiAgICAgICAgfVxuICAgIH0sIFt1cGRhdGVTZXNzaW9uU3RhcnRlZF0pO1xuXG4gICAgY29uc3QgcmVmcmVzaFRpbWVyID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0dXMgPSBhd2FpdCBnZXRUaW1lclN0YXR1cygpO1xuICAgICAgICBhcHBseVRpbWVyU3RhdHVzKHN0YXR1cyk7XG4gICAgfSwgW2FwcGx5VGltZXJTdGF0dXNdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhKCdOb3RpZmljYXRpb24nIGluIHdpbmRvdykpIHJldHVybjtcbiAgICAgICAgaWYgKE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uICE9PSAnZGVmYXVsdCcpIHJldHVybjtcbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvblBlcm1SZXF1ZXN0UmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgICAgICBub3RpZmljYXRpb25QZXJtUmVxdWVzdFJlZi5jdXJyZW50ID0gdHJ1ZTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgTm90aWZpY2F0aW9uLnJlcXVlc3RQZXJtaXNzaW9uKCkuY2F0Y2goKHBlcm1pc3Npb25FcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIHJlcXVlc3Qgbm90aWZpY2F0aW9uIHBlcm1pc3Npb24uJywgcGVybWlzc2lvbkVycm9yKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChwZXJtaXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIHJlcXVlc3Qgbm90aWZpY2F0aW9uIHBlcm1pc3Npb24uJywgcGVybWlzc2lvbkVycm9yKTtcbiAgICAgICAgfVxuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IHNob3dDb21wbGV0aW9uTm90aWZpY2F0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgfHwgISgnTm90aWZpY2F0aW9uJyBpbiB3aW5kb3cpKSByZXR1cm47XG4gICAgICAgIGlmIChOb3RpZmljYXRpb24ucGVybWlzc2lvbiAhPT0gJ2dyYW50ZWQnKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG5vdGlmaWNhdGlvbiA9IG5ldyBOb3RpZmljYXRpb24oJ1RpbWVyIENvbXBsZXRlJywge1xuICAgICAgICAgICAgICAgIGJvZHk6IHRhc2s/LnRpdGxlXG4gICAgICAgICAgICAgICAgICAgID8gYFlvdXIgc2Vzc2lvbiBmb3IgXCIke3Rhc2sudGl0bGV9XCIgaXMgY29tcGxldGUuYFxuICAgICAgICAgICAgICAgICAgICA6ICdZb3VyIHRpbWVyIGhhcyBmaW5pc2hlZC4nLFxuICAgICAgICAgICAgICAgIHRhZzogJ3Byb2plY3Qta2F0Y2h1cC10aW1lci1jb21wbGV0ZScsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgbm90aWZpY2F0aW9uLm9uQ2xpY2sgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgd2luZG93LmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgbm90aWZpY2F0aW9uLmNsb3NlKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChub3RpZmljYXRpb25FcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdVbmFibGUgdG8gc2hvdyB0aGUgdGltZXIgY29tcGxldGlvbiBub3RpZmljYXRpb24uJywgbm90aWZpY2F0aW9uRXJyb3IpO1xuICAgICAgICB9XG4gICAgfSwgW3Rhc2s/LnRpdGxlXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIEF1ZGlvID09PSAndW5kZWZpbmVkJykgcmV0dXJuIHVuZGVmaW5lZDtcblxuICAgICAgICBjb25zdCBjaGltZSA9IG5ldyBBdWRpbyhgJHtpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkx9YXVkaW8vdGltZXItY2hpbWUubXAzYCk7XG4gICAgICAgIGNoaW1lLnByZWxvYWQgPSAnYXV0byc7XG4gICAgICAgIGNoaW1lLnZvbHVtZSA9IDAuNzU7XG4gICAgICAgIGNoaW1lUmVmLmN1cnJlbnQgPSBjaGltZTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY2hpbWUucGF1c2UoKTtcbiAgICAgICAgICAgIGNoaW1lLmN1cnJlbnRUaW1lID0gMDtcbiAgICAgICAgICAgIGNoaW1lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9O1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IHBsYXlDb21wbGV0aW9uQ2hpbWUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNoaW1lID0gY2hpbWVSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFjaGltZSkgcmV0dXJuO1xuXG4gICAgICAgIGNoaW1lLmN1cnJlbnRUaW1lID0gMDtcbiAgICAgICAgY2hpbWUucGxheSgpLmNhdGNoKChwbGF5YmFja0Vycm9yKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1VuYWJsZSB0byBwbGF5IHRoZSB0aW1lciBjb21wbGV0aW9uIGNoaW1lLicsIHBsYXliYWNrRXJyb3IpO1xuICAgICAgICB9KTtcbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZWZyZXNoVGltZXIoKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAvLyBEZWZhdWx0IGxvY2FsIHRpbWVyIHN0YXRlIGNhbiBzdGlsbCBiZSB1c2VkIGlmIHNlcnZlciBpcyBkb3duLlxuICAgICAgICB9KTtcbiAgICB9LCBbcmVmcmVzaFRpbWVyXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWlzQWN0aXZlIHx8ICFlbmRUaW1lKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgICAgIGNvbnN0IHVwZGF0ZUNvdW50ZG93biA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRSZW1haW5pbmcgPSBNYXRoLm1heChcbiAgICAgICAgICAgICAgICAwLFxuICAgICAgICAgICAgICAgIE1hdGguY2VpbCgoZW5kVGltZSAtIERhdGUubm93KCkpIC8gMTAwMCksXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKG5leHRSZW1haW5pbmcpO1xuXG4gICAgICAgICAgICBpZiAobmV4dFJlbWFpbmluZyA9PT0gMCAmJiAhY29tcGxldGlvbkhhbmRsZWRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGNvbXBsZXRpb25IYW5kbGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHBsYXlDb21wbGV0aW9uQ2hpbWUoKTtcbiAgICAgICAgICAgICAgICBzaG93Q29tcGxldGlvbk5vdGlmaWNhdGlvbigpO1xuICAgICAgICAgICAgICAgIHJlZnJlc2hUaW1lcigpLmNhdGNoKCgpID0+IHNldEFjdGl2ZShmYWxzZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHVwZGF0ZUNvdW50ZG93bigpO1xuICAgICAgICBjb25zdCBpbnRlcnZhbElkID0gd2luZG93LnNldEludGVydmFsKHVwZGF0ZUNvdW50ZG93biwgMjUwKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCk7XG4gICAgfSwgW2VuZFRpbWUsIGlzQWN0aXZlLCBwbGF5Q29tcGxldGlvbkNoaW1lLCByZWZyZXNoVGltZXIsIHNob3dDb21wbGV0aW9uTm90aWZpY2F0aW9uLCB1cGRhdGVTZXNzaW9uU3RhcnRlZF0pO1xuXG4gICAgY29uc3QgcnVuVGltZXJBY3Rpb24gPSBhc3luYyAoYWN0aW9uLCBvblN1Y2Nlc3MpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFjdGlvbigpO1xuICAgICAgICAgICAgb25TdWNjZXNzPy4ocmVzcG9uc2UpO1xuXG4gICAgICAgICAgICBpZiAocmVzcG9uc2U/LmVuZFRpbWUpIHtcbiAgICAgICAgICAgICAgICBzZXRFbmRUaW1lKG5ldyBEYXRlKHJlc3BvbnNlLmVuZFRpbWUpLmdldFRpbWUoKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGF3YWl0IHJlZnJlc2hUaW1lcigpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKFxuICAgICAgICAgICAgICAgIHJlcXVlc3RFcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIHVwZGF0ZSB0aGUgdGltZXIuJyxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBzdGFydFNlc3Npb24gPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghdGFzayB8fCB0YXNrLmlkID09IG51bGwpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdTZWxlY3QgYSB0YXNrIGZyb20gdGhlIGRhc2hib2FyZCBiZWZvcmUgc3RhcnRpbmcgYSBzZXNzaW9uLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlzQWN0aXZlIHx8IGhhc1N0YXJ0ZWRTZXNzaW9uIHx8IGlzTG9hZGluZykgcmV0dXJuO1xuXG4gICAgICAgIGNvbXBsZXRpb25IYW5kbGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgc2V0U2Vzc2lvbkNvbXBsZXRlZChmYWxzZSk7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHNldE1lc3NhZ2UoJycpO1xuICAgICAgICBzZXRFcnJvcignJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHJlc2V0VGltZXIoKTtcbiAgICAgICAgICAgIHNldFBoYXNlKCdGT0NVUycpO1xuICAgICAgICAgICAgc2V0RW5kVGltZShudWxsKTtcblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzdGFydFRpbWVyKHtcbiAgICAgICAgICAgICAgICB0YXNrSWQ6IHRhc2suaWQsXG4gICAgICAgICAgICAgICAgZHVyYXRpb25TZWNvbmRzOiB0YXNrLmR1cmF0aW9uU2Vjb25kcyA/PyBERUZBVUxUX0ZPQ1VTX1NFQ09ORFMsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQodHJ1ZSk7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2U/LmVuZFRpbWUpIHtcbiAgICAgICAgICAgICAgICBzZXRFbmRUaW1lKG5ldyBEYXRlKHJlc3BvbnNlLmVuZFRpbWUpLmdldFRpbWUoKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldE1lc3NhZ2UoYFNlc3Npb24gU3RhcnRlZDogJHt0YXNrLnRpdGxlfWApO1xuICAgICAgICAgICAgYXdhaXQgcmVmcmVzaFRpbWVyKCk7XG4gICAgICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgICAgICAgc2V0RXJyb3IoXG4gICAgICAgICAgICAgICAgcmVxdWVzdEVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICA/IHJlcXVlc3RFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgOiAnU2Vzc2lvbiB3YXMgdW5hYmxlIHRvIHN0YXJ0LicsXG4gICAgICAgICAgICApO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlTG9nb3V0ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBjb25maXJtZWQgPSB3aW5kb3cuY29uZmlybSgnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGxvZyBvdXQ/Jyk7XG4gICAgICAgIGlmICghY29uZmlybWVkKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGxvZ291dCgpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8vIExvZ291dCBoZWxwZXIgY2xlYXJzIGxvY2FsIGF1dGggdG9rZW4gd2hlbiBzZXJ2ZXIgcmVxdWVzdCBmYWlscy5cbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZXNzaW9uLXN0YXJ0ZWQnKTtcbiAgICAgICAgICAgICAgICB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbSgncHJvamVjdC1rYXRjaHVwLXNlbGVjdGVkLXRhc2snKTtcbiAgICAgICAgICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZWxlY3RlZC10YXNrJyk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBXaWxsIHN0aWxsIGxvZ291dCBpZiBicm93c2VyIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGVcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgbmF2aWdhdGUoJy9sb2dpbicsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVCYWNrZ3JvdW5kQ2hhbmdlID0gKG5leHRCYWNrZ3JvdW5kKSA9PiB7XG4gICAgICAgIHNldEJhY2tncm91bmQobmV4dEJhY2tncm91bmQpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdwcm9qZWN0LWthdGNodXAtYmFja2dyb3VuZCcsIG5leHRCYWNrZ3JvdW5kKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBTZWxlY3RvciB3aWxsIHN0aWxsIG9wZXJhdGUgaWYgYW5kIHdoZW4gc3RvcmFnZSBpcyB1bmF2YWlsYWJsZS5cbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVZb3V0dWJlUGxheWVyVG9nZ2xlID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXh0RW5hYmxlZCA9ICFpc1lvdXR1YmVQbGF5ZXJFbmFibGVkO1xuICAgICAgICBzZXRZb3V0dWJlUGxheWVyRW5hYmxlZChuZXh0RW5hYmxlZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXG4gICAgICAgICAgICAgICAgJ3Byb2plY3Qta2F0Y2h1cC15b3V0dWJlLXBsYXllci1lbmFibGVkJyxcbiAgICAgICAgICAgICAgICBTdHJpbmcobmV4dEVuYWJsZWQpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBZb3V0dWJlIHBsYXllciB0b2dnbGUgd2lsbCBzdGlsbCB3b3JrIGlmIHRoZSBjdXJyZW50IHBhZ2UncyBzdG9yYWdlIGlzIHVuYXZhaWxhYmxlLlxuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdFRhc2sgPSAoc2VsZWN0ZWRUYXNrKSA9PiB7XG4gICAgICAgIGlmIChoYXNTdGFydGVkU2Vzc2lvbikgcmV0dXJuO1xuICAgICAgICBcbiAgICAgICAgc2V0VGFzayhzZWxlY3RlZFRhc2spO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB3aW5kb3cuc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgncHJvamVjdC1rYXRjaHVwLXNlbGVjdGVkLXRhc2snLCBKU09OLnN0cmluZ2lmeShzZWxlY3RlZFRhc2spKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBDYW4gc3RpbGwgc2VsZWN0IHRhc2sgaWYgYnJvd3NlciBzdG9yYWdlIGlzIHVuYXZhaWxhYmxlLlxuICAgICAgICB9XG5cbiAgICAgICAgc2V0TWVzc2FnZSgnJyk7XG4gICAgICAgIHNldEVycm9yKCcnKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlVGFza3NDaGFuZ2VkID0gdXNlQ2FsbGJhY2soKGRlbGV0ZWRUYXNrSWQgPSBudWxsKSA9PiB7XG4gICAgICAgIHNldFRhc2tSZWZyZXNoU2lnbmFsKChjdXJyZW50U2lnbmFsKSA9PiBjdXJyZW50U2lnbmFsICsgMSk7XG5cbiAgICAgICAgaWYgKFxuICAgICAgICAgICAgZGVsZXRlZFRhc2tJZCAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgU3RyaW5nKHRhc2s/LmlkKSA9PT0gU3RyaW5nKGRlbGV0ZWRUYXNrSWQpICYmXG4gICAgICAgICAgICAhaXNBY3RpdmUgJiZcbiAgICAgICAgICAgICFoYXNTdGFydGVkU2Vzc2lvblxuICAgICAgICApIHtcbiAgICAgICAgICAgIHNldFRhc2sobnVsbCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5yZW1vdmVJdGVtKCdwcm9qZWN0LWthdGNodXAtc2VsZWN0ZWQtdGFzaycpO1xuICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgLy8gSWdub3JlcyBicm93c2VyIHN0b3JhZ2UgdGhhdCBpcyB1bmF2YWlsYWJsZS5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFtoYXNTdGFydGVkU2Vzc2lvbiwgaXNBY3RpdmUsIHRhc2s/LmlkXSk7XG5cbiAgICBjb25zdCBoYW5kbGVUYXNrTWFuYWdlclRvZ2dsZSA9ICgpID0+IHtcbiAgICAgICAgc2V0VGFza01hbmFnZXJPcGVuKChpc09wZW4pID0+ICFpc09wZW4pO1xuICAgICAgICBzZXRUYXNrTm90aWNlKCcnKTtcbiAgICAgICAgc2V0VGFza0Vycm9yKCcnKTtcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlVGFza01hbmFnZXJDbG9zZSA9ICgpID0+IHNldFRhc2tNYW5hZ2VyT3BlbihmYWxzZSk7XG5cbiAgICBjb25zdCBoYW5kbGVUYXNrRm9ybUNoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcbiAgICAgICAgc2V0VGFza0Zvcm0oKGN1cnJlbnRGb3JtKSA9PiAoeyAuLi5jdXJyZW50Rm9ybSwgW2ZpZWxkXTogdmFsdWUgfSkpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVDcmVhdGVUYXNrID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgY29uc3QgdGl0bGUgPSB0YXNrRm9ybS50aXRsZS50cmltKCk7XG4gICAgICAgIGlmICghdGl0bGUpIHtcbiAgICAgICAgICAgIHNldFRhc2tFcnJvcignRW50ZXIgYSB0aXRsZSBmb3IgeW91ciB0YXNrLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0Q3JlYXRpbmdUYXNrKHRydWUpO1xuICAgICAgICBzZXRUYXNrRXJyb3IoJycpO1xuICAgICAgICBzZXRUYXNrTm90aWNlKCcnKTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgY3JlYXRlVGFzayh7XG4gICAgICAgICAgICAgICAgdGl0bGUsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IHRhc2tGb3JtLmRlc2NyaXB0aW9uLnRyaW0oKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIGR1ZV9kYXRlOiB0YXNrRm9ybS5kdWVEYXRlIHx8IG51bGwsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2V0VGFza0Zvcm0oRU1QVFlfVEFTS19GT1JNKTtcbiAgICAgICAgICAgIHNldFRhc2tOb3RpY2UoYEFkZGVkIFwiJHt0aXRsZX1cIiB0byB5b3VyIHRhc2tzLmApO1xuICAgICAgICAgICAgc2V0VGFza1JlZnJlc2hTaWduYWwoKGN1cnJlbnRTaWduYWwpID0+IGN1cnJlbnRTaWduYWwgKyAxKTtcbiAgICAgICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICAgICAgICBzZXRUYXNrRXJyb3IoXG4gICAgICAgICAgICAgICAgcmVxdWVzdEVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICAgICAgPyByZXF1ZXN0RXJyb3IubWVzc2FnZVxuICAgICAgICAgICAgICAgICAgICA6ICdVbmFibGUgdG8gY3JlYXRlIHlvdXIgdGFzay4nLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldENyZWF0aW5nVGFzayhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlVGFzayA9IGFzeW5jICh0YXNrdG9EZWxldGUpID0+IHtcbiAgICAgICAgY29uc3QgdGFza0lkID0gdGFza3RvRGVsZXRlPy5pZCA/PyB0YXNrdG9EZWxldGU/LnRhc2tJZDtcbiAgICAgICAgY29uc3QgdGFza1RpdGxlID0gdGFza3RvRGVsZXRlPy50aXRsZSA/PyB0YXNrdG9EZWxldGU/Lm5hbWUgPz8gJ1VudGl0bGVkIHRhc2snO1xuICAgICAgICBcbiAgICAgICAgaWYgKHRhc2tJZCA9PSBudWxsKSB7XG4gICAgICAgICAgICBzZXRUYXNrQWN0aW9uRXJyb3IoJ1RoaXMgdGFzayBjYW5ub3QgYmUgZGVsZXRlZCBiZWNhdXNlIGl0IGhhcyBubyB0YXNrIElELicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCBjb25maXJtZWQgPSB3aW5kb3cuY29uZmlybShcbiAgICAgICAgICAgIGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIFwiJHt0YXNrVGl0bGV9XCI/IFRoaXMgd2lsbCByZW1vdmUgaXQgZnJvbSB5b3VyIGFjdGl2ZSB0YXNrIGxpc3QuYCxcbiAgICAgICAgKTtcblxuICAgICAgICBpZiAoIWNvbmZpcm1lZCkgcmV0dXJuO1xuXG4gICAgICAgIHNldERlbGV0aW5nVGFza0lkKHRhc2tJZCk7XG4gICAgICAgIHNldFRhc2tBY3Rpb25FcnJvcignJyk7XG4gICAgICAgIHNldFRhc2tBY3Rpb25Ob3RpY2UoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBkZWxldGVUYXNrKHRhc2tJZCk7XG4gICAgICAgICAgICBzZXRUYXNrQWN0aW9uTm90aWNlKGBEZWxldGVkIFwiJHt0YXNrVGl0bGV9XCIuYCk7XG4gICAgICAgICAgICBoYW5kbGVUYXNrc0NoYW5nZWQodGFza0lkKTtcbiAgICAgICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICAgICAgICBzZXRUYXNrQWN0aW9uRXJyb3IoXG4gICAgICAgICAgICAgICAgcmVxdWVzdEVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICA/IHJlcXVlc3RFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIGRlbGV0ZSB5b3VyIHRhc2suJyxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXREZWxldGluZ1Rhc2tJZChudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVVcGRhdGVUYXNrID0gYXN5bmMgKHRhc2tUb1VwZGF0ZSwgdXBkYXRlcykgPT4ge1xuICAgICAgICBjb25zdCB0YXNrSWQgPSB0YXNrVG9VcGRhdGU/LmlkID8/IHRhc2tUb1VwZGF0ZT8udGFza0lkO1xuICAgICAgICBjb25zdCB0YXNrVGl0bGUgPSB0YXNrVG9VcGRhdGU/LnRpdGxlID8/IHRhc2tUb1VwZGF0ZT8ubmFtZSA/PyAnVW50aXRsZWQgVGFzayc7XG5cbiAgICAgICAgaWYgKHRhc2tJZCA9PSBudWxsKSB7XG4gICAgICAgICAgICBzZXRUYXNrQWN0aW9uRXJyb3IoJ1RoaXMgdGFzayBjYW5ub3QgYmUgdXBkYXRlZCBiZWNhdXNlIGl0IGRvZXMgbm90IGhhdmUgYSB0YXNrIElELicpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0VXBkYXRpbmdUYXNrSWQodGFza0lkKTtcbiAgICAgICAgc2V0VGFza0FjdGlvbkVycm9yKCcnKTtcbiAgICAgICAgc2V0VGFza0FjdGlvbk5vdGljZSgnJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRUYXNrID0gYXdhaXQgdXBkYXRlVGFzayh0YXNrSWQsIHVwZGF0ZXMpO1xuICAgICAgICAgICAgaWYgKCF1cGRhdGVkVGFzaykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVGhlIGdpdmVuIHRhc2sgY291bGQgbm90IGJlIGZvdW5kLiBSZWZyZXNoIHlvdXIgdGFzayBsaXN0IGFuZCB0cnkgYWdhaW4uJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldFRhc2soKGN1cnJlbnRUYXNrKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFjdXJyZW50VGFzayB8fCBTdHJpbmcoY3VycmVudFRhc2suaWQpICE9PSBTdHJpbmcodGFza0lkKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY3VycmVudFRhc2s7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgY29uc3QgaGFzT3duID0gKGtleSkgPT4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHVwZGF0ZWRUYXNrLCBrZXkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHREdWVEYXRlID0gaGFzT3duKCdkdWVEYXRlJylcbiAgICAgICAgICAgICAgICAgICAgPyB1cGRhdGVkVGFzay5kdWVEYXRlXG4gICAgICAgICAgICAgICAgICAgIDogaGFzT3duKCdkdWVfZGF0ZScpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZWRUYXNrLmR1ZV9kYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHVwZGF0ZXMuZHVlX2RhdGUgPz8gdXBkYXRlcy5kdWVEYXRlID8/IGN1cnJlbnRUYXNrLmR1ZURhdGU7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV4dERlc2NyaXB0aW9uID0gaGFzT3duKCdkZXNjcmlwdGlvbicpXG4gICAgICAgICAgICAgICAgICAgID8gdXBkYXRlZFRhc2suZGVzY3JpcHRpb25cbiAgICAgICAgICAgICAgICAgICAgOiB1cGRhdGVzLmRlc2NyaXB0aW9uID8/IGN1cnJlbnRUYXNrLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHRJc0NvbXBsZXRlID0gdXBkYXRlZFRhc2suaXNDb21wbGV0ZVxuICAgICAgICAgICAgICAgICAgICA/PyB1cGRhdGVkVGFzay5pc19jb21wbGV0ZVxuICAgICAgICAgICAgICAgICAgICA/PyB1cGRhdGVzLmlzX2NvbXBsZXRlXG4gICAgICAgICAgICAgICAgICAgID8/IHVwZGF0ZXMuaXNDb21wbGV0ZVxuICAgICAgICAgICAgICAgICAgICA/PyBjdXJyZW50VGFzay5pc0NvbXBsZXRlO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uY3VycmVudFRhc2ssXG4gICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZWRUYXNrLFxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogdXBkYXRlZFRhc2sudGl0bGUgPz8gdXBkYXRlcy50aXRsZSA/PyBjdXJyZW50VGFzay50aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IG5leHREZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgZHVlRGF0ZTogbmV4dER1ZURhdGUsXG4gICAgICAgICAgICAgICAgICAgIGlzQ29tcGxldGU6IEJvb2xlYW4obmV4dElzQ29tcGxldGUpLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgaWYgKHVwZGF0ZXMuaXNfY29tcGxldGUgIT09IHVuZGVmaW5lZCB8fCB1cGRhdGVzLmlzQ29tcGxldGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzTm93Q29tcGxldGUgPSBCb29sZWFuKHVwZGF0ZXMuaXNfY29tcGxldGUgPz8gdXBkYXRlcy5pc0NvbXBsZXRlKTtcbiAgICAgICAgICAgICAgICBzZXRUYXNrQWN0aW9uTm90aWNlKFxuICAgICAgICAgICAgICAgICAgICBpc05vd0NvbXBsZXRlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGBNYXJrZWQgXCIke3Rhc2tUaXRsZX1cIiBhcyBjb21wbGV0ZWQuYFxuICAgICAgICAgICAgICAgICAgICAgICAgOiBgUmVvcGVuZWQgXCIke3Rhc2tUaXRsZX1cIi5gLFxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldFRhc2tBY3Rpb25Ob3RpY2UoYFVwZGF0ZWQgXCIke3VwZGF0ZXMudGl0bGU/LnRyaW0oKSB8fCB0YXNrVGl0bGV9XCIuYCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldFRhc2tSZWZyZXNoU2lnbmFsKChjdXJyZW50U2lnbmFsKSA9PiBjdXJyZW50U2lnbmFsICsgMSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBjYXRjaCAocmVxdWVzdEVycm9yKSB7XG4gICAgICAgICAgICBzZXRUYXNrQWN0aW9uRXJyb3IoXG4gICAgICAgICAgICAgICAgcmVxdWVzdEVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICAgICAgPyByZXF1ZXN0RXJyb3IubWVzc2FnZVxuICAgICAgICAgICAgICAgICAgICA6ICdVbmFibGUgdG8gdXBkYXRlIHlvdXIgdGFzay4nLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldFVwZGF0aW5nVGFza0lkKG51bGwpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlc3VtZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFoYXNTdGFydGVkU2Vzc2lvbiB8fCBpc0FjdGl2ZSB8fCByZW1haW5pbmdTZWNvbmRzIDw9IDAgfHwgaXNMb2FkaW5nKSByZXR1cm47XG4gICAgICAgIFxuICAgICAgICBjb21wbGV0aW9uSGFuZGxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24oc3RhcnRUaW1lcik7XG4gICAgfTtcbiAgICBcbiAgICBjb25zdCBoYW5kbGVQYXVzZSA9ICgpID0+IHJ1blRpbWVyQWN0aW9uKHBhdXNlVGltZXIpO1xuXG4gICAgY29uc3QgaGFuZGxlU3RvcCA9ICgpID0+IHtcbiAgICAgICAgY29tcGxldGlvbkhhbmRsZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24oc3RvcFRpbWVyLCAoKSA9PiB1cGRhdGVTZXNzaW9uU3RhcnRlZCh0cnVlKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xuICAgICAgICBjb21wbGV0aW9uSGFuZGxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24ocmVzZXRUaW1lciwgKCkgPT4ge1xuICAgICAgICAgICAgc2V0UGhhc2UoJ0ZPQ1VTJyk7XG4gICAgICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKERFRkFVTFRfRk9DVVNfU0VDT05EUyk7XG4gICAgICAgICAgICBzZXRFbmRUaW1lKG51bGwpO1xuICAgICAgICAgICAgc2V0QWN0aXZlKGZhbHNlKTtcbiAgICAgICAgICAgIHVwZGF0ZVNlc3Npb25TdGFydGVkKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgICA8SW5zaWdodEFsZXJ0IC8+XG4gICAgICAgICAgICA8bWFpbiBjbGFzc05hbWU9e2BzbWFydC1mb2N1cy11aSB3b3Jrc3BhY2UtYmFja2dyb3VuZC0ke2JhY2tncm91bmR9YH0+XG4gICAgICAgICAgICAgICAgPERhc2hib2FyZFxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFRhc2s9e3Rhc2t9XG4gICAgICAgICAgICAgICAgICAgIHRhc2tTZWxlY3Rpb25EaXNhYmxlZD17aGFzU3RhcnRlZFNlc3Npb259XG4gICAgICAgICAgICAgICAgICAgIG9uU2VsZWN0VGFzaz17aGFuZGxlU2VsZWN0VGFza31cbiAgICAgICAgICAgICAgICAgICAgcmVmcmVzaFNpZ25hbD17dGFza1JlZnJlc2hTaWduYWx9XG4gICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlVGFzaz17aGFuZGxlRGVsZXRlVGFza31cbiAgICAgICAgICAgICAgICAgICAgZGVsZXRpbmdUYXNrSWQ9e2RlbGV0aW5nVGFza0lkfVxuICAgICAgICAgICAgICAgICAgICBvblVwZGF0ZVRhc2s9e2hhbmRsZVVwZGF0ZVRhc2t9XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0aW5nVGFza0lkPXt1cGRhdGluZ1Rhc2tJZH1cbiAgICAgICAgICAgICAgICAgICAgdGFza0FjdGlvbkVycm9yPXt0YXNrQWN0aW9uRXJyb3J9XG4gICAgICAgICAgICAgICAgICAgIHRhc2tBY3Rpb25Ob3RpY2U9e3Rhc2tBY3Rpb25Ob3RpY2V9XG4gICAgICAgICAgICAgICAgICAgIHRhc2tBY3Rpb25Ob3RpY2VGYWRpbmc9e2lzVGFza0FjdGlvbk5vdGljZUZhZGluZ31cbiAgICAgICAgICAgICAgICAgICAgaXNZb3V0dWJlUGxheWVyRW5hYmxlZD17aXNZb3V0dWJlUGxheWVyRW5hYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgb25Mb2dvdXQ9e2hhbmRsZUxvZ291dH1cbiAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgPFNldHRpbmdzUGFuZWwgXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ9e2JhY2tncm91bmR9XG4gICAgICAgICAgICAgICAgICAgIG9uQmFja2dyb3VuZENoYW5nZT17aGFuZGxlQmFja2dyb3VuZENoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgaXNZb3V0dWJlUGxheWVyRW5hYmxlZD17aXNZb3V0dWJlUGxheWVyRW5hYmxlZH1cbiAgICAgICAgICAgICAgICAgICAgb25Zb3V0dWJlUGxheWVyVG9nZ2xlPXtoYW5kbGVZb3V0dWJlUGxheWVyVG9nZ2xlfVxuICAgICAgICAgICAgICAgICAgICBpc1Rhc2tNYW5hZ2VyT3Blbj17aXNUYXNrTWFuYWdlck9wZW59XG4gICAgICAgICAgICAgICAgICAgIHRhc2tGb3JtPXt0YXNrRm9ybX1cbiAgICAgICAgICAgICAgICAgICAgaXNDcmVhdGluZ1Rhc2s9e2lzQ3JlYXRpbmdUYXNrfVxuICAgICAgICAgICAgICAgICAgICB0YXNrRXJyb3I9e3Rhc2tFcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgdGFza05vdGljZT17dGFza05vdGljZX1cbiAgICAgICAgICAgICAgICAgICAgdGFza05vdGljZUZhZGluZz17aXNUYXNrTm90aWNlRmFkaW5nfVxuICAgICAgICAgICAgICAgICAgICBvblRhc2tNYW5hZ2VyVG9nZ2xlPXtoYW5kbGVUYXNrTWFuYWdlclRvZ2dsZX1cbiAgICAgICAgICAgICAgICAgICAgb25UYXNrTWFuYWdlckNsb3NlPXtoYW5kbGVUYXNrTWFuYWdlckNsb3NlfVxuICAgICAgICAgICAgICAgICAgICBvblRhc2tGb3JtQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZX1cbiAgICAgICAgICAgICAgICAgICAgb25DcmVhdGVUYXNrPXtoYW5kbGVDcmVhdGVUYXNrfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtYXJ0LWZvY3VzLXNlc3Npb24tYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTdGFydFNlc3Npb25CdXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3N0YXJ0U2Vzc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0FjdGl2ZSB8fCBoYXNTdGFydGVkU2Vzc2lvbiB8fCAhdGFza31cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic21hcnQtZm9jdXMtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIHttZXNzYWdlICYmICFlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgc21hcnQtZm9jdXMtbWVzc2FnZSBhdXRvLWRpc21pc3Mtbm90aWNlJHtpc01lc3NhZ2VGYWRpbmcgPyAnIGlzLWZhZGluZycgOiAnJ31gfSByb2xlPVwic3RhdHVzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIDxQb21vZG9yb1RpbWVyXG4gICAgICAgICAgICAgICAgICAgIHRhc2s9e3Rhc2t9XG4gICAgICAgICAgICAgICAgICAgIHBoYXNlPXtwaGFzZX1cbiAgICAgICAgICAgICAgICAgICAgcmVtYWluaW5nU2Vjb25kcz17cmVtYWluaW5nU2Vjb25kc31cbiAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmU9e2lzQWN0aXZlfVxuICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgc2Vzc2lvbkNvbXBsZXRlZD17c2Vzc2lvbkNvbXBsZXRlZH1cbiAgICAgICAgICAgICAgICAgICAgZXJyb3I9eycnfVxuICAgICAgICAgICAgICAgICAgICBvblJlc3VtZT17aGFuZGxlUmVzdW1lfVxuICAgICAgICAgICAgICAgICAgICBjYW5SZXN1bWU9e2hhc1N0YXJ0ZWRTZXNzaW9uICYmICFpc0FjdGl2ZSAmJiByZW1haW5pbmdTZWNvbmRzID4gMCAmJiAhc2Vzc2lvbkNvbXBsZXRlZH1cbiAgICAgICAgICAgICAgICAgICAgb25QYXVzZT17aGFuZGxlUGF1c2V9XG4gICAgICAgICAgICAgICAgICAgIG9uU3RvcD17aGFuZGxlU3RvcH1cbiAgICAgICAgICAgICAgICAgICAgb25SZXNldD17aGFuZGxlUmVzZXR9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvbWFpbj5cbiAgICAgICAgPC8+XG4gICAgKTtcbn1cbiJdfQ==