import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PomodoroTimer.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/PomodoroTimer.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=426c4dd0";
function formatTime(totalSeconds) {
	const seconds = Math.max(0, Math.ceil(totalSeconds));
	const minutes = Math.floor(seconds / 60);
	const remainder = seconds % 60;
	return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}
function getPhaseLabel(phase) {
	if (phase === "SHORT_BREAK") return "Short Break";
	if (phase === "LONG_BREAK") return "Long Break";
	return "Focus";
}
export default function PomodoroTimer({ task, phase = "FOCUS", remainingSeconds = 20 * 60, isActive = false, isLoading = false, canResume = false, sessionCompleted = false, error = "", onResume, onPause, onStop, onReset }) {
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "pomodoro-timer",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "timer-header",
				children: /* @__PURE__ */ _jsxDEV("h2", {
					id: "timer-heading",
					children: getPhaseLabel(phase)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "timer-display",
				children: formatTime(remainingSeconds)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 13
			}, this),
			task ? /* @__PURE__ */ _jsxDEV("p", {
				className: "timer-task",
				children: ["Working on: ", /* @__PURE__ */ _jsxDEV("strong", { children: task.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 33
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 17
			}, this) : /* @__PURE__ */ _jsxDEV("p", {
				className: "timer-task",
				children: "Select a task to begin."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 17
			}, this),
			sessionCompleted && /* @__PURE__ */ _jsxDEV("p", {
				className: "timer-completion-message",
				role: "status",
				children: "Time's up!"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 17
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "timer-error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "timer-controls",
				children: [
					!isActive ? /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "timer-start",
						onClick: onResume,
						disabled: isLoading || !canResume,
						title: canResume ? "Resume paused timer" : "Start a session first",
						children: "Play"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 21
					}, this) : /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "timer-pause",
						onClick: onPause,
						disabled: isLoading,
						children: "Pause"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "timer-stop",
						onClick: onStop,
						disabled: isLoading || !isActive,
						children: "Stop"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "timer-reset",
						onClick: onReset,
						disabled: isLoading,
						children: "Reset"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 9
	}, this);
}
_c = PomodoroTimer;
var _c;
$RefreshReg$(_c, "PomodoroTimer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PomodoroTimer.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/PomodoroTimer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/PomodoroTimer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/PomodoroTimer.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTLFdBQVcsY0FBYztDQUM5QixNQUFNLFVBQVUsS0FBSyxJQUFJLEdBQUcsS0FBSyxLQUFLLFlBQVksQ0FBQztDQUNuRCxNQUFNLFVBQVUsS0FBSyxNQUFNLFVBQVUsRUFBRTtDQUN2QyxNQUFNLFlBQVksVUFBVTtDQUU1QixPQUFPLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRyxFQUFFLEdBQUcsT0FBTyxTQUFTLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztBQUNuRjtBQUVBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLElBQUksVUFBVSxlQUFlLE9BQU87Q0FDcEMsSUFBSSxVQUFVLGNBQWMsT0FBTztDQUNuQyxPQUFPO0FBQ1g7QUFFQSxlQUFlLFNBQVMsY0FBYyxFQUNsQyxNQUNBLFFBQVEsU0FDUixtQkFBbUIsS0FBSyxJQUN4QixXQUFXLE9BQ1gsWUFBWSxPQUNaLFlBQVksT0FDWixtQkFBbUIsT0FDbkIsUUFBUSxJQUNSLFVBQ0EsU0FDQSxRQUNBLFdBQ0Q7Q0FDQyxPQUNJLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0ksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWCx3QkFBQyxNQUFEO0tBQUksSUFBRztlQUFpQixjQUFjLEtBQUs7SUFBTTs7Ozs7R0FDaEQ7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDVixXQUFXLGdCQUFnQjtHQUMzQjs7Ozs7R0FFSixPQUNHLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWIsQ0FBMEIsZ0JBQ1Ysd0JBQUMsVUFBRCxZQUFTLEtBQUssTUFBYzs7OztZQUN6Qzs7Ozs7Y0FFSCx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFhO0dBQTBCOzs7OztHQUd2RCxvQkFDRyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtJQUEyQixNQUFLO2NBQVM7R0FFbkQ7Ozs7O0dBR04sU0FDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFjLE1BQUs7Y0FDN0I7R0FDQTs7Ozs7R0FHVCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0ssQ0FBQyxXQUNFLHdCQUFDLFVBQUQ7TUFDSSxNQUFLO01BQ0wsV0FBVTtNQUNWLFNBQVM7TUFDVCxVQUFVLGFBQWEsQ0FBQztNQUN4QixPQUFPLFlBQVksd0JBQXdCO2dCQUM5QztLQUVPOzs7O2dCQUVSLHdCQUFDLFVBQUQ7TUFDSSxNQUFLO01BQ0wsV0FBVTtNQUNWLFNBQVM7TUFDVCxVQUFVO2dCQUNiO0tBRU87Ozs7O0tBR1osd0JBQUMsVUFBRDtNQUNJLE1BQUs7TUFDTCxXQUFVO01BQ1YsU0FBUztNQUNULFVBQVUsYUFBYSxDQUFDO2dCQUMzQjtLQUVPOzs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDSSxNQUFLO01BQ0wsV0FBVTtNQUNWLFNBQVM7TUFDVCxVQUFVO2dCQUNiO0tBRU87Ozs7O0lBRVA7Ozs7OztFQUNBOzs7Ozs7QUFFakIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUG9tb2Rvcm9UaW1lci5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gZm9ybWF0VGltZSh0b3RhbFNlY29uZHMpIHtcbiAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5tYXgoMCwgTWF0aC5jZWlsKHRvdGFsU2Vjb25kcykpO1xuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKHNlY29uZHMgLyA2MCk7XG4gICAgY29uc3QgcmVtYWluZGVyID0gc2Vjb25kcyAlIDYwO1xuXG4gICAgcmV0dXJuIGAke1N0cmluZyhtaW51dGVzKS5wYWRTdGFydCgyLCAnMCcpfToke1N0cmluZyhyZW1haW5kZXIpLnBhZFN0YXJ0KDIsICcwJyl9YDtcbn1cblxuZnVuY3Rpb24gZ2V0UGhhc2VMYWJlbChwaGFzZSkge1xuICAgIGlmIChwaGFzZSA9PT0gJ1NIT1JUX0JSRUFLJykgcmV0dXJuICdTaG9ydCBCcmVhayc7XG4gICAgaWYgKHBoYXNlID09PSAnTE9OR19CUkVBSycpIHJldHVybiAnTG9uZyBCcmVhayc7XG4gICAgcmV0dXJuICdGb2N1cyc7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBvbW9kb3JvVGltZXIoe1xuICAgIHRhc2ssXG4gICAgcGhhc2UgPSAnRk9DVVMnLFxuICAgIHJlbWFpbmluZ1NlY29uZHMgPSAyMCAqIDYwLFxuICAgIGlzQWN0aXZlID0gZmFsc2UsXG4gICAgaXNMb2FkaW5nID0gZmFsc2UsXG4gICAgY2FuUmVzdW1lID0gZmFsc2UsXG4gICAgc2Vzc2lvbkNvbXBsZXRlZCA9IGZhbHNlLFxuICAgIGVycm9yID0gJycsXG4gICAgb25SZXN1bWUsXG4gICAgb25QYXVzZSxcbiAgICBvblN0b3AsXG4gICAgb25SZXNldCxcbn0pIHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb21vZG9yby10aW1lclwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aW1lci1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8aDIgaWQ9XCJ0aW1lci1oZWFkaW5nXCI+e2dldFBoYXNlTGFiZWwocGhhc2UpfTwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aW1lci1kaXNwbGF5XCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdFRpbWUocmVtYWluaW5nU2Vjb25kcyl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge3Rhc2sgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGltZXItdGFza1wiPlxuICAgICAgICAgICAgICAgICAgICBXb3JraW5nIG9uOiA8c3Ryb25nPnt0YXNrLnRpdGxlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGltZXItdGFza1wiPlNlbGVjdCBhIHRhc2sgdG8gYmVnaW4uPC9wPlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge3Nlc3Npb25Db21wbGV0ZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRpbWVyLWNvbXBsZXRpb24tbWVzc2FnZVwiIHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAgVGltZSdzIHVwIVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0aW1lci1lcnJvclwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRpbWVyLWNvbnRyb2xzXCI+XG4gICAgICAgICAgICAgICAgeyFpc0FjdGl2ZSA/IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0aW1lci1zdGFydFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblJlc3VtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmcgfHwgIWNhblJlc3VtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtjYW5SZXN1bWUgPyAnUmVzdW1lIHBhdXNlZCB0aW1lcicgOiAnU3RhcnQgYSBzZXNzaW9uIGZpcnN0J31cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgUGxheVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRpbWVyLXBhdXNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uUGF1c2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBQYXVzZVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGltZXItc3RvcFwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uU3RvcH1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZyB8fCAhaXNBY3RpdmV9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBTdG9wXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0aW1lci1yZXNldFwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uUmVzZXR9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBSZXNldFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9zZWN0aW9uPiAgXG4gICAgKTtcbn0iXX0=