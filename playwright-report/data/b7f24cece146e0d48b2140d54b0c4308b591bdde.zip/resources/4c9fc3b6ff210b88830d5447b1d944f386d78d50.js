import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SettingsPanel.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=426c4dd0";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=426c4dd0";
var _s = $RefreshSig$();
const EMPTY_TASK_FORM = {
	title: "",
	description: "",
	dueDate: ""
};
const BACKGROUNDS = [
	{
		value: "plain",
		label: "Plain White",
		description: "Clean white background"
	},
	{
		value: "paper",
		label: "Warm Paper",
		description: "Gives background a paper-like texture"
	},
	{
		value: "greenery",
		label: "Soft Greenery",
		description: "Subtle green garden-like tones"
	},
	{
		value: "sunset",
		label: "Warm Sunset",
		description: "Muted peach and cream tones"
	},
	{
		value: "blue-grid",
		label: "Blue Grid",
		description: "Light blue notebook grid"
	}
];
export default function SettingsPanel({ background, onBackgroundChange, isTaskManagerOpen = false, taskForm = EMPTY_TASK_FORM, isCreatingTask = false, taskError = "", taskNotice = "", taskNoticeFading = false, onTaskManagerToggle = () => {}, onTaskManagerClose = () => {}, onTaskFormChange = () => {}, onCreateTask = (event) => event.preventDefault() }) {
	_s();
	const [isBackgroundOpen, setBackgroundOpen] = useState(false);
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "settings-panel",
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: `settings-shortcut settings-background-trigger${isBackgroundOpen ? " is-active" : ""}`,
				onClick: () => {
					onTaskManagerClose?.();
					setBackgroundOpen((open) => !open);
				},
				title: "Change Background",
				children: /* @__PURE__ */ _jsxDEV("span", { children: "B" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: `settings-shortcut settings-task-trigger${isTaskManagerOpen ? " is-active" : ""}`,
				onClick: () => {
					setBackgroundOpen(false);
					onTaskManagerToggle?.();
				},
				title: "Add a Task",
				children: /* @__PURE__ */ _jsxDEV("span", { children: "T" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 13
			}, this),
			isBackgroundOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "background-selector",
				id: "background-selector",
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "background-image-select",
						children: "Background Image"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("select", {
						id: "background-image-select",
						value: background,
						onChange: (event) => onBackgroundChange(event.target.value),
						children: BACKGROUNDS.map((option) => /* @__PURE__ */ _jsxDEV("option", {
							value: option.value,
							children: option.label
						}, option.value, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 29
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 21
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "background-selector-help",
						children: "Choose a look for your background."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 17
			}, this),
			isTaskManagerOpen && /* @__PURE__ */ _jsxDEV("section", {
				className: "task-manager-panel",
				id: "task-manager-panel",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "task-manager-header",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							id: "task-manager-heading",
							children: "Add a Task"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Enter the details for your new task." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 29
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 25
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "task-manager-close",
							onClick: onTaskManagerClose,
							children: "X"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 25
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 21
					}, this),
					taskError && /* @__PURE__ */ _jsxDEV("p", {
						className: "task-manager-feedback-error",
						role: "alert",
						children: taskError
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 25
					}, this),
					taskNotice && /* @__PURE__ */ _jsxDEV("p", {
						className: `task-manager-feedback is-success auto-dismiss-notice${taskNoticeFading ? " is-fading" : ""}`,
						role: "status",
						children: taskNotice
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 25
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						className: "task-create-form",
						onSubmit: onCreateTask,
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "task-title",
								children: "Task Title"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: "new-task-title",
								name: "title",
								type: "text",
								value: taskForm.title,
								onChange: (event) => onTaskFormChange("title", event.target.value),
								maxLength: 150,
								required: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "new-task-description",
								children: ["Description ", /* @__PURE__ */ _jsxDEV("span", { children: "(optional)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 75
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: "new-task-description",
								name: "description",
								value: taskForm.description,
								onChange: (event) => onTaskFormChange("description", event.target.value),
								maxLength: 500,
								rows: 2
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "new-task-due-date",
								children: ["Due Date ", /* @__PURE__ */ _jsxDEV("span", { children: "(optional)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 69
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: "new-task-due-date",
								name: "dueDate",
								type: "date",
								value: taskForm.dueDate,
								onChange: (event) => onTaskFormChange("dueDate", event.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 25
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "task-manager-add-button",
								disabled: isCreatingTask,
								children: isCreatingTask ? "Adding..." : "Add Task"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 25
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 21
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 17
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 9
	}, this);
}
_s(SettingsPanel, "Z2K5UxuKS64Bn53I8nfh4wgE4eg=");
_c = SettingsPanel;
var _c;
$RefreshReg$(_c, "SettingsPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SettingsPanel.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/SettingsPanel.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsTUFBTSxrQkFBa0I7Q0FBRSxPQUFPO0NBQUksYUFBYTtDQUFJLFNBQVM7QUFBRztBQUVsRSxNQUFNLGNBQWM7Q0FDaEI7RUFBRSxPQUFPO0VBQVMsT0FBTztFQUFlLGFBQWE7Q0FBeUI7Q0FDOUU7RUFBRSxPQUFPO0VBQVMsT0FBTztFQUFjLGFBQWE7Q0FBdUM7Q0FDM0Y7RUFBRSxPQUFPO0VBQVksT0FBTztFQUFpQixhQUFZO0NBQWlDO0NBQzFGO0VBQUUsT0FBTztFQUFVLE9BQU87RUFBZSxhQUFhO0NBQThCO0NBQ3BGO0VBQUUsT0FBTztFQUFhLE9BQU87RUFBYSxhQUFhO0NBQTBCO0FBQ3JGO0FBRUEsZUFBZSxTQUFTLGNBQWMsRUFDbEMsWUFDQSxvQkFDQSxvQkFBb0IsT0FDcEIsV0FBVyxpQkFDWCxpQkFBaUIsT0FDakIsWUFBWSxJQUNaLGFBQWEsSUFDYixtQkFBbUIsT0FDbkIsNEJBQTRCLENBQUMsR0FDN0IsMkJBQTJCLENBQUMsR0FDNUIseUJBQXlCLENBQUMsR0FDMUIsZ0JBQWdCLFVBQVUsTUFBTSxlQUFlLEtBQ2hEOztDQUNDLE1BQU0sQ0FBQyxrQkFBa0IscUJBQXFCLFNBQVMsS0FBSztDQUU1RCxPQUNJLHdCQUFDLFNBQUQ7RUFBTyxXQUFVO1lBQWpCO0dBQ0ksd0JBQUMsVUFBRDtJQUNJLE1BQUs7SUFDTCxXQUFXLGdEQUFnRCxtQkFBbUIsZUFBZTtJQUM3RixlQUFlO0tBQ1gscUJBQXFCO0tBQ3JCLG1CQUFtQixTQUFTLENBQUMsSUFBSTtJQUNyQztJQUNBLE9BQU07Y0FFTix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7R0FDVDs7Ozs7R0FFUix3QkFBQyxVQUFEO0lBQ0ksTUFBSztJQUNMLFdBQVcsMENBQTBDLG9CQUFvQixlQUFlO0lBQ3hGLGVBQWU7S0FDWCxrQkFBa0IsS0FBSztLQUN2QixzQkFBc0I7SUFDMUI7SUFDQSxPQUFNO2NBRU4sd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O0dBQ1Q7Ozs7O0dBRVAsb0JBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBc0IsSUFBRztjQUF4QztLQUNJLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUEwQjtLQUF1Qjs7Ozs7S0FDaEUsd0JBQUMsVUFBRDtNQUNJLElBQUc7TUFDSCxPQUFPO01BQ1AsV0FBVyxVQUFVLG1CQUFtQixNQUFNLE9BQU8sS0FBSztnQkFFekQsWUFBWSxLQUFLLFdBQ2Qsd0JBQUMsVUFBRDtPQUEyQixPQUFPLE9BQU87aUJBQ3BDLE9BQU87TUFDSixHQUZLLE9BQU87Ozs7YUFFWixDQUNYO0tBQ0c7Ozs7O0tBQ1Isd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTJCO0tBRXJDOzs7OztJQUNGOzs7Ozs7R0FHUixxQkFDRyx3QkFBQyxXQUFEO0lBQ0ksV0FBVTtJQUNWLElBQUc7Y0FGUDtLQUlJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0ksd0JBQUMsT0FBRCxhQUNJLHdCQUFDLE1BQUQ7T0FBSSxJQUFHO2lCQUF1QjtNQUFjOzs7O2dCQUM1Qyx3QkFBQyxLQUFELFlBQUcsdUNBQXVDOzs7O2NBQ3pDOzs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsV0FBVTtPQUNWLFNBQVM7aUJBQ1o7TUFFTzs7OztjQUNQOzs7Ozs7S0FFSixhQUNHLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQThCLE1BQUs7Z0JBQzNDO0tBQ0Y7Ozs7O0tBRU4sY0FDRyx3QkFBQyxLQUFEO01BQUcsV0FBVyx1REFBdUQsbUJBQW1CLGVBQWU7TUFBTSxNQUFLO2dCQUM3RztLQUNGOzs7OztLQUdQLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQW1CLFVBQVU7Z0JBQTdDO09BQ0ksd0JBQUMsU0FBRDtRQUFPLFNBQVE7a0JBQWE7T0FBaUI7Ozs7O09BQzdDLHdCQUFDLFNBQUQ7UUFDSSxJQUFHO1FBQ0gsTUFBSztRQUNMLE1BQUs7UUFDTCxPQUFPLFNBQVM7UUFDaEIsV0FBVyxVQUFVLGlCQUFpQixTQUFTLE1BQU0sT0FBTyxLQUFLO1FBQ2pFLFdBQVc7UUFDWDtPQUNIOzs7OztPQUVELHdCQUFDLFNBQUQ7UUFBTyxTQUFRO2tCQUFmLENBQXNDLGdCQUFZLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztnQkFBUTs7Ozs7O09BQ2hGLHdCQUFDLFlBQUQ7UUFDSSxJQUFHO1FBQ0gsTUFBSztRQUNMLE9BQU8sU0FBUztRQUNoQixXQUFXLFVBQVUsaUJBQWlCLGVBQWUsTUFBTSxPQUFPLEtBQUs7UUFDdkUsV0FBVztRQUNYLE1BQU07T0FDVDs7Ozs7T0FFRCx3QkFBQyxTQUFEO1FBQU8sU0FBUTtrQkFBZixDQUFtQyxhQUFTLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztnQkFBUTs7Ozs7O09BQzFFLHdCQUFDLFNBQUQ7UUFDSSxJQUFHO1FBQ0gsTUFBSztRQUNMLE1BQUs7UUFDTCxPQUFPLFNBQVM7UUFDaEIsV0FBVyxVQUFVLGlCQUFpQixXQUFXLE1BQU0sT0FBTyxLQUFLO09BQ3RFOzs7OztPQUVELHdCQUFDLFVBQUQ7UUFDSSxNQUFLO1FBQ0wsV0FBVTtRQUNWLFVBQVU7a0JBRVQsaUJBQWlCLGNBQWM7T0FDNUI7Ozs7O01BQ047Ozs7OztJQUNEOzs7Ozs7RUFFVjs7Ozs7O0FBRWYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2V0dGluZ3NQYW5lbC5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IEVNUFRZX1RBU0tfRk9STSA9IHsgdGl0bGU6ICcnLCBkZXNjcmlwdGlvbjogJycsIGR1ZURhdGU6ICcnIH07XG5cbmNvbnN0IEJBQ0tHUk9VTkRTID0gW1xuICAgIHsgdmFsdWU6ICdwbGFpbicsIGxhYmVsOiAnUGxhaW4gV2hpdGUnLCBkZXNjcmlwdGlvbjogJ0NsZWFuIHdoaXRlIGJhY2tncm91bmQnIH0sXG4gICAgeyB2YWx1ZTogJ3BhcGVyJywgbGFiZWw6ICdXYXJtIFBhcGVyJywgZGVzY3JpcHRpb246ICdHaXZlcyBiYWNrZ3JvdW5kIGEgcGFwZXItbGlrZSB0ZXh0dXJlJ30sXG4gICAgeyB2YWx1ZTogJ2dyZWVuZXJ5JywgbGFiZWw6ICdTb2Z0IEdyZWVuZXJ5JywgZGVzY3JpcHRpb246J1N1YnRsZSBncmVlbiBnYXJkZW4tbGlrZSB0b25lcycgfSxcbiAgICB7IHZhbHVlOiAnc3Vuc2V0JywgbGFiZWw6ICdXYXJtIFN1bnNldCcsIGRlc2NyaXB0aW9uOiAnTXV0ZWQgcGVhY2ggYW5kIGNyZWFtIHRvbmVzJyB9LFxuICAgIHsgdmFsdWU6ICdibHVlLWdyaWQnLCBsYWJlbDogJ0JsdWUgR3JpZCcsIGRlc2NyaXB0aW9uOiAnTGlnaHQgYmx1ZSBub3RlYm9vayBncmlkJ31cbl07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNldHRpbmdzUGFuZWwoe1xuICAgIGJhY2tncm91bmQsXG4gICAgb25CYWNrZ3JvdW5kQ2hhbmdlLFxuICAgIGlzVGFza01hbmFnZXJPcGVuID0gZmFsc2UsXG4gICAgdGFza0Zvcm0gPSBFTVBUWV9UQVNLX0ZPUk0sXG4gICAgaXNDcmVhdGluZ1Rhc2sgPSBmYWxzZSxcbiAgICB0YXNrRXJyb3IgPSAnJyxcbiAgICB0YXNrTm90aWNlID0gJycsXG4gICAgdGFza05vdGljZUZhZGluZyA9IGZhbHNlLFxuICAgIG9uVGFza01hbmFnZXJUb2dnbGUgPSAoKSA9PiB7fSxcbiAgICBvblRhc2tNYW5hZ2VyQ2xvc2UgPSAoKSA9PiB7fSxcbiAgICBvblRhc2tGb3JtQ2hhbmdlID0gKCkgPT4ge30sXG4gICAgb25DcmVhdGVUYXNrID0gKGV2ZW50KSA9PiBldmVudC5wcmV2ZW50RGVmYXVsdCgpLFxufSkge1xuICAgIGNvbnN0IFtpc0JhY2tncm91bmRPcGVuLCBzZXRCYWNrZ3JvdW5kT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwic2V0dGluZ3MtcGFuZWxcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BzZXR0aW5ncy1zaG9ydGN1dCBzZXR0aW5ncy1iYWNrZ3JvdW5kLXRyaWdnZXIke2lzQmFja2dyb3VuZE9wZW4gPyAnIGlzLWFjdGl2ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgb25UYXNrTWFuYWdlckNsb3NlPy4oKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0QmFja2dyb3VuZE9wZW4oKG9wZW4pID0+ICFvcGVuKVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgdGl0bGU9XCJDaGFuZ2UgQmFja2dyb3VuZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+Qjwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2V0dGluZ3Mtc2hvcnRjdXQgc2V0dGluZ3MtdGFzay10cmlnZ2VyJHtpc1Rhc2tNYW5hZ2VyT3BlbiA/ICcgaXMtYWN0aXZlJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBzZXRCYWNrZ3JvdW5kT3BlbihmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIG9uVGFza01hbmFnZXJUb2dnbGU/LigpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgdGl0bGU9XCJBZGQgYSBUYXNrXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj5UPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHtpc0JhY2tncm91bmRPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJhY2tncm91bmQtc2VsZWN0b3JcIiBpZD1cImJhY2tncm91bmQtc2VsZWN0b3JcIj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJiYWNrZ3JvdW5kLWltYWdlLXNlbGVjdFwiPkJhY2tncm91bmQgSW1hZ2U8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImJhY2tncm91bmQtaW1hZ2Utc2VsZWN0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiYWNrZ3JvdW5kfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25CYWNrZ3JvdW5kQ2hhbmdlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtCQUNLR1JPVU5EUy5tYXAoKG9wdGlvbikgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJiYWNrZ3JvdW5kLXNlbGVjdG9yLWhlbHBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIENob29zZSBhIGxvb2sgZm9yIHlvdXIgYmFja2dyb3VuZC5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2lzVGFza01hbmFnZXJPcGVuICYmIChcbiAgICAgICAgICAgICAgICA8c2VjdGlvblxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItcGFuZWxcIlxuICAgICAgICAgICAgICAgICAgICBpZD1cInRhc2stbWFuYWdlci1wYW5lbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbWFuYWdlci1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGlkPVwidGFzay1tYW5hZ2VyLWhlYWRpbmdcIj5BZGQgYSBUYXNrPC9oMj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5FbnRlciB0aGUgZGV0YWlscyBmb3IgeW91ciBuZXcgdGFzay48L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItY2xvc2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uVGFza01hbmFnZXJDbG9zZX1cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBYXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAge3Rhc2tFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0YXNrLW1hbmFnZXItZmVlZGJhY2stZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFza0Vycm9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7dGFza05vdGljZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0YXNrLW1hbmFnZXItZmVlZGJhY2sgaXMtc3VjY2VzcyBhdXRvLWRpc21pc3Mtbm90aWNlJHt0YXNrTm90aWNlRmFkaW5nID8gJyBpcy1mYWRpbmcnIDogJyd9YH0gcm9sZT1cInN0YXR1c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrTm90aWNlfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInRhc2stY3JlYXRlLWZvcm1cIiBvblN1Ym1pdD17b25DcmVhdGVUYXNrfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidGFzay10aXRsZVwiPlRhc2sgVGl0bGU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuZXctdGFzay10aXRsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRpdGxlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uVGFza0Zvcm1DaGFuZ2UoJ3RpdGxlJywgZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezE1MH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctdGFzay1kZXNjcmlwdGlvblwiPkRlc2NyaXB0aW9uIDxzcGFuPihvcHRpb25hbCk8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmV3LXRhc2stZGVzY3JpcHRpb25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkZXNjcmlwdGlvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IG9uVGFza0Zvcm1DaGFuZ2UoJ2Rlc2NyaXB0aW9uJywgZXZlbnQudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezUwMH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXsyfVxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctdGFzay1kdWUtZGF0ZVwiPkR1ZSBEYXRlIDxzcGFuPihvcHRpb25hbCk8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmV3LXRhc2stZHVlLWRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkdWVEYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Rhc2tGb3JtLmR1ZURhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gb25UYXNrRm9ybUNoYW5nZSgnZHVlRGF0ZScsIGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGFzay1tYW5hZ2VyLWFkZC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0NyZWF0aW5nVGFza31cbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNDcmVhdGluZ1Rhc2sgPyAnQWRkaW5nLi4uJyA6ICdBZGQgVGFzayd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgIDwvYXNpZGU+XG4gICAgKTtcbn0iXX0=