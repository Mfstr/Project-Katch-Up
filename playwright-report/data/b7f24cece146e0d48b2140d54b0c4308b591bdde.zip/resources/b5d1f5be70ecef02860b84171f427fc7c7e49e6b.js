import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Dashboard.jsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=426c4dd0";
import { getTasks } from "/src/services/apiClient.js";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=426c4dd0";
var _s = $RefreshSig$();
function normalizeTasks(task) {
	return {
		id: task?.id ?? task?.taskId,
		title: task?.title ?? task?.name ?? "Untitled Task",
		description: task?.description ?? "",
		dueDate: task?.dueDate ?? task?.due_date ?? null,
		isComplete: Boolean(task?.isComplete ?? task?.is_complete ?? false),
		durationSeconds: task?.durationSeconds ?? task?.duration_seconds ?? 20 * 60
	};
}
function formatDueDate(value) {
	if (!value) return null;
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return null;
	return date.toLocaleDateString();
}
export default function Dashboard({ selectedTask, onSelectTask, taskSelectionDisabled = false, refreshSignal = 0, onDeleteTask, deletingTaskId = null, taskActionError = "", taskActionNotice = "", taskActionNoticeFading = false }) {
	_s();
	const [tasks, setTasks] = useState([]);
	const [isLoading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const loadTasks = useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const responseTasks = await getTasks();
			const nextTasks = responseTasks.map(normalizeTasks).filter((task) => !task.isComplete);
			setTasks(nextTasks);
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Unable to load tasks.");
		} finally {
			setLoading(false);
		}
	}, []);
	useEffect(() => {
		loadTasks();
	}, [loadTasks, refreshSignal]);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "dashboard",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: /* @__PURE__ */ _jsxDEV("h1", {
					id: "dashboard-heading",
					children: "Your Tasks"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 21
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "refresh-tasks",
					onClick: loadTasks,
					disabled: isLoading,
					children: isLoading ? "Loading..." : "Refresh Tasks"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 17
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 13
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 17
			}, this),
			taskActionError && /* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-error",
				role: "alert",
				children: taskActionError
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 17
			}, this),
			taskActionNotice && /* @__PURE__ */ _jsxDEV("div", {
				className: `dashboard-notice auto-dismiss-notice${taskActionNoticeFading ? " is-fading" : ""}`,
				role: "status",
				children: taskActionNotice
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 17
			}, this),
			!isLoading && !error && tasks.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "empty-state",
				children: "No incomplete tasks were found."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "task-list",
				role: "list",
				children: tasks.map((task, index) => {
					const dueDate = formatDueDate(task.dueDate);
					const isSelected = task.id != null && String(selectedTask?.id) === String(task.id);
					const isDeleting = String(deletingTaskId) === String(task.id) && deletingTaskId !== null;
					const taskKey = task.id ?? `task-${index}`;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "task-list-item",
						role: "listitem",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: `task-card${isSelected ? " selected" : ""}`,
							onClick: () => onSelectTask?.(task),
							disabled: taskSelectionDisabled,
							title: taskSelectionDisabled ? "Finish or reset the current session before selecting another task." : `Select ${task.title}`,
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "task-card-title",
									children: task.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 37
								}, this),
								task.description && /* @__PURE__ */ _jsxDEV("span", {
									className: "task-card-description",
									children: task.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 41
								}, this),
								dueDate && /* @__PURE__ */ _jsxDEV("span", {
									className: "task-card-due-date",
									children: ["Due ", dueDate]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 41
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 29
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "task-delete-button",
							onClick: () => onDeleteTask?.(task),
							disabled: !onDeleteTask || task.id == null || isDeleting,
							title: `Delete ${task.title}`,
							children: isDeleting ? "Deleting..." : "Delete"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 29
						}, this)]
					}, taskKey, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 25
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 9
	}, this);
}
_s(Dashboard, "a0EwJ1FY4riQ3ws+yJ92XvFrlLA=");
_c = Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Dashboard.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/Dashboard.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBQ2pELFNBQVMsZ0JBQWdCOzs7O0FBRXpCLFNBQVMsZUFBZSxNQUFNO0NBQzFCLE9BQU87RUFDSCxJQUFJLE1BQU0sTUFBTSxNQUFNO0VBQ3RCLE9BQU8sTUFBTSxTQUFTLE1BQU0sUUFBUTtFQUNwQyxhQUFhLE1BQU0sZUFBZTtFQUNsQyxTQUFTLE1BQU0sV0FBVyxNQUFNLFlBQVk7RUFDNUMsWUFBWSxRQUFRLE1BQU0sY0FBYyxNQUFNLGVBQWUsS0FBSztFQUNsRSxpQkFBaUIsTUFBTSxtQkFBbUIsTUFBTSxvQkFBb0IsS0FBSztDQUM3RTtBQUNKO0FBRUEsU0FBUyxjQUFjLE9BQU87Q0FDMUIsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUVuQixNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FDM0IsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLENBQUMsR0FBRyxPQUFPO0NBRXpDLE9BQU8sS0FBSyxtQkFBbUI7QUFDbkM7QUFFQSxlQUFlLFNBQVMsVUFBVSxFQUM5QixjQUNBLGNBQ0Esd0JBQXdCLE9BQ3hCLGdCQUFnQixHQUNoQixjQUNBLGlCQUFpQixNQUNqQixrQkFBa0IsSUFDbEIsbUJBQW1CLElBQ25CLHlCQUF5QixTQUMxQjs7Q0FDQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsQ0FBQyxDQUFDO0NBQ3JDLE1BQU0sQ0FBQyxXQUFXLGNBQWMsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLE1BQU0sWUFBWSxZQUFZLFlBQVk7RUFDdEMsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNBLE1BQU0sZ0JBQWdCLE1BQU0sU0FBUztHQUNyQyxNQUFNLFlBQVksY0FBYyxJQUFJLGNBQWMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxDQUFDLEtBQUssVUFBVTtHQUNyRixTQUFTLFNBQVM7RUFDdEIsU0FBUyxjQUFjO0dBQ25CLFNBQ0ksd0JBQXdCLFFBQ2xCLGFBQWEsVUFDYix1QkFDVjtFQUNKLFVBQVU7R0FDTixXQUFXLEtBQUs7RUFDcEI7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUFFLFVBQVU7Q0FBRyxHQUFHLENBQUMsV0FBVyxhQUFhLENBQUM7Q0FFNUQsT0FDSSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNJLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDSSx3QkFBQyxPQUFELFlBQ0ksd0JBQUMsTUFBRDtLQUFJLElBQUc7ZUFBb0I7SUFBYzs7OzthQUN4Qzs7OztjQUVMLHdCQUFDLFVBQUQ7S0FDSSxNQUFLO0tBQ0wsV0FBVTtLQUNWLFNBQVM7S0FDVCxVQUFVO2VBRVQsWUFBWSxlQUFlO0lBQ3hCOzs7O1lBQ1A7Ozs7OztHQUVKLFNBQ0csd0JBQUMsT0FBRDtJQUFLLFdBQVc7SUFBa0IsTUFBSztjQUNsQztHQUNBOzs7OztHQUdSLG1CQUNHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWtCLE1BQUs7Y0FDakM7R0FDQTs7Ozs7R0FHUixvQkFDRyx3QkFBQyxPQUFEO0lBQUssV0FBVyx1Q0FBdUMseUJBQXlCLGVBQWU7SUFBTSxNQUFLO2NBQ3JHO0dBQ0E7Ozs7O0dBR1IsQ0FBQyxhQUFhLENBQUMsU0FBUyxNQUFNLFdBQVcsS0FDdEMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYztHQUFrQzs7Ozs7R0FHakUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7SUFBWSxNQUFLO2NBQzNCLE1BQU0sS0FBSyxNQUFNLFVBQVU7S0FDeEIsTUFBTSxVQUFVLGNBQWMsS0FBSyxPQUFPO0tBQzFDLE1BQU0sYUFBYSxLQUFLLE1BQU0sUUFBUSxPQUFPLGNBQWMsRUFBRSxNQUFNLE9BQU8sS0FBSyxFQUFFO0tBQ2pGLE1BQU0sYUFBYSxPQUFPLGNBQWMsTUFBTSxPQUFPLEtBQUssRUFBRSxLQUFLLG1CQUFtQjtLQUNwRixNQUFNLFVBQVUsS0FBSyxNQUFNLFFBQVE7S0FFbkMsT0FDSSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUErQixNQUFLO2dCQUFuRCxDQUNJLHdCQUFDLFVBQUQ7T0FDSSxNQUFLO09BQ0wsV0FBVyxZQUFZLGFBQWEsY0FBYztPQUNsRCxlQUFlLGVBQWUsSUFBSTtPQUNsQyxVQUFVO09BQ1YsT0FBTyx3QkFBd0IsdUVBQXVFLFVBQVUsS0FBSztpQkFMekg7UUFPUSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUIsS0FBSztRQUFZOzs7OztRQUVuRCxLQUFLLGVBQ0Ysd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7OztRQUdULFdBQ0csd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQXFDLFFBQzVCLE9BQ0g7Ozs7OztPQUVWOzs7OztnQkFFUix3QkFBQyxVQUFEO09BQ0ksTUFBSztPQUNMLFdBQVU7T0FDVixlQUFlLGVBQWUsSUFBSTtPQUNsQyxVQUFVLENBQUMsZ0JBQWdCLEtBQUssTUFBTSxRQUFRO09BQzlDLE9BQU8sVUFBVSxLQUFLO2lCQUVyQixhQUFhLGdCQUFnQjtNQUMxQjs7OztjQUNQO1FBaENnQzs7OztZQWdDaEM7SUFFYixDQUFDO0dBQ0E7Ozs7O0VBQ0E7Ozs7OztBQUVqQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmQuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0VGFza3MgfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGlDbGllbnQuanMnO1xuXG5mdW5jdGlvbiBub3JtYWxpemVUYXNrcyh0YXNrKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IHRhc2s/LmlkID8/IHRhc2s/LnRhc2tJZCxcbiAgICAgICAgdGl0bGU6IHRhc2s/LnRpdGxlID8/IHRhc2s/Lm5hbWUgPz8gJ1VudGl0bGVkIFRhc2snLFxuICAgICAgICBkZXNjcmlwdGlvbjogdGFzaz8uZGVzY3JpcHRpb24gPz8gJycsXG4gICAgICAgIGR1ZURhdGU6IHRhc2s/LmR1ZURhdGUgPz8gdGFzaz8uZHVlX2RhdGUgPz8gbnVsbCxcbiAgICAgICAgaXNDb21wbGV0ZTogQm9vbGVhbih0YXNrPy5pc0NvbXBsZXRlID8/IHRhc2s/LmlzX2NvbXBsZXRlID8/IGZhbHNlKSxcbiAgICAgICAgZHVyYXRpb25TZWNvbmRzOiB0YXNrPy5kdXJhdGlvblNlY29uZHMgPz8gdGFzaz8uZHVyYXRpb25fc2Vjb25kcyA/PyAyMCAqIDYwLFxuICAgIH07XG59XG5cbmZ1bmN0aW9uIGZvcm1hdER1ZURhdGUodmFsdWUpIHtcbiAgICBpZiAoIXZhbHVlKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gICAgaWYgKE51bWJlci5pc05hTihkYXRlLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xuXG4gICAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKCk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhc2hib2FyZCh7XG4gICAgc2VsZWN0ZWRUYXNrLFxuICAgIG9uU2VsZWN0VGFzayxcbiAgICB0YXNrU2VsZWN0aW9uRGlzYWJsZWQgPSBmYWxzZSxcbiAgICByZWZyZXNoU2lnbmFsID0gMCxcbiAgICBvbkRlbGV0ZVRhc2ssXG4gICAgZGVsZXRpbmdUYXNrSWQgPSBudWxsLFxuICAgIHRhc2tBY3Rpb25FcnJvciA9ICcnLFxuICAgIHRhc2tBY3Rpb25Ob3RpY2UgPSAnJyxcbiAgICB0YXNrQWN0aW9uTm90aWNlRmFkaW5nID0gZmFsc2UsXG59KSB7XG4gICAgY29uc3QgW3Rhc2tzLCBzZXRUYXNrc10gPSB1c2VTdGF0ZShbXSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgICBjb25zdCBsb2FkVGFza3MgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHNldEVycm9yKCcnKTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2VUYXNrcyA9IGF3YWl0IGdldFRhc2tzKCk7XG4gICAgICAgICAgICBjb25zdCBuZXh0VGFza3MgPSByZXNwb25zZVRhc2tzLm1hcChub3JtYWxpemVUYXNrcykuZmlsdGVyKCh0YXNrKSA9PiAhdGFzay5pc0NvbXBsZXRlKTtcbiAgICAgICAgICAgIHNldFRhc2tzKG5leHRUYXNrcyk7XG4gICAgICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgICAgICAgc2V0RXJyb3IoIFxuICAgICAgICAgICAgICAgIHJlcXVlc3RFcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIGxvYWQgdGFza3MuJywgXG4gICAgICAgICAgICApO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4geyBsb2FkVGFza3MoKTsgfSwgW2xvYWRUYXNrcywgcmVmcmVzaFNpZ25hbF0pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZGFzaGJvYXJkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1oZWFkZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDEgaWQ9XCJkYXNoYm9hcmQtaGVhZGluZ1wiPllvdXIgVGFza3M8L2gxPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVmcmVzaC10YXNrc1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2xvYWRUYXNrc31cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAnTG9hZGluZy4uLicgOiAnUmVmcmVzaCBUYXNrcyd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZSA9XCJkYXNoYm9hcmQtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge3Rhc2tBY3Rpb25FcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAge3Rhc2tBY3Rpb25FcnJvcn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHt0YXNrQWN0aW9uTm90aWNlICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGRhc2hib2FyZC1ub3RpY2UgYXV0by1kaXNtaXNzLW5vdGljZSR7dGFza0FjdGlvbk5vdGljZUZhZGluZyA/ICcgaXMtZmFkaW5nJyA6ICcnfWB9IHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAge3Rhc2tBY3Rpb25Ob3RpY2V9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7IWlzTG9hZGluZyAmJiAhZXJyb3IgJiYgdGFza3MubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZVwiPk5vIGluY29tcGxldGUgdGFza3Mgd2VyZSBmb3VuZC48L3A+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbGlzdFwiIHJvbGU9XCJsaXN0XCI+XG4gICAgICAgICAgICAgICAge3Rhc2tzLm1hcCgodGFzaywgaW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZHVlRGF0ZSA9IGZvcm1hdER1ZURhdGUodGFzay5kdWVEYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHRhc2suaWQgIT0gbnVsbCAmJiBTdHJpbmcoc2VsZWN0ZWRUYXNrPy5pZCkgPT09IFN0cmluZyh0YXNrLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEZWxldGluZyA9IFN0cmluZyhkZWxldGluZ1Rhc2tJZCkgPT09IFN0cmluZyh0YXNrLmlkKSAmJiBkZWxldGluZ1Rhc2tJZCAhPT0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdGFza0tleSA9IHRhc2suaWQgPz8gYHRhc2stJHtpbmRleH1gO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRhc2stbGlzdC1pdGVtXCIga2V5PXt0YXNrS2V5fSByb2xlPVwibGlzdGl0ZW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0YXNrLWNhcmQke2lzU2VsZWN0ZWQgPyAnIHNlbGVjdGVkJyA6ICcnfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0VGFzaz8uKHRhc2spfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dGFza1NlbGVjdGlvbkRpc2FibGVkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17dGFza1NlbGVjdGlvbkRpc2FibGVkID8gJ0ZpbmlzaCBvciByZXNldCB0aGUgY3VycmVudCBzZXNzaW9uIGJlZm9yZSBzZWxlY3RpbmcgYW5vdGhlciB0YXNrLicgOiBgU2VsZWN0ICR7dGFzay50aXRsZX1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YXNrLWNhcmQtdGl0bGVcIj57dGFzay50aXRsZX08L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLmRlc2NyaXB0aW9uICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0YXNrLWNhcmQtZGVzY3JpcHRpb25cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Rhc2suZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2R1ZURhdGUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRhc2stY2FyZC1kdWUtZGF0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEdWUge2R1ZURhdGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRhc2stZGVsZXRlLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRGVsZXRlVGFzaz8uKHRhc2spfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IW9uRGVsZXRlVGFzayB8fCB0YXNrLmlkID09IG51bGwgfHwgaXNEZWxldGluZ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2BEZWxldGUgJHt0YXNrLnRpdGxlfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNEZWxldGluZyA/ICdEZWxldGluZy4uLicgOiAnRGVsZXRlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICApO1xufSJdfQ==