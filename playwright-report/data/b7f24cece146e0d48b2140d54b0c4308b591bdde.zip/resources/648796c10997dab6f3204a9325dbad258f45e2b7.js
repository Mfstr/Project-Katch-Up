import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SmartFocusUI.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=426c4dd0";
import { createTask, deleteTask, getNextTask, getTimerStatus, pauseTimer, resetTimer, startTimer, stopTimer } from "/src/services/apiClient.js";
import StartSessionButton from "/src/components/StartSessionButton.jsx";
import Dashboard from "/src/components/Dashboard.jsx";
import PomodoroTimer from "/src/components/PomodoroTimer.jsx";
import SettingsPanel from "/src/components/SettingsPanel.jsx";
var _jsxFileName = "/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=426c4dd0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const DEFAULT_FOCUS_SECONDS = 20 * 60;
const SHORT_BREAK_SECONDS = 5 * 60;
const EMPTY_TASK_FORM = {
	title: "",
	description: "",
	dueDate: ""
};
function readSavedTask() {
	try {
		const savedTask = window.localStorage.getItem("project-katchup-selected-task");
		return savedTask ? JSON.parse(savedTask) : null;
	} catch {
		return null;
	}
}
function useAutoDismissNotice(notice, clearNotice, fadeAfterMs = 3500, fadeDurationMs = 450) {
	_s();
	const [isFading, setIsFading] = useState(false);
	useEffect(() => {
		if (!notice) {
			setIsFading(false);
			return undefined;
		}
		setIsFading(false);
		const fadeTimeout = window.setTimeout(() => setIsFading(true), fadeAfterMs);
		const clearTimeoutId = window.setTimeout(clearNotice, fadeAfterMs + fadeDurationMs);
		return () => {
			window.clearTimeout(fadeTimeout);
			window.clearTimeout(clearTimeoutId);
		};
	}, [
		notice,
		clearNotice,
		fadeAfterMs,
		fadeDurationMs
	]);
	return isFading;
}
_s(useAutoDismissNotice, "lmqng1GcDj1d3lPdAAp1zhQA/e4=");
export default function SmartFocusUI() {
	_s2();
	const [task, setTask] = useState(readSavedTask);
	const [phase, setPhase] = useState("FOCUS");
	const [remainingSeconds, setRemainingSeconds] = useState(DEFAULT_FOCUS_SECONDS);
	const [endTime, setEndTime] = useState(null);
	const [isActive, setActive] = useState(false);
	const [hasStartedSession, setHasStartedSession] = useState(() => {
		try {
			return window.sessionStorage.getItem("project-katchup-session-started") === "true";
		} catch {
			return false;
		}
	});
	const [isLoading, setLoading] = useState(false);
	const [message, setMessage] = useState("");
	const [error, setError] = useState("");
	const [sessionCompleted, setSessionCompleted] = useState(false);
	const [taskRefreshSignal, setTaskRefreshSignal] = useState(0);
	const [isTaskManagerOpen, setTaskManagerOpen] = useState(false);
	const [taskForm, setTaskForm] = useState(EMPTY_TASK_FORM);
	const [isCreatingTask, setCreatingTask] = useState(false);
	const [deletingTaskId, setDeletingTaskId] = useState(null);
	const [taskError, setTaskError] = useState("");
	const [taskNotice, setTaskNotice] = useState("");
	const [taskActionError, setTaskActionError] = useState("");
	const [taskActionNotice, setTaskActionNotice] = useState("");
	const clearMessageNotice = useCallback(() => setMessage(""), []);
	const clearTaskNotice = useCallback(() => setTaskNotice(""), []);
	const clearTaskActionNotice = useCallback(() => setTaskActionNotice(""), []);
	const isMessageFading = useAutoDismissNotice(message, clearMessageNotice);
	const isTaskNoticeFading = useAutoDismissNotice(taskNotice, clearTaskNotice);
	const isTaskActionNoticeFading = useAutoDismissNotice(taskActionNotice, clearTaskActionNotice);
	const chimeRef = useRef(null);
	const completionHandledRef = useRef(false);
	const notificationPermRequestRef = useRef(false);
	const [background, setBackground] = useState(() => {
		try {
			return window.localStorage.getItem("project-katchup-background") || "plain";
		} catch {
			return "plain";
		}
	});
	const updateSessionStarted = useCallback((started) => {
		setHasStartedSession(started);
		try {
			if (started) {
				window.sessionStorage.setItem("project-katchup-session-started", "true");
			} else {
				window.sessionStorage.removeItem("project-katchup-session-started");
			}
		} catch {}
	}, []);
	const applyTimerStatus = useCallback((status) => {
		if (!status) return;
		const nextPhase = status.phase ?? "FOCUS";
		const nextRemaining = Number(status.remainingSeconds);
		setPhase(nextPhase);
		setRemainingSeconds(Number.isFinite(nextRemaining) ? nextRemaining : nextPhase === "SHORT_BREAK" ? SHORT_BREAK_SECONDS : DEFAULT_FOCUS_SECONDS);
		setActive(Boolean(status.isActive));
		setEndTime(status.endTime ? new Date(status.endTime).getTime() : null);
		if (status.isActive) {
			updateSessionStarted(true);
		} else if (Number.isFinite(nextRemaining) && nextRemaining <= 0) {
			updateSessionStarted(false);
			setSessionCompleted(true);
		}
	}, [updateSessionStarted]);
	const refreshTimer = useCallback(async () => {
		const status = await getTimerStatus();
		applyTimerStatus(status);
	}, [applyTimerStatus]);
	useEffect(() => {
		if (typeof window === "undefined" || !("Notification" in window)) return;
		if (Notification.permission !== "default") return;
		if (notificationPermRequestRef.current) return;
		notificationPermRequestRef.current = true;
		try {
			Notification.requestPermission().catch((permissionError) => {
				console.warn("Unable to request notification permission.", permissionError);
			});
		} catch (permissionError) {
			console.warn("Unable to request notification permission.", permissionError);
		}
	}, []);
	const showCompletionNotification = useCallback(() => {
		if (typeof window === "undefined" || !("Notification" in window)) return;
		if (Notification.permission !== "granted") return;
		try {
			const notification = new Notification("Timer Complete", {
				body: task?.title ? `Your session for "${task.title}" is complete.` : "Your timer has finished.",
				tag: "project-katchup-timer-complete"
			});
			notification.onClick = () => {
				window.focus();
				notification.close();
			};
		} catch (notificationError) {
			console.warn("Unable to show the timer completion notification.", notificationError);
		}
	}, [task?.title]);
	useEffect(() => {
		if (typeof Audio === "undefined") return undefined;
		const chime = new Audio(`${import.meta.env.BASE_URL}audio/timer-chime.mp3`);
		chime.preload = "auto";
		chime.volume = .75;
		chimeRef.current = chime;
		return () => {
			chime.pause();
			chime.currentTime = 0;
			chimeRef.current = null;
		};
	}, []);
	const playCompletionChime = useCallback(() => {
		const chime = chimeRef.current;
		if (!chime) return;
		chime.currentTime = 0;
		chime.play().catch((playbackError) => {
			console.warn("Unable to play the timer completion chime.", playbackError);
		});
	}, []);
	useEffect(() => {
		refreshTimer().catch(() => {
			// Default local timer state can still be used if server is down.
		});
	}, [refreshTimer]);
	useEffect(() => {
		if (!isActive || !endTime) return undefined;
		const updateCountdown = () => {
			const nextRemaining = Math.max(0, Math.ceil((endTime - Date.now()) / 1e3));
			setRemainingSeconds(nextRemaining);
			if (nextRemaining === 0 && !completionHandledRef.current) {
				completionHandledRef.current = true;
				setSessionCompleted(true);
				updateSessionStarted(false);
				playCompletionChime();
				showCompletionNotification();
				refreshTimer().catch(() => setActive(false));
			}
		};
		updateCountdown();
		const intervalId = window.setInterval(updateCountdown, 250);
		return () => window.clearInterval(intervalId);
	}, [
		endTime,
		isActive,
		playCompletionChime,
		refreshTimer,
		showCompletionNotification,
		updateSessionStarted
	]);
	const runTimerAction = async (action, onSuccess) => {
		setLoading(true);
		setError("");
		try {
			const response = await action();
			onSuccess?.(response);
			if (response?.endTime) {
				setEndTime(new Date(response.endTime).getTime());
			}
			await refreshTimer();
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Unable to update the timer.");
		} finally {
			setLoading(false);
		}
	};
	const startSession = async () => {
		if (!task || task.id == null) {
			setError("Select a task from the dashboard before starting a session.");
			return;
		}
		if (isActive || hasStartedSession || isLoading) return;
		completionHandledRef.current = false;
		setSessionCompleted(false);
		setLoading(true);
		setMessage("");
		setError("");
		try {
			await resetTimer();
			setPhase("FOCUS");
			setEndTime(null);
			const response = await startTimer({
				taskId: task.id,
				durationSeconds: task.durationSeconds ?? DEFAULT_FOCUS_SECONDS
			});
			updateSessionStarted(true);
			if (response?.endTime) {
				setEndTime(new Date(response.endTime).getTime());
			}
			setMessage(`Session Started: ${task.title}`);
			await refreshTimer();
		} catch (requestError) {
			setError(requestError instanceof Error ? requestError.message : "Session was unable to start.");
		} finally {
			setLoading(false);
		}
	};
	const handleBackgroundChange = (nextBackground) => {
		setBackground(nextBackground);
		try {
			window.localStorage.setItem("project-katchup-background", nextBackground);
		} catch {}
	};
	const handleSelectTask = (selectedTask) => {
		if (hasStartedSession) return;
		setTask(selectedTask);
		try {
			window.sessionStorage.setItem("project-katchup-selected-task", JSON.stringify(selectedTask));
		} catch {}
		setMessage("");
		setError("");
	};
	const handleTasksChanged = useCallback((deletedTaskId = null) => {
		setTaskRefreshSignal((currentSignal) => currentSignal + 1);
		if (deletedTaskId !== null && String(task?.id) === String(deletedTaskId) && !isActive && !hasStartedSession) {
			setTask(null);
			try {
				window.sessionStorage.removeItem("project-katchup-selected-task");
			} catch {}
		}
	}, [
		hasStartedSession,
		isActive,
		task?.id
	]);
	const handleTaskManagerToggle = () => {
		setTaskManagerOpen((isOpen) => !isOpen);
		setTaskNotice("");
		setTaskError("");
	};
	const handleTaskManagerClose = () => setTaskManagerOpen(false);
	const handleTaskFormChange = (field, value) => {
		setTaskForm((currentForm) => ({
			...currentForm,
			[field]: value
		}));
	};
	const handleCreateTask = async (event) => {
		event.preventDefault();
		const title = taskForm.title.trim();
		if (!title) {
			setTaskError("Enter a title for your task.");
			return;
		}
		setCreatingTask(true);
		setTaskError("");
		setTaskNotice("");
		try {
			await createTask({
				title,
				description: taskForm.description.trim() || null,
				due_date: taskForm.dueDate || null
			});
			setTaskForm(EMPTY_TASK_FORM);
			setTaskNotice(`Added "${title}" to your tasks.`);
			setTaskRefreshSignal((currentSignal) => currentSignal + 1);
		} catch (requestError) {
			setTaskError(requestError instanceof Error ? requestError.message : "Unable to create your task.");
		} finally {
			setCreatingTask(false);
		}
	};
	const handleDeleteTask = async (tasktoDelete) => {
		const taskId = tasktoDelete?.id ?? tasktoDelete?.taskId;
		const taskTitle = tasktoDelete?.title ?? tasktoDelete?.name ?? "Untitled task";
		if (taskId == null) {
			setTaskActionError("This task cannot be deleted because it has no task ID.");
			return;
		}
		const confirmed = window.confirm(`Are you sure you want to delete "${taskTitle}"? This will remove it from your active task list.`);
		if (!confirmed) return;
		setDeletingTaskId(taskId);
		setTaskActionError("");
		setTaskActionNotice("");
		try {
			await deleteTask(taskId);
			setTaskActionNotice(`Deleted "${taskTitle}".`);
			handleTasksChanged(taskId);
		} catch (requestError) {
			setTaskActionError(requestError instanceof Error ? requestError.message : "Unable to delete your task.");
		} finally {
			setDeletingTaskId(null);
		}
	};
	const handleResume = () => {
		if (!hasStartedSession || isActive || remainingSeconds <= 0 || isLoading) return;
		completionHandledRef.current = false;
		setSessionCompleted(false);
		return runTimerAction(startTimer);
	};
	const handlePause = () => runTimerAction(pauseTimer);
	const handleStop = () => {
		completionHandledRef.current = true;
		setSessionCompleted(false);
		return runTimerAction(stopTimer, () => updateSessionStarted(true));
	};
	const handleReset = () => {
		completionHandledRef.current = false;
		setSessionCompleted(false);
		return runTimerAction(resetTimer, () => {
			setPhase("FOCUS");
			setRemainingSeconds(DEFAULT_FOCUS_SECONDS);
			setEndTime(null);
			setActive(false);
			updateSessionStarted(false);
		});
	};
	return /* @__PURE__ */ _jsxDEV("main", {
		className: `smart-focus-ui workspace-background-${background}`,
		children: [
			/* @__PURE__ */ _jsxDEV(Dashboard, {
				selectedTask: task,
				taskSelectionDisabled: hasStartedSession,
				onSelectTask: handleSelectTask,
				refreshSignal: taskRefreshSignal,
				onDeleteTask: handleDeleteTask,
				deletingTaskId,
				taskActionError,
				taskActionNotice,
				taskActionNoticeFading: isTaskActionNoticeFading
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 457,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV(SettingsPanel, {
				background,
				onBackgroundChange: handleBackgroundChange,
				isTaskManagerOpen,
				taskForm,
				isCreatingTask,
				taskError,
				taskNotice,
				taskNoticeFading: isTaskNoticeFading,
				onTaskManagerToggle: handleTaskManagerToggle,
				onTaskManagerClose: handleTaskManagerClose,
				onTaskFormChange: handleTaskFormChange,
				onCreateTask: handleCreateTask
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 469,
				columnNumber: 13
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "smart-focus-session-button",
				children: /* @__PURE__ */ _jsxDEV(StartSessionButton, {
					onClick: startSession,
					loading: isLoading,
					disabled: isActive || hasStartedSession || !task
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 485,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 484,
				columnNumber: 13
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "smart-focus-error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 493,
				columnNumber: 17
			}, this),
			message && !error && /* @__PURE__ */ _jsxDEV("div", {
				className: `smart-focus-message auto-dismiss-notice${isMessageFading ? " is-fading" : ""}`,
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 499,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV(PomodoroTimer, {
				task,
				phase,
				remainingSeconds,
				isActive,
				isLoading,
				sessionCompleted,
				error: "",
				onResume: handleResume,
				canResume: hasStartedSession && !isActive && remainingSeconds > 0 && !sessionCompleted,
				onPause: handlePause,
				onStop: handleStop,
				onReset: handleReset
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 504,
				columnNumber: 13
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 456,
		columnNumber: 9
	}, this);
}
_s2(SmartFocusUI, "i5OGCWiAZP6KMrLmBdR/nt8EoLM=", false, function() {
	return [
		useAutoDismissNotice,
		useAutoDismissNotice,
		useAutoDismissNotice
	];
});
_c = SmartFocusUI;
var _c;
$RefreshReg$(_c, "SmartFocusUI");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SmartFocusUI.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/home/ashartz/Project-Katch-Up/frontend/src/components/SmartFocusUI.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsUUFBUSxnQkFBZ0I7QUFFekQsU0FDSSxZQUNBLFlBQ0EsYUFDQSxnQkFDQSxZQUNBLFlBQ0EsWUFDQSxpQkFDRztBQUVQLE9BQU8sd0JBQXdCO0FBQy9CLE9BQU8sZUFBZTtBQUN0QixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLG1CQUFtQjs7OztBQUUxQixNQUFNLHdCQUF3QixLQUFLO0FBQ25DLE1BQU0sc0JBQXNCLElBQUk7QUFDaEMsTUFBTSxrQkFBa0I7Q0FBRSxPQUFPO0NBQUksYUFBYTtDQUFJLFNBQVM7QUFBRztBQUVsRSxTQUFTLGdCQUFnQjtDQUNyQixJQUFJO0VBQ0EsTUFBTSxZQUFZLE9BQU8sYUFBYSxRQUFRLCtCQUErQjtFQUM3RSxPQUFPLFlBQVksS0FBSyxNQUFNLFNBQVMsSUFBSTtDQUMvQyxRQUFRO0VBQ0osT0FBTztDQUNYO0FBQ0o7QUFFQSxTQUFTLHFCQUFxQixRQUFRLGFBQWEsY0FBYyxNQUFNLGlCQUFpQixLQUFLOztDQUN6RixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsS0FBSztDQUU5QyxnQkFBZ0I7RUFDWixJQUFJLENBQUMsUUFBUTtHQUNULFlBQVksS0FBSztHQUNqQixPQUFPO0VBQ1g7RUFFQSxZQUFZLEtBQUs7RUFDakIsTUFBTSxjQUFjLE9BQU8saUJBQWlCLFlBQVksSUFBSSxHQUFHLFdBQVc7RUFDMUUsTUFBTSxpQkFBaUIsT0FBTyxXQUMxQixhQUNBLGNBQWMsY0FDbEI7RUFFQSxhQUFhO0dBQ1QsT0FBTyxhQUFhLFdBQVc7R0FDL0IsT0FBTyxhQUFhLGNBQWM7RUFDdEM7Q0FDSixHQUFHO0VBQUM7RUFBUTtFQUFhO0VBQWE7Q0FBYyxDQUFDO0NBRXJELE9BQU87QUFDWDs7QUFFQSxlQUFlLFNBQVMsZUFBZTs7Q0FDbkMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLGFBQWE7Q0FDOUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLE9BQU87Q0FDMUMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxxQkFBcUI7Q0FDOUUsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsYUFBYSxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsZUFBZTtFQUM3RCxJQUFJO0dBQ0EsT0FBTyxPQUFPLGVBQWUsUUFBUSxpQ0FBaUMsTUFBTTtFQUNoRixRQUFRO0dBQ0osT0FBTztFQUNYO0NBQ0osQ0FBQztDQUNELE1BQU0sQ0FBQyxXQUFXLGNBQWMsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLENBQUM7Q0FDNUQsTUFBTSxDQUFDLG1CQUFtQixzQkFBc0IsU0FBUyxLQUFLO0NBQzlELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxlQUFlO0NBQ3hELE1BQU0sQ0FBQyxnQkFBZ0IsbUJBQW1CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLElBQUk7Q0FDekQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEVBQUU7Q0FDM0QsTUFBTSxxQkFBcUIsa0JBQWtCLFdBQVcsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUMvRCxNQUFNLGtCQUFrQixrQkFBa0IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0NBQy9ELE1BQU0sd0JBQXdCLGtCQUFrQixvQkFBb0IsRUFBRSxHQUFHLENBQUMsQ0FBQztDQUMzRSxNQUFNLGtCQUFrQixxQkFBcUIsU0FBUyxrQkFBa0I7Q0FDeEUsTUFBTSxxQkFBcUIscUJBQXFCLFlBQVksZUFBZTtDQUMzRSxNQUFNLDJCQUEyQixxQkFBcUIsa0JBQWtCLHFCQUFxQjtDQUM3RixNQUFNLFdBQVcsT0FBTyxJQUFJO0NBQzVCLE1BQU0sdUJBQXVCLE9BQU8sS0FBSztDQUN6QyxNQUFNLDZCQUE2QixPQUFPLEtBQUs7Q0FDL0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLGVBQWU7RUFDL0MsSUFBSTtHQUNBLE9BQU8sT0FBTyxhQUFhLFFBQVEsNEJBQTRCLEtBQUs7RUFDeEUsUUFBUTtHQUNKLE9BQU87RUFDWDtDQUNKLENBQUM7Q0FFRCxNQUFNLHVCQUF1QixhQUFhLFlBQVk7RUFDbEQscUJBQXFCLE9BQU87RUFDNUIsSUFBSTtHQUNBLElBQUksU0FBUztJQUNULE9BQU8sZUFBZSxRQUFRLG1DQUFtQyxNQUFNO0dBQzNFLE9BQU87SUFDSCxPQUFPLGVBQWUsV0FBVyxpQ0FBaUM7R0FDdEU7RUFDSixRQUFRLENBRVI7Q0FDSixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sbUJBQW1CLGFBQWEsV0FBVztFQUM3QyxJQUFJLENBQUMsUUFBUTtFQUViLE1BQU0sWUFBWSxPQUFPLFNBQVM7RUFDbEMsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLGdCQUFnQjtFQUVwRCxTQUFTLFNBQVM7RUFDbEIsb0JBQ0ksT0FBTyxTQUFTLGFBQWEsSUFDdkIsZ0JBQ0EsY0FBYyxnQkFDVixzQkFDQSxxQkFDZDtFQUVBLFVBQVUsUUFBUSxPQUFPLFFBQVEsQ0FBQztFQUNsQyxXQUFXLE9BQU8sVUFBVSxJQUFJLEtBQUssT0FBTyxPQUFPLENBQUMsQ0FBQyxRQUFRLElBQUksSUFBSTtFQUVyRSxJQUFJLE9BQU8sVUFBVTtHQUNqQixxQkFBcUIsSUFBSTtFQUM3QixPQUFPLElBQUksT0FBTyxTQUFTLGFBQWEsS0FBSyxpQkFBaUIsR0FBRztHQUM3RCxxQkFBcUIsS0FBSztHQUMxQixvQkFBb0IsSUFBSTtFQUM1QjtDQUNKLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztDQUV6QixNQUFNLGVBQWUsWUFBWSxZQUFZO0VBQ3pDLE1BQU0sU0FBUyxNQUFNLGVBQWU7RUFDcEMsaUJBQWlCLE1BQU07Q0FDM0IsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0NBRXJCLGdCQUFnQjtFQUNaLElBQUksT0FBTyxXQUFXLGVBQWUsRUFBRSxrQkFBa0IsU0FBUztFQUNsRSxJQUFJLGFBQWEsZUFBZSxXQUFXO0VBQzNDLElBQUksMkJBQTJCLFNBQVM7RUFFeEMsMkJBQTJCLFVBQVU7RUFFckMsSUFBSTtHQUNBLGFBQWEsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLG9CQUFvQjtJQUN4RCxRQUFRLEtBQUssOENBQThDLGVBQWU7R0FDOUUsQ0FBQztFQUNMLFNBQVMsaUJBQWlCO0dBQ3RCLFFBQVEsS0FBSyw4Q0FBOEMsZUFBZTtFQUM5RTtDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSw2QkFBNkIsa0JBQWtCO0VBQ2pELElBQUksT0FBTyxXQUFXLGVBQWUsRUFBRSxrQkFBa0IsU0FBUztFQUNsRSxJQUFJLGFBQWEsZUFBZSxXQUFXO0VBRTNDLElBQUk7R0FDQSxNQUFNLGVBQWUsSUFBSSxhQUFhLGtCQUFrQjtJQUNwRCxNQUFNLE1BQU0sUUFDTixxQkFBcUIsS0FBSyxNQUFNLGtCQUNoQztJQUNOLEtBQUs7R0FDVCxDQUFDO0dBRUQsYUFBYSxnQkFBZ0I7SUFDekIsT0FBTyxNQUFNO0lBQ2IsYUFBYSxNQUFNO0dBQ3ZCO0VBQ0osU0FBUyxtQkFBbUI7R0FDeEIsUUFBUSxLQUFLLHFEQUFxRCxpQkFBaUI7RUFDdkY7Q0FDSixHQUFHLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FFaEIsZ0JBQWdCO0VBQ1osSUFBSSxPQUFPLFVBQVUsYUFBYSxPQUFPO0VBRXpDLE1BQU0sUUFBUSxJQUFJLE1BQU0sR0FBRyxZQUFZLElBQUksU0FBUyxzQkFBc0I7RUFDMUUsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sU0FBUztFQUNmLFNBQVMsVUFBVTtFQUVuQixhQUFhO0dBQ1QsTUFBTSxNQUFNO0dBQ1osTUFBTSxjQUFjO0dBQ3BCLFNBQVMsVUFBVTtFQUN2QjtDQUNKLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxzQkFBc0Isa0JBQWtCO0VBQzFDLE1BQU0sUUFBUSxTQUFTO0VBQ3ZCLElBQUksQ0FBQyxPQUFPO0VBRVosTUFBTSxjQUFjO0VBQ3BCLE1BQU0sS0FBSyxDQUFDLENBQUMsT0FBTyxrQkFBa0I7R0FDbEMsUUFBUSxLQUFLLDhDQUE4QyxhQUFhO0VBQzVFLENBQUM7Q0FDTCxHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUNaLGFBQWEsQ0FBQyxDQUFDLFlBQVk7O0VBRTNCLENBQUM7Q0FDTCxHQUFHLENBQUMsWUFBWSxDQUFDO0NBRWpCLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxPQUFPO0VBRWxDLE1BQU0sd0JBQXdCO0dBQzFCLE1BQU0sZ0JBQWdCLEtBQUssSUFDdkIsR0FDQSxLQUFLLE1BQU0sVUFBVSxLQUFLLElBQUksS0FBSyxHQUFJLENBQzNDO0dBRUEsb0JBQW9CLGFBQWE7R0FFakMsSUFBSSxrQkFBa0IsS0FBSyxDQUFDLHFCQUFxQixTQUFTO0lBQ3RELHFCQUFxQixVQUFVO0lBQy9CLG9CQUFvQixJQUFJO0lBQ3hCLHFCQUFxQixLQUFLO0lBQzFCLG9CQUFvQjtJQUNwQiwyQkFBMkI7SUFDM0IsYUFBYSxDQUFDLENBQUMsWUFBWSxVQUFVLEtBQUssQ0FBQztHQUMvQztFQUNKO0VBRUEsZ0JBQWdCO0VBQ2hCLE1BQU0sYUFBYSxPQUFPLFlBQVksaUJBQWlCLEdBQUc7RUFFMUQsYUFBYSxPQUFPLGNBQWMsVUFBVTtDQUNoRCxHQUFHO0VBQUM7RUFBUztFQUFVO0VBQXFCO0VBQWM7RUFBNEI7Q0FBb0IsQ0FBQztDQUUzRyxNQUFNLGlCQUFpQixPQUFPLFFBQVEsY0FBYztFQUNoRCxXQUFXLElBQUk7RUFDZixTQUFTLEVBQUU7RUFFWCxJQUFJO0dBQ0EsTUFBTSxXQUFXLE1BQU0sT0FBTztHQUM5QixZQUFZLFFBQVE7R0FFcEIsSUFBSSxVQUFVLFNBQVM7SUFDbkIsV0FBVyxJQUFJLEtBQUssU0FBUyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUM7R0FDbkQ7R0FFQSxNQUFNLGFBQWE7RUFDdkIsU0FBUyxjQUFjO0dBQ25CLFNBQ0ksd0JBQXdCLFFBQ2xCLGFBQWEsVUFDYiw2QkFDVjtFQUNKLFVBQVU7R0FDTixXQUFXLEtBQUs7RUFDcEI7Q0FDSjtDQUVBLE1BQU0sZUFBZSxZQUFZO0VBQzdCLElBQUksQ0FBQyxRQUFRLEtBQUssTUFBTSxNQUFNO0dBQzFCLFNBQVMsNkRBQTZEO0dBQ3RFO0VBQ0o7RUFFQSxJQUFJLFlBQVkscUJBQXFCLFdBQVc7RUFFaEQscUJBQXFCLFVBQVU7RUFDL0Isb0JBQW9CLEtBQUs7RUFDekIsV0FBVyxJQUFJO0VBQ2YsV0FBVyxFQUFFO0VBQ2IsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNBLE1BQU0sV0FBVztHQUNqQixTQUFTLE9BQU87R0FDaEIsV0FBVyxJQUFJO0dBRWYsTUFBTSxXQUFXLE1BQU0sV0FBVztJQUM5QixRQUFRLEtBQUs7SUFDYixpQkFBaUIsS0FBSyxtQkFBbUI7R0FDN0MsQ0FBQztHQUVELHFCQUFxQixJQUFJO0dBQ3pCLElBQUksVUFBVSxTQUFTO0lBQ25CLFdBQVcsSUFBSSxLQUFLLFNBQVMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDO0dBQ25EO0dBRUEsV0FBVyxvQkFBb0IsS0FBSyxPQUFPO0dBQzNDLE1BQU0sYUFBYTtFQUN2QixTQUFTLGNBQWM7R0FDbkIsU0FDSSx3QkFBd0IsUUFDdEIsYUFBYSxVQUNiLDhCQUNOO0VBQ0osVUFBVTtHQUNOLFdBQVcsS0FBSztFQUNwQjtDQUNKO0NBRUEsTUFBTSwwQkFBMEIsbUJBQW1CO0VBQy9DLGNBQWMsY0FBYztFQUM1QixJQUFJO0dBQ0EsT0FBTyxhQUFhLFFBQVEsOEJBQThCLGNBQWM7RUFDNUUsUUFBUSxDQUVSO0NBQ0o7Q0FFQSxNQUFNLG9CQUFvQixpQkFBaUI7RUFDdkMsSUFBSSxtQkFBbUI7RUFFdkIsUUFBUSxZQUFZO0VBRXBCLElBQUk7R0FDQSxPQUFPLGVBQWUsUUFBUSxpQ0FBaUMsS0FBSyxVQUFVLFlBQVksQ0FBQztFQUMvRixRQUFRLENBRVI7RUFFQSxXQUFXLEVBQUU7RUFDYixTQUFTLEVBQUU7Q0FDZjtDQUVBLE1BQU0scUJBQXFCLGFBQWEsZ0JBQWdCLFNBQVM7RUFDN0Qsc0JBQXNCLGtCQUFrQixnQkFBZ0IsQ0FBQztFQUV6RCxJQUNJLGtCQUFrQixRQUNsQixPQUFPLE1BQU0sRUFBRSxNQUFNLE9BQU8sYUFBYSxLQUN6QyxDQUFDLFlBQ0QsQ0FBQyxtQkFDSDtHQUNFLFFBQVEsSUFBSTtHQUNaLElBQUk7SUFDQSxPQUFPLGVBQWUsV0FBVywrQkFBK0I7R0FDcEUsUUFBUSxDQUVSO0VBQ0o7Q0FDSixHQUFHO0VBQUM7RUFBbUI7RUFBVSxNQUFNO0NBQUUsQ0FBQztDQUUxQyxNQUFNLGdDQUFnQztFQUNsQyxvQkFBb0IsV0FBVyxDQUFDLE1BQU07RUFDdEMsY0FBYyxFQUFFO0VBQ2hCLGFBQWEsRUFBRTtDQUNuQjtDQUVBLE1BQU0sK0JBQStCLG1CQUFtQixLQUFLO0NBRTdELE1BQU0sd0JBQXdCLE9BQU8sVUFBVTtFQUMzQyxhQUFhLGlCQUFpQjtHQUFFLEdBQUc7SUFBYyxRQUFRO0VBQU0sRUFBRTtDQUNyRTtDQUVBLE1BQU0sbUJBQW1CLE9BQU8sVUFBVTtFQUN0QyxNQUFNLGVBQWU7RUFFckIsTUFBTSxRQUFRLFNBQVMsTUFBTSxLQUFLO0VBQ2xDLElBQUksQ0FBQyxPQUFPO0dBQ1IsYUFBYSw4QkFBOEI7R0FDM0M7RUFDSjtFQUVBLGdCQUFnQixJQUFJO0VBQ3BCLGFBQWEsRUFBRTtFQUNmLGNBQWMsRUFBRTtFQUVoQixJQUFJO0dBQ0EsTUFBTSxXQUFXO0lBQ2I7SUFDQSxhQUFhLFNBQVMsWUFBWSxLQUFLLEtBQUs7SUFDNUMsVUFBVSxTQUFTLFdBQVc7R0FDbEMsQ0FBQztHQUVELFlBQVksZUFBZTtHQUMzQixjQUFjLFVBQVUsTUFBTSxpQkFBaUI7R0FDL0Msc0JBQXNCLGtCQUFrQixnQkFBZ0IsQ0FBQztFQUM3RCxTQUFTLGNBQWM7R0FDbkIsYUFDSSx3QkFBd0IsUUFDbEIsYUFBYSxVQUNiLDZCQUNWO0VBQ0osVUFBVTtHQUNOLGdCQUFnQixLQUFLO0VBQ3pCO0NBQ0o7Q0FFQSxNQUFNLG1CQUFtQixPQUFPLGlCQUFpQjtFQUM3QyxNQUFNLFNBQVMsY0FBYyxNQUFNLGNBQWM7RUFDakQsTUFBTSxZQUFZLGNBQWMsU0FBUyxjQUFjLFFBQVE7RUFFL0QsSUFBSSxVQUFVLE1BQU07R0FDaEIsbUJBQW1CLHdEQUF3RDtHQUMzRTtFQUNKO0VBRUEsTUFBTSxZQUFZLE9BQU8sUUFDckIsb0NBQW9DLFVBQVUsbURBQ2xEO0VBRUEsSUFBSSxDQUFDLFdBQVc7RUFFaEIsa0JBQWtCLE1BQU07RUFDeEIsbUJBQW1CLEVBQUU7RUFDckIsb0JBQW9CLEVBQUU7RUFFdEIsSUFBSTtHQUNBLE1BQU0sV0FBVyxNQUFNO0dBQ3ZCLG9CQUFvQixZQUFZLFVBQVUsR0FBRztHQUM3QyxtQkFBbUIsTUFBTTtFQUM3QixTQUFTLGNBQWM7R0FDbkIsbUJBQ0ksd0JBQXdCLFFBQ3RCLGFBQWEsVUFDYiw2QkFDTjtFQUNKLFVBQVU7R0FDTixrQkFBa0IsSUFBSTtFQUMxQjtDQUNKO0NBRUEsTUFBTSxxQkFBcUI7RUFDdkIsSUFBSSxDQUFDLHFCQUFxQixZQUFZLG9CQUFvQixLQUFLLFdBQVc7RUFFMUUscUJBQXFCLFVBQVU7RUFDL0Isb0JBQW9CLEtBQUs7RUFDekIsT0FBTyxlQUFlLFVBQVU7Q0FDcEM7Q0FFQSxNQUFNLG9CQUFvQixlQUFlLFVBQVU7Q0FFbkQsTUFBTSxtQkFBbUI7RUFDckIscUJBQXFCLFVBQVU7RUFDL0Isb0JBQW9CLEtBQUs7RUFDekIsT0FBTyxlQUFlLGlCQUFpQixxQkFBcUIsSUFBSSxDQUFDO0NBQ3JFO0NBRUEsTUFBTSxvQkFBb0I7RUFDdEIscUJBQXFCLFVBQVU7RUFDL0Isb0JBQW9CLEtBQUs7RUFDekIsT0FBTyxlQUFlLGtCQUFrQjtHQUNwQyxTQUFTLE9BQU87R0FDaEIsb0JBQW9CLHFCQUFxQjtHQUN6QyxXQUFXLElBQUk7R0FDZixVQUFVLEtBQUs7R0FDZixxQkFBcUIsS0FBSztFQUM5QixDQUFDO0NBQ0w7Q0FFQSxPQUNJLHdCQUFDLFFBQUQ7RUFBTSxXQUFXLHVDQUF1QztZQUF4RDtHQUNJLHdCQUFDLFdBQUQ7SUFDSSxjQUFjO0lBQ2QsdUJBQXVCO0lBQ3ZCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsY0FBYztJQUNFO0lBQ0M7SUFDQztJQUNsQix3QkFBd0I7R0FDM0I7Ozs7O0dBRUQsd0JBQUMsZUFBRDtJQUNnQjtJQUNaLG9CQUFvQjtJQUNEO0lBQ1Q7SUFDTTtJQUNMO0lBQ0M7SUFDWixrQkFBa0I7SUFDbEIscUJBQXFCO0lBQ3JCLG9CQUFvQjtJQUNwQixrQkFBa0I7SUFDbEIsY0FBYztHQUNqQjs7Ozs7R0FFRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNYLHdCQUFDLG9CQUFEO0tBQ0ksU0FBUztLQUNULFNBQVM7S0FDVCxVQUFVLFlBQVkscUJBQXFCLENBQUM7SUFDL0M7Ozs7O0dBQ0E7Ozs7O0dBRUosU0FDRyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFvQixNQUFLO2NBQ25DO0dBQ0E7Ozs7O0dBR1IsV0FBVyxDQUFDLFNBQ1Qsd0JBQUMsT0FBRDtJQUFLLFdBQVcsMENBQTBDLGtCQUFrQixlQUFlO0lBQU0sTUFBSztjQUNqRztHQUNBOzs7OztHQUdULHdCQUFDLGVBQUQ7SUFDVTtJQUNDO0lBQ1c7SUFDUjtJQUNDO0lBQ087SUFDbEIsT0FBTztJQUNQLFVBQVU7SUFDVixXQUFXLHFCQUFxQixDQUFDLFlBQVksbUJBQW1CLEtBQUssQ0FBQztJQUN0RSxTQUFTO0lBQ1QsUUFBUTtJQUNSLFNBQVM7R0FDWjs7Ozs7RUFFQzs7Ozs7O0FBRWQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU21hcnRGb2N1c1VJLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuXG5pbXBvcnQge1xuICAgIGNyZWF0ZVRhc2ssXG4gICAgZGVsZXRlVGFzayxcbiAgICBnZXROZXh0VGFzayxcbiAgICBnZXRUaW1lclN0YXR1cyxcbiAgICBwYXVzZVRpbWVyLFxuICAgIHJlc2V0VGltZXIsXG4gICAgc3RhcnRUaW1lcixcbiAgICBzdG9wVGltZXIsXG59IGZyb20gJy4uL3NlcnZpY2VzL2FwaUNsaWVudC5qcyc7XG5cbmltcG9ydCBTdGFydFNlc3Npb25CdXR0b24gZnJvbSAnLi9TdGFydFNlc3Npb25CdXR0b24uanN4JztcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9EYXNoYm9hcmQuanN4JztcbmltcG9ydCBQb21vZG9yb1RpbWVyIGZyb20gJy4vUG9tb2Rvcm9UaW1lci5qc3gnO1xuaW1wb3J0IFNldHRpbmdzUGFuZWwgZnJvbSAnLi9TZXR0aW5nc1BhbmVsLmpzeCc7XG5cbmNvbnN0IERFRkFVTFRfRk9DVVNfU0VDT05EUyA9IDIwICogNjA7XG5jb25zdCBTSE9SVF9CUkVBS19TRUNPTkRTID0gNSAqIDYwO1xuY29uc3QgRU1QVFlfVEFTS19GT1JNID0geyB0aXRsZTogJycsIGRlc2NyaXB0aW9uOiAnJywgZHVlRGF0ZTogJycgfTtcblxuZnVuY3Rpb24gcmVhZFNhdmVkVGFzaygpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBzYXZlZFRhc2sgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZWxlY3RlZC10YXNrJyk7XG4gICAgICAgIHJldHVybiBzYXZlZFRhc2sgPyBKU09OLnBhcnNlKHNhdmVkVGFzaykgOiBudWxsO1xuICAgIH0gY2F0Y2gge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHVzZUF1dG9EaXNtaXNzTm90aWNlKG5vdGljZSwgY2xlYXJOb3RpY2UsIGZhZGVBZnRlck1zID0gMzUwMCwgZmFkZUR1cmF0aW9uTXMgPSA0NTApIHtcbiAgICBjb25zdCBbaXNGYWRpbmcsIHNldElzRmFkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghbm90aWNlKSB7XG4gICAgICAgICAgICBzZXRJc0ZhZGluZyhmYWxzZSk7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG5cbiAgICAgICAgc2V0SXNGYWRpbmcoZmFsc2UpO1xuICAgICAgICBjb25zdCBmYWRlVGltZW91dCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHNldElzRmFkaW5nKHRydWUpLCBmYWRlQWZ0ZXJNcyk7XG4gICAgICAgIGNvbnN0IGNsZWFyVGltZW91dElkID0gd2luZG93LnNldFRpbWVvdXQoXG4gICAgICAgICAgICBjbGVhck5vdGljZSxcbiAgICAgICAgICAgIGZhZGVBZnRlck1zICsgZmFkZUR1cmF0aW9uTXMsXG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoZmFkZVRpbWVvdXQpO1xuICAgICAgICAgICAgd2luZG93LmNsZWFyVGltZW91dChjbGVhclRpbWVvdXRJZCk7XG4gICAgICAgIH07XG4gICAgfSwgW25vdGljZSwgY2xlYXJOb3RpY2UsIGZhZGVBZnRlck1zLCBmYWRlRHVyYXRpb25Nc10pO1xuXG4gICAgcmV0dXJuIGlzRmFkaW5nO1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTbWFydEZvY3VzVUkoKSB7XG4gICAgY29uc3QgW3Rhc2ssIHNldFRhc2tdID0gdXNlU3RhdGUocmVhZFNhdmVkVGFzayk7XG4gICAgY29uc3QgW3BoYXNlLCBzZXRQaGFzZV0gPSB1c2VTdGF0ZSgnRk9DVVMnKTtcbiAgICBjb25zdCBbcmVtYWluaW5nU2Vjb25kcywgc2V0UmVtYWluaW5nU2Vjb25kc10gPSB1c2VTdGF0ZShERUZBVUxUX0ZPQ1VTX1NFQ09ORFMpO1xuICAgIGNvbnN0IFtlbmRUaW1lLCBzZXRFbmRUaW1lXSA9IHVzZVN0YXRlKG51bGwpO1xuICAgIGNvbnN0IFtpc0FjdGl2ZSwgc2V0QWN0aXZlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbaGFzU3RhcnRlZFNlc3Npb24sIHNldEhhc1N0YXJ0ZWRTZXNzaW9uXSA9IHVzZVN0YXRlKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiB3aW5kb3cuc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbSgncHJvamVjdC1rYXRjaHVwLXNlc3Npb24tc3RhcnRlZCcpID09PSAndHJ1ZSc7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgW2lzTG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICAgIGNvbnN0IFtzZXNzaW9uQ29tcGxldGVkLCBzZXRTZXNzaW9uQ29tcGxldGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdGFza1JlZnJlc2hTaWduYWwsIHNldFRhc2tSZWZyZXNoU2lnbmFsXSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IFtpc1Rhc2tNYW5hZ2VyT3Blbiwgc2V0VGFza01hbmFnZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCBbdGFza0Zvcm0sIHNldFRhc2tGb3JtXSA9IHVzZVN0YXRlKEVNUFRZX1RBU0tfRk9STSk7XG4gICAgY29uc3QgW2lzQ3JlYXRpbmdUYXNrLCBzZXRDcmVhdGluZ1Rhc2tdID0gdXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IFtkZWxldGluZ1Rhc2tJZCwgc2V0RGVsZXRpbmdUYXNrSWRdID0gdXNlU3RhdGUobnVsbCk7XG4gICAgY29uc3QgW3Rhc2tFcnJvciwgc2V0VGFza0Vycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbdGFza05vdGljZSwgc2V0VGFza05vdGljZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgW3Rhc2tBY3Rpb25FcnJvciwgc2V0VGFza0FjdGlvbkVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgICBjb25zdCBbdGFza0FjdGlvbk5vdGljZSwgc2V0VGFza0FjdGlvbk5vdGljZV0gPSB1c2VTdGF0ZSgnJyk7XG4gICAgY29uc3QgY2xlYXJNZXNzYWdlTm90aWNlID0gdXNlQ2FsbGJhY2soKCkgPT4gc2V0TWVzc2FnZSgnJyksIFtdKTtcbiAgICBjb25zdCBjbGVhclRhc2tOb3RpY2UgPSB1c2VDYWxsYmFjaygoKSA9PiBzZXRUYXNrTm90aWNlKCcnKSwgW10pO1xuICAgIGNvbnN0IGNsZWFyVGFza0FjdGlvbk5vdGljZSA9IHVzZUNhbGxiYWNrKCgpID0+IHNldFRhc2tBY3Rpb25Ob3RpY2UoJycpLCBbXSk7XG4gICAgY29uc3QgaXNNZXNzYWdlRmFkaW5nID0gdXNlQXV0b0Rpc21pc3NOb3RpY2UobWVzc2FnZSwgY2xlYXJNZXNzYWdlTm90aWNlKTtcbiAgICBjb25zdCBpc1Rhc2tOb3RpY2VGYWRpbmcgPSB1c2VBdXRvRGlzbWlzc05vdGljZSh0YXNrTm90aWNlLCBjbGVhclRhc2tOb3RpY2UpO1xuICAgIGNvbnN0IGlzVGFza0FjdGlvbk5vdGljZUZhZGluZyA9IHVzZUF1dG9EaXNtaXNzTm90aWNlKHRhc2tBY3Rpb25Ob3RpY2UsIGNsZWFyVGFza0FjdGlvbk5vdGljZSk7XG4gICAgY29uc3QgY2hpbWVSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgY29uc3QgY29tcGxldGlvbkhhbmRsZWRSZWYgPSB1c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IG5vdGlmaWNhdGlvblBlcm1SZXF1ZXN0UmVmID0gdXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBbYmFja2dyb3VuZCwgc2V0QmFja2dyb3VuZF0gPSB1c2VTdGF0ZSgoKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXR1cm4gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdwcm9qZWN0LWthdGNodXAtYmFja2dyb3VuZCcpIHx8ICdwbGFpbic7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgcmV0dXJuICdwbGFpbic7XG4gICAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IHVwZGF0ZVNlc3Npb25TdGFydGVkID0gdXNlQ2FsbGJhY2soKHN0YXJ0ZWQpID0+IHtcbiAgICAgICAgc2V0SGFzU3RhcnRlZFNlc3Npb24oc3RhcnRlZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoc3RhcnRlZCkge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdwcm9qZWN0LWthdGNodXAtc2Vzc2lvbi1zdGFydGVkJywgJ3RydWUnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZXNzaW9uLXN0YXJ0ZWQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAvLyBUaW1lciBjb250cm9scyB3aWxsIHN0aWxsIHdvcmsgd2hlbiBicm93c2VyIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGUuXG4gICAgICAgIH1cbiAgICB9LCBbXSk7XG5cbiAgICBjb25zdCBhcHBseVRpbWVyU3RhdHVzID0gdXNlQ2FsbGJhY2soKHN0YXR1cykgPT4ge1xuICAgICAgICBpZiAoIXN0YXR1cykgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IG5leHRQaGFzZSA9IHN0YXR1cy5waGFzZSA/PyAnRk9DVVMnO1xuICAgICAgICBjb25zdCBuZXh0UmVtYWluaW5nID0gTnVtYmVyKHN0YXR1cy5yZW1haW5pbmdTZWNvbmRzKTtcblxuICAgICAgICBzZXRQaGFzZShuZXh0UGhhc2UpO1xuICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKFxuICAgICAgICAgICAgTnVtYmVyLmlzRmluaXRlKG5leHRSZW1haW5pbmcpXG4gICAgICAgICAgICAgICAgPyBuZXh0UmVtYWluaW5nXG4gICAgICAgICAgICAgICAgOiBuZXh0UGhhc2UgPT09ICdTSE9SVF9CUkVBSydcbiAgICAgICAgICAgICAgICAgICAgPyBTSE9SVF9CUkVBS19TRUNPTkRTXG4gICAgICAgICAgICAgICAgICAgIDogREVGQVVMVF9GT0NVU19TRUNPTkRTLFxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgc2V0QWN0aXZlKEJvb2xlYW4oc3RhdHVzLmlzQWN0aXZlKSk7XG4gICAgICAgIHNldEVuZFRpbWUoc3RhdHVzLmVuZFRpbWUgPyBuZXcgRGF0ZShzdGF0dXMuZW5kVGltZSkuZ2V0VGltZSgpIDogbnVsbCk7XG5cbiAgICAgICAgaWYgKHN0YXR1cy5pc0FjdGl2ZSkge1xuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQodHJ1ZSk7XG4gICAgICAgIH0gZWxzZSBpZiAoTnVtYmVyLmlzRmluaXRlKG5leHRSZW1haW5pbmcpICYmIG5leHRSZW1haW5pbmcgPD0gMCkge1xuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQoZmFsc2UpO1xuICAgICAgICAgICAgc2V0U2Vzc2lvbkNvbXBsZXRlZCh0cnVlKTtcbiAgICAgICAgfVxuICAgIH0sIFt1cGRhdGVTZXNzaW9uU3RhcnRlZF0pO1xuXG4gICAgY29uc3QgcmVmcmVzaFRpbWVyID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0dXMgPSBhd2FpdCBnZXRUaW1lclN0YXR1cygpO1xuICAgICAgICBhcHBseVRpbWVyU3RhdHVzKHN0YXR1cyk7XG4gICAgfSwgW2FwcGx5VGltZXJTdGF0dXNdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyB8fCAhKCdOb3RpZmljYXRpb24nIGluIHdpbmRvdykpIHJldHVybjtcbiAgICAgICAgaWYgKE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uICE9PSAnZGVmYXVsdCcpIHJldHVybjtcbiAgICAgICAgaWYgKG5vdGlmaWNhdGlvblBlcm1SZXF1ZXN0UmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgICAgICBub3RpZmljYXRpb25QZXJtUmVxdWVzdFJlZi5jdXJyZW50ID0gdHJ1ZTtcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgTm90aWZpY2F0aW9uLnJlcXVlc3RQZXJtaXNzaW9uKCkuY2F0Y2goKHBlcm1pc3Npb25FcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIHJlcXVlc3Qgbm90aWZpY2F0aW9uIHBlcm1pc3Npb24uJywgcGVybWlzc2lvbkVycm9yKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChwZXJtaXNzaW9uRXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignVW5hYmxlIHRvIHJlcXVlc3Qgbm90aWZpY2F0aW9uIHBlcm1pc3Npb24uJywgcGVybWlzc2lvbkVycm9yKTtcbiAgICAgICAgfVxuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IHNob3dDb21wbGV0aW9uTm90aWZpY2F0aW9uID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgfHwgISgnTm90aWZpY2F0aW9uJyBpbiB3aW5kb3cpKSByZXR1cm47XG4gICAgICAgIGlmIChOb3RpZmljYXRpb24ucGVybWlzc2lvbiAhPT0gJ2dyYW50ZWQnKSByZXR1cm47XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG5vdGlmaWNhdGlvbiA9IG5ldyBOb3RpZmljYXRpb24oJ1RpbWVyIENvbXBsZXRlJywge1xuICAgICAgICAgICAgICAgIGJvZHk6IHRhc2s/LnRpdGxlXG4gICAgICAgICAgICAgICAgICAgID8gYFlvdXIgc2Vzc2lvbiBmb3IgXCIke3Rhc2sudGl0bGV9XCIgaXMgY29tcGxldGUuYFxuICAgICAgICAgICAgICAgICAgICA6ICdZb3VyIHRpbWVyIGhhcyBmaW5pc2hlZC4nLFxuICAgICAgICAgICAgICAgIHRhZzogJ3Byb2plY3Qta2F0Y2h1cC10aW1lci1jb21wbGV0ZScsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgbm90aWZpY2F0aW9uLm9uQ2xpY2sgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgd2luZG93LmZvY3VzKCk7XG4gICAgICAgICAgICAgICAgbm90aWZpY2F0aW9uLmNsb3NlKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChub3RpZmljYXRpb25FcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdVbmFibGUgdG8gc2hvdyB0aGUgdGltZXIgY29tcGxldGlvbiBub3RpZmljYXRpb24uJywgbm90aWZpY2F0aW9uRXJyb3IpO1xuICAgICAgICB9XG4gICAgfSwgW3Rhc2s/LnRpdGxlXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIEF1ZGlvID09PSAndW5kZWZpbmVkJykgcmV0dXJuIHVuZGVmaW5lZDtcblxuICAgICAgICBjb25zdCBjaGltZSA9IG5ldyBBdWRpbyhgJHtpbXBvcnQubWV0YS5lbnYuQkFTRV9VUkx9YXVkaW8vdGltZXItY2hpbWUubXAzYCk7XG4gICAgICAgIGNoaW1lLnByZWxvYWQgPSAnYXV0byc7XG4gICAgICAgIGNoaW1lLnZvbHVtZSA9IDAuNzU7XG4gICAgICAgIGNoaW1lUmVmLmN1cnJlbnQgPSBjaGltZTtcblxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY2hpbWUucGF1c2UoKTtcbiAgICAgICAgICAgIGNoaW1lLmN1cnJlbnRUaW1lID0gMDtcbiAgICAgICAgICAgIGNoaW1lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9O1xuICAgIH0sIFtdKTtcblxuICAgIGNvbnN0IHBsYXlDb21wbGV0aW9uQ2hpbWUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNoaW1lID0gY2hpbWVSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFjaGltZSkgcmV0dXJuO1xuXG4gICAgICAgIGNoaW1lLmN1cnJlbnRUaW1lID0gMDtcbiAgICAgICAgY2hpbWUucGxheSgpLmNhdGNoKChwbGF5YmFja0Vycm9yKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oJ1VuYWJsZSB0byBwbGF5IHRoZSB0aW1lciBjb21wbGV0aW9uIGNoaW1lLicsIHBsYXliYWNrRXJyb3IpO1xuICAgICAgICB9KTtcbiAgICB9LCBbXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZWZyZXNoVGltZXIoKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAvLyBEZWZhdWx0IGxvY2FsIHRpbWVyIHN0YXRlIGNhbiBzdGlsbCBiZSB1c2VkIGlmIHNlcnZlciBpcyBkb3duLlxuICAgICAgICB9KTtcbiAgICB9LCBbcmVmcmVzaFRpbWVyXSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWlzQWN0aXZlIHx8ICFlbmRUaW1lKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgICAgIGNvbnN0IHVwZGF0ZUNvdW50ZG93biA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRSZW1haW5pbmcgPSBNYXRoLm1heChcbiAgICAgICAgICAgICAgICAwLFxuICAgICAgICAgICAgICAgIE1hdGguY2VpbCgoZW5kVGltZSAtIERhdGUubm93KCkpIC8gMTAwMCksXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKG5leHRSZW1haW5pbmcpO1xuXG4gICAgICAgICAgICBpZiAobmV4dFJlbWFpbmluZyA9PT0gMCAmJiAhY29tcGxldGlvbkhhbmRsZWRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGNvbXBsZXRpb25IYW5kbGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQodHJ1ZSk7XG4gICAgICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIHBsYXlDb21wbGV0aW9uQ2hpbWUoKTtcbiAgICAgICAgICAgICAgICBzaG93Q29tcGxldGlvbk5vdGlmaWNhdGlvbigpO1xuICAgICAgICAgICAgICAgIHJlZnJlc2hUaW1lcigpLmNhdGNoKCgpID0+IHNldEFjdGl2ZShmYWxzZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIHVwZGF0ZUNvdW50ZG93bigpO1xuICAgICAgICBjb25zdCBpbnRlcnZhbElkID0gd2luZG93LnNldEludGVydmFsKHVwZGF0ZUNvdW50ZG93biwgMjUwKTtcblxuICAgICAgICByZXR1cm4gKCkgPT4gd2luZG93LmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCk7XG4gICAgfSwgW2VuZFRpbWUsIGlzQWN0aXZlLCBwbGF5Q29tcGxldGlvbkNoaW1lLCByZWZyZXNoVGltZXIsIHNob3dDb21wbGV0aW9uTm90aWZpY2F0aW9uLCB1cGRhdGVTZXNzaW9uU3RhcnRlZF0pO1xuXG4gICAgY29uc3QgcnVuVGltZXJBY3Rpb24gPSBhc3luYyAoYWN0aW9uLCBvblN1Y2Nlc3MpID0+IHtcbiAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFjdGlvbigpO1xuICAgICAgICAgICAgb25TdWNjZXNzPy4ocmVzcG9uc2UpO1xuXG4gICAgICAgICAgICBpZiAocmVzcG9uc2U/LmVuZFRpbWUpIHtcbiAgICAgICAgICAgICAgICBzZXRFbmRUaW1lKG5ldyBEYXRlKHJlc3BvbnNlLmVuZFRpbWUpLmdldFRpbWUoKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGF3YWl0IHJlZnJlc2hUaW1lcigpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldEVycm9yKFxuICAgICAgICAgICAgICAgIHJlcXVlc3RFcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIHVwZGF0ZSB0aGUgdGltZXIuJyxcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBzdGFydFNlc3Npb24gPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmICghdGFzayB8fCB0YXNrLmlkID09IG51bGwpIHtcbiAgICAgICAgICAgIHNldEVycm9yKCdTZWxlY3QgYSB0YXNrIGZyb20gdGhlIGRhc2hib2FyZCBiZWZvcmUgc3RhcnRpbmcgYSBzZXNzaW9uLicpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlzQWN0aXZlIHx8IGhhc1N0YXJ0ZWRTZXNzaW9uIHx8IGlzTG9hZGluZykgcmV0dXJuO1xuXG4gICAgICAgIGNvbXBsZXRpb25IYW5kbGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgc2V0U2Vzc2lvbkNvbXBsZXRlZChmYWxzZSk7XG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgICAgIHNldE1lc3NhZ2UoJycpO1xuICAgICAgICBzZXRFcnJvcignJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IHJlc2V0VGltZXIoKTtcbiAgICAgICAgICAgIHNldFBoYXNlKCdGT0NVUycpO1xuICAgICAgICAgICAgc2V0RW5kVGltZShudWxsKTtcblxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBzdGFydFRpbWVyKHtcbiAgICAgICAgICAgICAgICB0YXNrSWQ6IHRhc2suaWQsXG4gICAgICAgICAgICAgICAgZHVyYXRpb25TZWNvbmRzOiB0YXNrLmR1cmF0aW9uU2Vjb25kcyA/PyBERUZBVUxUX0ZPQ1VTX1NFQ09ORFMsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdXBkYXRlU2Vzc2lvblN0YXJ0ZWQodHJ1ZSk7XG4gICAgICAgICAgICBpZiAocmVzcG9uc2U/LmVuZFRpbWUpIHtcbiAgICAgICAgICAgICAgICBzZXRFbmRUaW1lKG5ldyBEYXRlKHJlc3BvbnNlLmVuZFRpbWUpLmdldFRpbWUoKSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNldE1lc3NhZ2UoYFNlc3Npb24gU3RhcnRlZDogJHt0YXNrLnRpdGxlfWApO1xuICAgICAgICAgICAgYXdhaXQgcmVmcmVzaFRpbWVyKCk7XG4gICAgICAgIH0gY2F0Y2ggKHJlcXVlc3RFcnJvcikge1xuICAgICAgICAgICAgc2V0RXJyb3IoXG4gICAgICAgICAgICAgICAgcmVxdWVzdEVycm9yIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgICAgICAgICA/IHJlcXVlc3RFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgOiAnU2Vzc2lvbiB3YXMgdW5hYmxlIHRvIHN0YXJ0LicsXG4gICAgICAgICAgICApO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlQmFja2dyb3VuZENoYW5nZSA9IChuZXh0QmFja2dyb3VuZCkgPT4ge1xuICAgICAgICBzZXRCYWNrZ3JvdW5kKG5leHRCYWNrZ3JvdW5kKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncHJvamVjdC1rYXRjaHVwLWJhY2tncm91bmQnLCBuZXh0QmFja2dyb3VuZCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLy8gU2VsZWN0b3Igd2lsbCBzdGlsbCBvcGVyYXRlIGlmIGFuZCB3aGVuIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGUuXG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0VGFzayA9IChzZWxlY3RlZFRhc2spID0+IHtcbiAgICAgICAgaWYgKGhhc1N0YXJ0ZWRTZXNzaW9uKSByZXR1cm47XG4gICAgICAgIFxuICAgICAgICBzZXRUYXNrKHNlbGVjdGVkVGFzayk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5zZXNzaW9uU3RvcmFnZS5zZXRJdGVtKCdwcm9qZWN0LWthdGNodXAtc2VsZWN0ZWQtdGFzaycsIEpTT04uc3RyaW5naWZ5KHNlbGVjdGVkVGFzaykpO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8vIENhbiBzdGlsbCBzZWxlY3QgdGFzayBpZiBicm93c2VyIHN0b3JhZ2UgaXMgdW5hdmFpbGFibGUuXG4gICAgICAgIH1cblxuICAgICAgICBzZXRNZXNzYWdlKCcnKTtcbiAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUYXNrc0NoYW5nZWQgPSB1c2VDYWxsYmFjaygoZGVsZXRlZFRhc2tJZCA9IG51bGwpID0+IHtcbiAgICAgICAgc2V0VGFza1JlZnJlc2hTaWduYWwoKGN1cnJlbnRTaWduYWwpID0+IGN1cnJlbnRTaWduYWwgKyAxKTtcblxuICAgICAgICBpZiAoXG4gICAgICAgICAgICBkZWxldGVkVGFza0lkICE9PSBudWxsICYmXG4gICAgICAgICAgICBTdHJpbmcodGFzaz8uaWQpID09PSBTdHJpbmcoZGVsZXRlZFRhc2tJZCkgJiZcbiAgICAgICAgICAgICFpc0FjdGl2ZSAmJlxuICAgICAgICAgICAgIWhhc1N0YXJ0ZWRTZXNzaW9uXG4gICAgICAgICkge1xuICAgICAgICAgICAgc2V0VGFzayhudWxsKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgd2luZG93LnNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oJ3Byb2plY3Qta2F0Y2h1cC1zZWxlY3RlZC10YXNrJyk7XG4gICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBJZ25vcmVzIGJyb3dzZXIgc3RvcmFnZSB0aGF0IGlzIHVuYXZhaWxhYmxlLlxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSwgW2hhc1N0YXJ0ZWRTZXNzaW9uLCBpc0FjdGl2ZSwgdGFzaz8uaWRdKTtcblxuICAgIGNvbnN0IGhhbmRsZVRhc2tNYW5hZ2VyVG9nZ2xlID0gKCkgPT4ge1xuICAgICAgICBzZXRUYXNrTWFuYWdlck9wZW4oKGlzT3BlbikgPT4gIWlzT3Blbik7XG4gICAgICAgIHNldFRhc2tOb3RpY2UoJycpO1xuICAgICAgICBzZXRUYXNrRXJyb3IoJycpO1xuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVUYXNrTWFuYWdlckNsb3NlID0gKCkgPT4gc2V0VGFza01hbmFnZXJPcGVuKGZhbHNlKTtcblxuICAgIGNvbnN0IGhhbmRsZVRhc2tGb3JtQ2hhbmdlID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xuICAgICAgICBzZXRUYXNrRm9ybSgoY3VycmVudEZvcm0pID0+ICh7IC4uLmN1cnJlbnRGb3JtLCBbZmllbGRdOiB2YWx1ZSB9KSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZUNyZWF0ZVRhc2sgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcblxuICAgICAgICBjb25zdCB0aXRsZSA9IHRhc2tGb3JtLnRpdGxlLnRyaW0oKTtcbiAgICAgICAgaWYgKCF0aXRsZSkge1xuICAgICAgICAgICAgc2V0VGFza0Vycm9yKCdFbnRlciBhIHRpdGxlIGZvciB5b3VyIHRhc2suJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICBzZXRDcmVhdGluZ1Rhc2sodHJ1ZSk7XG4gICAgICAgIHNldFRhc2tFcnJvcignJyk7XG4gICAgICAgIHNldFRhc2tOb3RpY2UoJycpO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBjcmVhdGVUYXNrKHtcbiAgICAgICAgICAgICAgICB0aXRsZSxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogdGFza0Zvcm0uZGVzY3JpcHRpb24udHJpbSgpIHx8IG51bGwsXG4gICAgICAgICAgICAgICAgZHVlX2RhdGU6IHRhc2tGb3JtLmR1ZURhdGUgfHwgbnVsbCxcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBzZXRUYXNrRm9ybShFTVBUWV9UQVNLX0ZPUk0pO1xuICAgICAgICAgICAgc2V0VGFza05vdGljZShgQWRkZWQgXCIke3RpdGxlfVwiIHRvIHlvdXIgdGFza3MuYCk7XG4gICAgICAgICAgICBzZXRUYXNrUmVmcmVzaFNpZ25hbCgoY3VycmVudFNpZ25hbCkgPT4gY3VycmVudFNpZ25hbCArIDEpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldFRhc2tFcnJvcihcbiAgICAgICAgICAgICAgICByZXF1ZXN0RXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgICAgICAgICAgICA/IHJlcXVlc3RFcnJvci5tZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgIDogJ1VuYWJsZSB0byBjcmVhdGUgeW91ciB0YXNrLicsXG4gICAgICAgICAgICApO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgc2V0Q3JlYXRpbmdUYXNrKGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoYW5kbGVEZWxldGVUYXNrID0gYXN5bmMgKHRhc2t0b0RlbGV0ZSkgPT4ge1xuICAgICAgICBjb25zdCB0YXNrSWQgPSB0YXNrdG9EZWxldGU/LmlkID8/IHRhc2t0b0RlbGV0ZT8udGFza0lkO1xuICAgICAgICBjb25zdCB0YXNrVGl0bGUgPSB0YXNrdG9EZWxldGU/LnRpdGxlID8/IHRhc2t0b0RlbGV0ZT8ubmFtZSA/PyAnVW50aXRsZWQgdGFzayc7XG4gICAgICAgIFxuICAgICAgICBpZiAodGFza0lkID09IG51bGwpIHtcbiAgICAgICAgICAgIHNldFRhc2tBY3Rpb25FcnJvcignVGhpcyB0YXNrIGNhbm5vdCBiZSBkZWxldGVkIGJlY2F1c2UgaXQgaGFzIG5vIHRhc2sgSUQuJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGNvbmZpcm1lZCA9IHdpbmRvdy5jb25maXJtKFxuICAgICAgICAgICAgYEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgXCIke3Rhc2tUaXRsZX1cIj8gVGhpcyB3aWxsIHJlbW92ZSBpdCBmcm9tIHlvdXIgYWN0aXZlIHRhc2sgbGlzdC5gLFxuICAgICAgICApO1xuXG4gICAgICAgIGlmICghY29uZmlybWVkKSByZXR1cm47XG5cbiAgICAgICAgc2V0RGVsZXRpbmdUYXNrSWQodGFza0lkKTtcbiAgICAgICAgc2V0VGFza0FjdGlvbkVycm9yKCcnKTtcbiAgICAgICAgc2V0VGFza0FjdGlvbk5vdGljZSgnJyk7XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGF3YWl0IGRlbGV0ZVRhc2sodGFza0lkKTtcbiAgICAgICAgICAgIHNldFRhc2tBY3Rpb25Ob3RpY2UoYERlbGV0ZWQgXCIke3Rhc2tUaXRsZX1cIi5gKTtcbiAgICAgICAgICAgIGhhbmRsZVRhc2tzQ2hhbmdlZCh0YXNrSWQpO1xuICAgICAgICB9IGNhdGNoIChyZXF1ZXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHNldFRhc2tBY3Rpb25FcnJvcihcbiAgICAgICAgICAgICAgICByZXF1ZXN0RXJyb3IgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgICAgICAgID8gcmVxdWVzdEVycm9yLm1lc3NhZ2VcbiAgICAgICAgICAgICAgICA6ICdVbmFibGUgdG8gZGVsZXRlIHlvdXIgdGFzay4nLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgIHNldERlbGV0aW5nVGFza0lkKG51bGwpO1xuICAgICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlc3VtZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFoYXNTdGFydGVkU2Vzc2lvbiB8fCBpc0FjdGl2ZSB8fCByZW1haW5pbmdTZWNvbmRzIDw9IDAgfHwgaXNMb2FkaW5nKSByZXR1cm47XG4gICAgICAgIFxuICAgICAgICBjb21wbGV0aW9uSGFuZGxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24oc3RhcnRUaW1lcik7XG4gICAgfTtcbiAgICBcbiAgICBjb25zdCBoYW5kbGVQYXVzZSA9ICgpID0+IHJ1blRpbWVyQWN0aW9uKHBhdXNlVGltZXIpO1xuXG4gICAgY29uc3QgaGFuZGxlU3RvcCA9ICgpID0+IHtcbiAgICAgICAgY29tcGxldGlvbkhhbmRsZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24oc3RvcFRpbWVyLCAoKSA9PiB1cGRhdGVTZXNzaW9uU3RhcnRlZCh0cnVlKSk7XG4gICAgfTtcblxuICAgIGNvbnN0IGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xuICAgICAgICBjb21wbGV0aW9uSGFuZGxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIHNldFNlc3Npb25Db21wbGV0ZWQoZmFsc2UpO1xuICAgICAgICByZXR1cm4gcnVuVGltZXJBY3Rpb24ocmVzZXRUaW1lciwgKCkgPT4ge1xuICAgICAgICAgICAgc2V0UGhhc2UoJ0ZPQ1VTJyk7XG4gICAgICAgICAgICBzZXRSZW1haW5pbmdTZWNvbmRzKERFRkFVTFRfRk9DVVNfU0VDT05EUyk7XG4gICAgICAgICAgICBzZXRFbmRUaW1lKG51bGwpO1xuICAgICAgICAgICAgc2V0QWN0aXZlKGZhbHNlKTtcbiAgICAgICAgICAgIHVwZGF0ZVNlc3Npb25TdGFydGVkKGZhbHNlKTtcbiAgICAgICAgfSk7XG4gICAgfTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT17YHNtYXJ0LWZvY3VzLXVpIHdvcmtzcGFjZS1iYWNrZ3JvdW5kLSR7YmFja2dyb3VuZH1gfT5cbiAgICAgICAgICAgIDxEYXNoYm9hcmRcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFRhc2s9e3Rhc2t9XG4gICAgICAgICAgICAgICAgdGFza1NlbGVjdGlvbkRpc2FibGVkPXtoYXNTdGFydGVkU2Vzc2lvbn1cbiAgICAgICAgICAgICAgICBvblNlbGVjdFRhc2s9e2hhbmRsZVNlbGVjdFRhc2t9XG4gICAgICAgICAgICAgICAgcmVmcmVzaFNpZ25hbD17dGFza1JlZnJlc2hTaWduYWx9XG4gICAgICAgICAgICAgICAgb25EZWxldGVUYXNrPXtoYW5kbGVEZWxldGVUYXNrfVxuICAgICAgICAgICAgICAgIGRlbGV0aW5nVGFza0lkPXtkZWxldGluZ1Rhc2tJZH1cbiAgICAgICAgICAgICAgICB0YXNrQWN0aW9uRXJyb3I9e3Rhc2tBY3Rpb25FcnJvcn1cbiAgICAgICAgICAgICAgICB0YXNrQWN0aW9uTm90aWNlPXt0YXNrQWN0aW9uTm90aWNlfVxuICAgICAgICAgICAgICAgIHRhc2tBY3Rpb25Ob3RpY2VGYWRpbmc9e2lzVGFza0FjdGlvbk5vdGljZUZhZGluZ31cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIDxTZXR0aW5nc1BhbmVsIFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ9e2JhY2tncm91bmR9XG4gICAgICAgICAgICAgICAgb25CYWNrZ3JvdW5kQ2hhbmdlPXtoYW5kbGVCYWNrZ3JvdW5kQ2hhbmdlfVxuICAgICAgICAgICAgICAgIGlzVGFza01hbmFnZXJPcGVuPXtpc1Rhc2tNYW5hZ2VyT3Blbn1cbiAgICAgICAgICAgICAgICB0YXNrRm9ybT17dGFza0Zvcm19XG4gICAgICAgICAgICAgICAgaXNDcmVhdGluZ1Rhc2s9e2lzQ3JlYXRpbmdUYXNrfVxuICAgICAgICAgICAgICAgIHRhc2tFcnJvcj17dGFza0Vycm9yfVxuICAgICAgICAgICAgICAgIHRhc2tOb3RpY2U9e3Rhc2tOb3RpY2V9XG4gICAgICAgICAgICAgICAgdGFza05vdGljZUZhZGluZz17aXNUYXNrTm90aWNlRmFkaW5nfVxuICAgICAgICAgICAgICAgIG9uVGFza01hbmFnZXJUb2dnbGU9e2hhbmRsZVRhc2tNYW5hZ2VyVG9nZ2xlfVxuICAgICAgICAgICAgICAgIG9uVGFza01hbmFnZXJDbG9zZT17aGFuZGxlVGFza01hbmFnZXJDbG9zZX1cbiAgICAgICAgICAgICAgICBvblRhc2tGb3JtQ2hhbmdlPXtoYW5kbGVUYXNrRm9ybUNoYW5nZX1cbiAgICAgICAgICAgICAgICBvbkNyZWF0ZVRhc2s9e2hhbmRsZUNyZWF0ZVRhc2t9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtYXJ0LWZvY3VzLXNlc3Npb24tYnV0dG9uXCI+XG4gICAgICAgICAgICAgICAgPFN0YXJ0U2Vzc2lvbkJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzdGFydFNlc3Npb259XG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQWN0aXZlIHx8IGhhc1N0YXJ0ZWRTZXNzaW9uIHx8ICF0YXNrfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2Vycm9yICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtYXJ0LWZvY3VzLWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHttZXNzYWdlICYmICFlcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BzbWFydC1mb2N1cy1tZXNzYWdlIGF1dG8tZGlzbWlzcy1ub3RpY2Uke2lzTWVzc2FnZUZhZGluZyA/ICcgaXMtZmFkaW5nJyA6ICcnfWB9IHJvbGU9XCJzdGF0dXNcIj5cbiAgICAgICAgICAgICAgICAgICAge21lc3NhZ2V9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8UG9tb2Rvcm9UaW1lclxuICAgICAgICAgICAgICAgIHRhc2s9e3Rhc2t9XG4gICAgICAgICAgICAgICAgcGhhc2U9e3BoYXNlfVxuICAgICAgICAgICAgICAgIHJlbWFpbmluZ1NlY29uZHM9e3JlbWFpbmluZ1NlY29uZHN9XG4gICAgICAgICAgICAgICAgaXNBY3RpdmU9e2lzQWN0aXZlfVxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxuICAgICAgICAgICAgICAgIHNlc3Npb25Db21wbGV0ZWQ9e3Nlc3Npb25Db21wbGV0ZWR9XG4gICAgICAgICAgICAgICAgZXJyb3I9eycnfVxuICAgICAgICAgICAgICAgIG9uUmVzdW1lPXtoYW5kbGVSZXN1bWV9XG4gICAgICAgICAgICAgICAgY2FuUmVzdW1lPXtoYXNTdGFydGVkU2Vzc2lvbiAmJiAhaXNBY3RpdmUgJiYgcmVtYWluaW5nU2Vjb25kcyA+IDAgJiYgIXNlc3Npb25Db21wbGV0ZWR9XG4gICAgICAgICAgICAgICAgb25QYXVzZT17aGFuZGxlUGF1c2V9XG4gICAgICAgICAgICAgICAgb25TdG9wPXtoYW5kbGVTdG9wfVxuICAgICAgICAgICAgICAgIG9uUmVzZXQ9e2hhbmRsZVJlc2V0fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIFxuICAgICAgICA8L21haW4+XG4gICAgKTtcbn1cbiJdfQ==